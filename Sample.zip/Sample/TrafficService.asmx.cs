﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using junoViewerLib;
using System.Configuration;
using System.IO;

using junoViewerLib.DAL;
using junoViewerLib.BAL;
using junoViewerLib.TrafficModule;
using System.Xml.Linq;
using System.Data;
using System.Drawing;
using junoViewerVBUtilities;
using System.Xml;
using junoViewerLib.Utils;
using junoViewerLib.Client_Specific.TRAC;

namespace JunoViewer_Web.webServices
{
    /// <summary>
    /// Summary description for TrafficService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class TrafficService : System.Web.Services.WebService
    {

        [WebMethod(enableSession: true)]
        public List<string> GetAllSectionsData()
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var user = Session["user"] as junoViewerLib.BAL.UserBAL;

            //Get connection to the user's database
            string connString = user.GetConnectionString();
            var dbMan = new DBWorkerBase(connString);
            var netDefDAL = new NetworkDefinitionDAL();
            List<NetworkSegment> sections;
            if (user.NetworkIDs != "" && user.NetworkIDs != null && user.NetworkIDs != "0" && user.PermissionName != "Administrator")
            {
                sections = netDefDAL.GetSectionDefinitionsByNetwordIDs(dbMan, user.NetworkIDs);
            }
            else
            {
                sections = netDefDAL.GetSectionDefinitions(dbMan, -1);
            }
            var data = new List<string>();
            sections.OrderBy(d => d.SectionLabel1).ToList();
            foreach (var section in sections)
            {
                data.Add(section.SectionID.ToString() + "|" + section.SectionLabel1.ToString() + " " + section.SectionLabel2.ToString());
            }
            return data;

        }
        [WebMethod(enableSession: true)]
        public List<string> GetTrafficeStationChannelBySections(string SectionIDs)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;

                //Get connection to the user's database
                string connString = user.GetConnectionString();
                var dbMan = new DBWorkerBase(connString);
                var TrafCha = new trafficStationChannel();
                List<trafficStationChannel> TrafficeChannels;
                TrafficeChannels = TrafCha.GetTrafficStationChannelBySections(dbMan, SectionIDs);
                var data = new List<string>();
                TrafficeChannels.OrderBy(d => d.secName).ToList();
                foreach (var TrafChan in TrafficeChannels)
                {
                    data.Add(TrafChan.ID.ToString() + "|" + TrafChan.statNumber.ToString() + " " + TrafChan.secName.ToString() + " Km" + string.Format("{0:#0.00}", Convert.ToDouble(TrafChan.location) / 1000) + " " + TrafChan.statName.ToString() + "; Lane = " + TrafChan.lane.ToString());
                }
                return data;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficeStationChannelBySections. Details: " + ex.Message);
            }

        }


        /// <summary>
        /// Gets the Traffic Channels Info for the selected Link 
        /// </summary>
        /// <param name="LinkID"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public string GetSelectedReportDataInXL(string linkID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    //Get connection to the user's database
                    string connString = user.GetConnectionString();
                    var dbMan = new DBWorkerBase(connString);
                    var traffDAL = new trafficDAL();
                    List<clsTrafficReport> trafficData = traffDAL.GetDetailsForReportName(dbMan, Convert.ToInt32(linkID));
                    var key = user.ID + "_" + trafficData[0].Name;
                    string fileURL = "~/zz_temp/" + key + ".xlsx";
                    string fName = Server.MapPath(fileURL);
                    string sheetName = trafficData[0].Name;
                    System.IO.File.Delete(fName);
                    junoViewerVBUtilities.jCollection reportResult = new junoViewerVBUtilities.jCollection();

                    if (trafficData.Count > 0)
                    {
                        string chanXML = trafficData[0].channelsXML.Replace("\r\n", "").Replace(" ", String.Empty);
                        XDocument y = XDocument.Parse(chanXML);
                        var chanXMLtables = y.Descendants("id");
                        string channel = "";
                        foreach (var chanID in chanXMLtables)
                        {
                            channel = channel + chanID.Value + ",";

                        }
                        if (channel != "")
                        {
                            string channelIDs = channel.Substring(0, channel.Length - 1);
                            DataTable dtChannels = traffDAL.GetTrafficDataWithChannles(dbMan, channelIDs);

                            if (dtChannels.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtChannels.Rows.Count; i++)
                                {
                                    var reportRow = new junoViewerVBUtilities.jCollection();
                                    reportRow["Link Name"] = trafficData[0].Name.ToString();
                                    reportRow["Section"] = dtChannels.Rows[i]["secName"].ToString();
                                    reportRow["Station"] = dtChannels.Rows[i]["statName"].ToString();
                                    reportRow["Channel"] = dtChannels.Rows[i]["channelCode"].ToString();
                                    reportRow["Location"] = dtChannels.Rows[i]["location"].ToString();
                                    reportRow["Lane"] = dtChannels.Rows[i]["lane"].ToString();
                                    if (dtChannels.Rows[i]["monthStart"].ToString() != "" && dtChannels.Rows[i]["monthStart"].ToString() != null)
                                    {
                                        DateTime dateStart = Convert.ToDateTime(dtChannels.Rows[i]["monthStart"]);
                                        reportRow["Month Start"] = dateStart.ToString("dd-MMM-yyyy");
                                    }
                                    else
                                    {
                                        reportRow["Month Start"] = "";
                                    }
                                    if (dtChannels.Rows[i]["monthEnd"].ToString() != "" && dtChannels.Rows[i]["monthEnd"].ToString() != null)
                                    {
                                        DateTime dateEnd = Convert.ToDateTime(dtChannels.Rows[i]["monthEnd"]);
                                        reportRow["Month End"] = dateEnd.ToString("dd-MMM-yyyy");
                                    }
                                    else
                                    {
                                        reportRow["Month End"] = "";
                                    }
                                    reportRow["ADT"] = dtChannels.Rows[i]["ADT"].ToString();
                                    reportRow["ADTT"] = dtChannels.Rows[i]["ADTT"].ToString();
                                    reportRow["E80perHeavy"] = dtChannels.Rows[i]["E80perHeavy"].ToString();
                                    reportRow["Light Sum"] = dtChannels.Rows[i]["lightSum"].ToString();
                                    reportRow["Light Min"] = dtChannels.Rows[i]["lightMin"].ToString();
                                    reportRow["Light Max"] = dtChannels.Rows[i]["lightMax"].ToString();
                                    reportRow["Light Std Dev"] = dtChannels.Rows[i]["lightStdDev"].ToString();
                                    reportRow["Heavy Sum"] = dtChannels.Rows[i]["heavySum"].ToString();
                                    reportRow["Heavy Min"] = dtChannels.Rows[i]["heavyMin"].ToString();
                                    reportRow["Heavy Max"] = dtChannels.Rows[i]["heavyMax"].ToString();
                                    reportRow["Heavy Std Dev"] = dtChannels.Rows[i]["heavyStdDev"].ToString();
                                    reportRow["Total Sum"] = dtChannels.Rows[i]["totalSum"].ToString();
                                    reportRow["Total Min"] = dtChannels.Rows[i]["totalMin"].ToString();
                                    reportRow["Total Max"] = dtChannels.Rows[i]["totalMax"].ToString();
                                    reportRow["Total Std Dev"] = dtChannels.Rows[i]["totalStdDev"].ToString();
                                    reportRow["Long Heavy(%)"] = dtChannels.Rows[i]["longHeavyPerc"].ToString();
                                    reportRow["Good Record(%)"] = dtChannels.Rows[i]["goodRecordPerc"].ToString();
                                    reportRow["Overload Perc(%)"] = dtChannels.Rows[i]["overloadPerc"].ToString();
                                    reportResult.Add(reportRow);
                                }
                            }

                            else
                            {
                                var reportRow = new junoViewerVBUtilities.jCollection();
                                reportRow["Link Name"] = "";
                                reportRow["Section"] = "";
                                reportRow["Station"] = "";
                                reportRow["Channel"] = "";
                                reportRow["Location"] = "";
                                reportRow["Lane"] = "";
                                reportRow["Month Start"] = "";
                                reportRow["Month End"] = "";
                                reportRow["ADT"] = "";
                                reportRow["ADTT"] = "";
                                reportRow["E80perHeavy"] = "";
                                reportRow["Light Sum"] = "";
                                reportRow["Light Min"] = "";
                                reportRow["Light Max"] = "";
                                reportRow["Light Std Dev"] = "";
                                reportRow["Heavy Sum"] = "";
                                reportRow["Heavy Min"] = "";
                                reportRow["Heavy Max"] = "";
                                reportRow["Heavy Std Dev"] = "";
                                reportRow["Total Sum"] = "";
                                reportRow["Total Min"] = "";
                                reportRow["Total Max"] = "";
                                reportRow["Total Std Dev"] = "";
                                reportRow["Long Heavy(%)"] = "";
                                reportRow["Good Record(%)"] = "";
                                reportRow["Overload Perc(%)"] = "";
                                reportResult.Add(reportRow);
                            }

                            junoViewerVBUtilities.xlFileHelper.ExportTableDataToExcel(reportResult, fName, sheetName, 0, 0, 9, SpreadsheetGear.FileFormat.OpenXMLWorkbook);
                            return fileURL;
                        }
                        else
                        {
                            return "";
                        }
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetSelectedReportDataInXL. Details: " + ex.Message);
            }
        }

        [WebMethod(enableSession: true)]
        public int AddTrafficReport(string Sections, string Channels, string GrowthChannels, string Direction, int LocStart, int LocEnd, bool AddDataOverLanes, bool FitGrowthRate, string DateFrom, string DateTo, string Reportname, string Description, string projected_ADT, string projected_ADTT, string projected_E80perHeavy, string growth_ADT, string growth_ADTT, string growth_E80perHeavy)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());

                var TraffData = new trafficView();
                string SecXml = getSectionsXmlFormat(Sections);
                string ChannelXml = getChannelXmlFormat(Channels);
                string GrowthChannelXml = getGrowthChannelXmlFormat(GrowthChannels);
                DateTime enteredDateFrom = DateTime.Parse(DateFrom);
                DateTime enteredDateTo = DateTime.Parse(DateTo);

                if (user != null)
                {
                    var DAL = new trafficDAL();
                    TraffData.reportName = Reportname;
                    TraffData.routePosition = 0;
                    TraffData.Description = Description;
                    TraffData.direction = Direction;
                    TraffData.routeStart = LocStart;
                    TraffData.routeEnd = LocEnd;
                    TraffData.comment = null;
                    TraffData.sectionsXML = SecXml;
                    TraffData.channelsXML = ChannelXml;
                    TraffData.growthChannelsXML = GrowthChannelXml;
                    TraffData.addDataOverLanes = AddDataOverLanes;
                    TraffData.fitGrowthRate = FitGrowthRate;
                    TraffData.growthDateFrom = enteredDateFrom;
                    TraffData.growthDateTo = enteredDateTo;
                    TraffData.growth_ADT = float.Parse(Math.Round(Convert.ToDouble(growth_ADT), 1).ToString());
                    TraffData.growth_ADTT = float.Parse(Math.Round(Convert.ToDouble(growth_ADTT), 1).ToString());
                    TraffData.growth_E80perHeavy = float.Parse(Math.Round(Convert.ToDouble(growth_E80perHeavy), 1).ToString());
                    TraffData.projected_ADT = float.Parse(Math.Round(Convert.ToDouble(projected_ADT), 1).ToString());
                    TraffData.projected_ADTT = float.Parse(Math.Round(Convert.ToDouble(projected_ADTT), 1).ToString());
                    TraffData.projected_E80perHeavy = float.Parse(Math.Round(Convert.ToDouble(projected_E80perHeavy), 1).ToString());
                    return DAL.AddTrafficReports(TraffData, dbMan);
                }
                return -999;

            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddTrafficReport. Details: " + ex.Message);
            }
        }

        [WebMethod(enableSession: true)]
        public int AddValidate(string ReportName)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var result = new List<NameAndIDData>();
            if (user != null)
            {
                var DAL = new trafficDAL();
                result = DAL.ReadReportName(dbMan);
                for (int i = 0; i < result.Count(); i++)
                {

                    if (result[i].Name.ToString().ToUpper() == ReportName.ToUpper())
                    {
                        return 1;
                    }
                }

            }
            return -999;
        }

        [WebMethod(enableSession: true)]
        public int UpdatesTrafficReport(string Sections, string Channels, string GrowthChannels, string Direction, int LocStart, int LocEnd, bool AddDataOverLanes, bool FitGrowthRate, string DateFrom, string DateTo, string Reportname, int ReportID, string Description, string projected_ADT, string projected_ADTT, string projected_E80perHeavy, string growth_ADT, string growth_ADTT, string growth_E80perHeavy, int routePosition)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            string SecXml = getSectionsXmlFormat(Sections);
            string ChannelXml = getChannelXmlFormat(Channels);
            string GrowthChannelXml = getGrowthChannelXmlFormat(GrowthChannels);
            DateTime enteredDateFrom = DateTime.Parse(DateFrom);
            DateTime enteredDateTo = DateTime.Parse(DateTo);

            if (user != null)
            {
                var DAL = new trafficDAL();
                var TraffData = new trafficView();
                var repname = Reportname;
                //Commented and Added by Kanaka Raju for route Position is updating Zero
                //TraffData.routePosition = 0;
                TraffData.routePosition = routePosition;
                //-------------------------
                TraffData.ID = ReportID;
                TraffData.Description = Description;
                TraffData.direction = Direction;
                TraffData.routeStart = LocStart;
                TraffData.routeEnd = LocEnd;
                TraffData.comment = null;
                TraffData.sectionsXML = SecXml;
                TraffData.channelsXML = ChannelXml;
                TraffData.growthChannelsXML = GrowthChannelXml;
                TraffData.addDataOverLanes = AddDataOverLanes;
                TraffData.fitGrowthRate = FitGrowthRate;
                TraffData.growthDateFrom = enteredDateFrom;
                TraffData.growthDateTo = enteredDateTo;
                TraffData.growth_ADT = float.Parse(Math.Round(Convert.ToDouble(growth_ADT), 1).ToString());
                TraffData.growth_ADTT = float.Parse(Math.Round(Convert.ToDouble(growth_ADTT), 1).ToString());
                TraffData.growth_E80perHeavy = float.Parse(Math.Round(Convert.ToDouble(growth_E80perHeavy), 1).ToString());
                TraffData.projected_ADT = float.Parse(Math.Round(Convert.ToDouble(projected_ADT), 1).ToString());
                TraffData.projected_ADTT = float.Parse(Math.Round(Convert.ToDouble(projected_ADTT), 1).ToString());
                TraffData.projected_E80perHeavy = float.Parse(Math.Round(Convert.ToDouble(projected_E80perHeavy), 1).ToString());
                return DAL.UpdateTrafficReports(TraffData, dbMan, ReportID);
            }
            return -999;
        }

        [WebMethod(enableSession: true)]
        public int UpdateTrafficGrid(int ReportID, int routePosition, string reportName)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());

                if (user != null)
                {
                    var DAL = new trafficDAL();

                    return DAL.UpdateTrafficData(routePosition, dbMan, ReportID, reportName);
                }
                return -999;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateTrafficReport. Details: " + ex.Message);
            }
        }

        [WebMethod(enableSession: true)]
        public int InsertGlobalValue(string MonthDate)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                UserBAL user = Context.Session["user"] as UserBAL;
                if (user != null)
                {
                    string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                    var dbMan = new DBWorkerBase(connString);
                    int AccountId = user.AccountID;
                    var DAL = new trafficDAL();
                    string ParamName = "TrafficProjectedMonth";
                    DataTable dtGlobalValues = DAL.GetGlobalData(dbMan, AccountId, ParamName);
                    if (dtGlobalValues.Rows.Count > 0)
                    {
                        return DAL.UpdateGlobalValue(dbMan, MonthDate, AccountId);
                    }
                    else
                    {
                        return DAL.InsertGlobalValue(dbMan, MonthDate, AccountId);
                    }
                }
                return -999;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateTrafficReport. Details: " + ex.Message);
            }
        }
        [WebMethod(enableSession: true)]
        public int CalculateReportData(string GDateTo)
        {

            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            //calculating ADT,ADTT,E80 Using name value pair
            var result = new List<clsTrafficReport>();
            int totalrows = 0;
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var DAL = new trafficDAL();
            result = DAL.GetReports(dbMan);
            List<Exception> Exceptions = new List<Exception>();
            foreach (var items in result)
            {
                try
                {
                    string SecXML = items.sectionsXML.Replace("\r\n", "").Trim();
                    XDocument x = XDocument.Parse(SecXML);
                    var SecXMLtables = x.Descendants("section");
                    string Sec = "";
                    string channel = "";
                    string growthchannel = "";
                    foreach (var secName in SecXMLtables)
                    {
                        Sec = Sec + secName.Value + ",";
                    }

                    string ChanXML = items.channelsXML.Replace("\r\n", "").Replace(" ", String.Empty);
                    XDocument y = XDocument.Parse(ChanXML);
                    var ChanXMLtables = y.Descendants("id");
                    foreach (var chanID in ChanXMLtables)
                    {
                        channel = channel + chanID.Value + ",";

                    }

                    string GrowChanXML = items.growthChannelsXML.Replace("\r\n", "").Replace(" ", String.Empty).Trim();
                    XDocument z = XDocument.Parse(GrowChanXML);
                    var GrowChanXMLtables = z.Descendants("id");
                    foreach (var GrowchanID in GrowChanXMLtables)
                    {
                        growthchannel = growthchannel + GrowchanID.Value + ",";

                    }
                    bool fixgrowth;
                    bool adddata;
                    if (items.fitGrowthRate == 1)
                    {
                        fixgrowth = true;
                    }
                    else
                    {
                        fixgrowth = false;
                    }
                    if (items.addDataOverLanes == 1)
                    {
                        adddata = true;
                    }
                    else
                    {
                        adddata = false;
                    }
                    List<NameAndDataValues> obj = new List<NameAndDataValues>();
                    obj = GetReportImageURL(Sec.Substring(0, Sec.Length - 1), channel.Substring(0, channel.Length - 1), growthchannel.Substring(0, growthchannel.Length - 1), items.direction, items.routeStart, items.routeEnd, adddata, fixgrowth, items.growthDateFrom, GDateTo, items.Name, items.description);
                    int rows = UpdatesGrowthProjectedValues(obj[1].DataValues, obj[2].DataValues, obj[3].DataValues, obj[4].DataValues, obj[5].DataValues, obj[6].DataValues, items.Value, GDateTo);
                    totalrows = totalrows + rows;
                }
                catch (Exception ex)
                {
                    Exceptions.Add(ex);
                }
            }
            return totalrows;
        }
        private int UpdatesGrowthProjectedValues(string projected_ADT, string projected_ADTT, string projected_E80perHeavy, string growth_ADT, string growth_ADTT, string growth_E80perHeavy, int ReportID, string DateTo)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                if (user != null)
                {
                    var DAL = new trafficDAL();
                    var TraffData = new trafficView();
                    DateTime growthDateTo = junoViewerVBUtilities.clsGoferTools.ParseDateNoTime(DateTo);
                    TraffData.ID = ReportID;
                    TraffData.growth_ADT = float.Parse(Convert.ToDouble(growth_ADT).ToString());
                    TraffData.growth_ADTT = float.Parse(Convert.ToDouble(growth_ADTT).ToString());
                    TraffData.growth_E80perHeavy = float.Parse(Convert.ToDouble(growth_E80perHeavy).ToString());
                    TraffData.projected_ADT = float.Parse(Convert.ToDouble(projected_ADT).ToString());
                    TraffData.projected_ADTT = float.Parse(Convert.ToDouble(projected_ADTT).ToString());
                    TraffData.projected_E80perHeavy = float.Parse(Convert.ToDouble(projected_E80perHeavy).ToString());
                    TraffData.growthDateTo = growthDateTo;
                    return DAL.UpdatesGrowthProjectedValues(TraffData, dbMan, ReportID);
                }
                return -999;

            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateTrafficReport. Details: " + ex.Message);
            }
        }

        [WebMethod(enableSession: true)]
        public List<clsTrafficReport> GetDataForReportName(int ReportID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<clsTrafficReport>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var DAL = new trafficDAL();
            return DAL.GetDetailsForReportName(dbMan, ReportID);
        }

        [WebMethod(enableSession: true)]
        public List<NameAndDataValues> GetDistinctGrowthDate()
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                return DAL.GetDistinctGrowthDate(dbMan);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetDistinctGrowthDate. Details: " + ex.Message);
            }
        }

        [WebMethod(enableSession: true)]
        public List<NameAndIDData> GetReportsData(string Direction)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<NameAndIDData>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var DAL = new trafficDAL();
            return DAL.GetReportForDirection(dbMan, Direction);
        }

        [WebMethod(enableSession: true)]
        public string GetProjectedMonth()
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var result = new List<NameAndIDData>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                int AccountId = user.AccountID;
                string ParamName = "TrafficProjectedMonth";
                var dbAdmin = new DBWorkerBase(connString);
                AccountDAL objAccount = new AccountDAL();
                string pd = Convert.ToString(objAccount.GetParamValueFromNameValuePair(user.AccountID, ParamName, dbAdmin));
                return pd;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetReportsData. Details: " + ex.Message);
            }

        }


        [WebMethod(enableSession: true)]
        public List<clsTrafficReport> GetReports()
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                var result = new List<clsTrafficReport>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                return DAL.GetReports(dbMan);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetReports. Details: " + ex.Message);
            }

        }

        [WebMethod(enableSession: true)]
        public int DeleteReports(int ReportID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var result = new List<clsTrafficReport>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                return DAL.DeleteReport(dbMan, ReportID);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetReports. Details: " + ex.Message);
            }

        }

        [WebMethod(enableSession: true)]
        public bool Searchreports(string ReportName)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                var result = new List<clsTrafficReport>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                return DAL.SearchForReport(dbMan, ReportName);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetReports. Details: " + ex.Message);
            }

        }
        [WebMethod(enableSession: true)]
        public string GenerateLinks()
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                var result = new List<clsTrafficReport>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                DataTable dtReports = DAL.GetDataForReports(dbMan);
                var key = user.ID + "_" + HttpContext.Current.Session.SessionID;
                string fileURL = "~/zz_temp/" + key + ".xlsx";
                string fName = Server.MapPath(fileURL);
                System.IO.File.Delete(fName);
                junoViewerVBUtilities.jCollection ReportResult = new junoViewerVBUtilities.jCollection();

                if (dtReports.Rows.Count > 0)
                {
                    for (int i = 0; i < dtReports.Rows.Count; i++)
                    {
                        var reportRow = new junoViewerVBUtilities.jCollection();
                        reportRow["LinkName"] = dtReports.Rows[i]["reportName"].ToString();
                        reportRow["Index"] = dtReports.Rows[i]["routePosition"].ToString();
                        reportRow["Direction"] = dtReports.Rows[i]["direction"].ToString();
                        reportRow["StartLocation"] = dtReports.Rows[i]["routeStart"].ToString();
                        reportRow["EndLocation"] = dtReports.Rows[i]["routeEnd"].ToString();
                        string SecXML = dtReports.Rows[i]["sectionsXML"].ToString().Replace("\r\n", "").Trim();
                        XDocument x = XDocument.Parse(SecXML);
                        var SecXMLtables = x.Descendants("section");
                        string Sec = "";
                        string channel = "";
                        string growthchannel = "";
                        foreach (var secName in SecXMLtables)
                        {
                            Sec = Sec + secName.Value + ",";
                        }

                        string ChanXML = dtReports.Rows[i]["channelsXML"].ToString().Replace("\r\n", "").Trim().Replace("\r\n", "").Replace(" ", String.Empty);
                        XDocument y = XDocument.Parse(ChanXML);
                        var ChanXMLtables = y.Descendants("id");
                        foreach (var chanID in ChanXMLtables)
                        {
                            channel = channel + chanID.Value + ",";

                        }

                        trafficStationChannel TrafCha = new trafficStationChannel();
                        List<trafficStationChannel> TrafficeChannels;
                        TrafficeChannels = TrafCha.GetTrafficStationChannelByChannelID(dbMan, channel.Substring(0, channel.Length - 1));
                        var data = new List<string>();
                        TrafficeChannels.OrderBy(d => d.secName).ToList();

                        foreach (var TrafChan in TrafficeChannels)
                        {
                            //data.Add(TrafChan.ID.ToString() + "|" + TrafChan.statNumber.ToString() + " " + TrafChan.secName.ToString() + " Km" + string.Format("{0:#0.00}", Convert.ToDouble(TrafChan.location) / 1000) + " " + TrafChan.statName.ToString() + "; Lane = " + TrafChan.lane.ToString());
                            data.Add(TrafChan.ID.ToString() + "|" + TrafChan.statNumber.ToString() + " " + TrafChan.secName.ToString());
                        }

                        string GrowChanXML = dtReports.Rows[i]["growthChannelsXML"].ToString().Replace("\r\n", "").Trim().Replace("\r\n", "").Replace(" ", String.Empty);
                        XDocument z = XDocument.Parse(GrowChanXML);
                        var GrowChanXMLtables = z.Descendants("id");
                        foreach (var GrowchanID in GrowChanXMLtables)
                        {
                            for (var k = 0; k < data.Count; k++)
                            {
                                if (GrowchanID.Value == data[k].Split('|')[0])
                                {
                                    growthchannel = growthchannel + data[k].Split('|')[1] + ",";
                                }
                            }
                        }
                        string channelNames = "";
                        for (var j = 0; j < data.Count; j++)
                        {
                            if (j == data.Count - 1)
                            {
                                channelNames = channelNames + data[j].Split('|')[1];
                            }
                            else
                            {
                                channelNames = channelNames + data[j].Split('|')[1] + ",";

                            }
                        }

                        reportRow["Sections"] = Sec.Substring(0, Sec.Length - 1);
                        reportRow["Channels"] = channelNames;
                        reportRow["GrowthChannels"] = growthchannel.Substring(0, growthchannel.Length - 1);
                        if (Convert.ToInt32(dtReports.Rows[i]["growth_ADT"]) == -999)
                        {
                            reportRow["Growth_ADT"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Growth_ADT"] = dtReports.Rows[i]["growth_ADT"].ToString();
                        }
                        if (Convert.ToInt32(dtReports.Rows[i]["growth_ADTT"]) == -999)
                        {
                            reportRow["Growth_ADTT"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Growth_ADTT"] = dtReports.Rows[i]["growth_ADTT"].ToString();
                        }

                        if (Convert.ToInt32(dtReports.Rows[i]["growth_E80perHeavy"]) == -999)
                        {
                            reportRow["Growth_E80"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Growth_E80"] = dtReports.Rows[i]["growth_E80perHeavy"].ToString();
                        }
                        if (Convert.ToInt32(dtReports.Rows[i]["projected_ADT"]) == -999)
                        {
                            reportRow["Projected_ADT"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Projected_ADT"] = string.Format("{0:#0.00}", dtReports.Rows[i]["projected_ADT"]);
                        }
                        if (Convert.ToInt32(dtReports.Rows[i]["projected_ADTT"]) == -999)
                        {
                            reportRow["Projected_ADTT"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Projected_ADTT"] = string.Format("{0:#0.00}", dtReports.Rows[i]["projected_ADTT"]);

                        }
                        if (Convert.ToInt32(dtReports.Rows[i]["projected_E80perHeavy"]) == -999)
                        {
                            reportRow["Projected_E80"] = "Undetermined";
                        }
                        else
                        {
                            reportRow["Projected_E80"] = string.Format("{0:#0.00}", dtReports.Rows[i]["projected_E80perHeavy"]);

                        }

                        ReportResult.Add(reportRow);
                    }
                }

                else
                {
                    var reportRow = new junoViewerVBUtilities.jCollection();
                    reportRow["LinkName"] = "";
                    reportRow["Index"] = "";
                    reportRow["Direction"] = "";
                    reportRow["StartLocation"] = "";
                    reportRow["EndLocation"] = "";
                    reportRow["Sections"] = "";
                    reportRow["Channels"] = "";
                    reportRow["GrowthChannels"] = "";
                    reportRow["Growth_ADT"] = "";
                    reportRow["Growth_ADTT"] = "";
                    reportRow["Growth_E80"] = "";
                    reportRow["Projected_ADT"] = "";
                    reportRow["Projected_ADTT"] = "";
                    reportRow["Projected_E80"] = "";
                    ReportResult.Add(reportRow);
                }

                junoViewerVBUtilities.xlFileHelper.ExportTableDataToExcel(ReportResult, fName, "Traffic_Links", 0, 0, 9, SpreadsheetGear.FileFormat.OpenXMLWorkbook);
                return fileURL;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetReports. Details: " + ex.Message);
            }

        }

        [WebMethod(enableSession: true)]
        public string GenerateReportWord()
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var result = new List<clsTrafficReport>();
                var data = "";
                var InproperReports = "";
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                result = DAL.GetReports(dbMan);
                List<Exception> Exceptions = new List<Exception>();
                foreach (var items in result)
                {
                    try
                    {
                        string SecXML = items.sectionsXML.Replace("\r\n", "").Trim();
                        XDocument x = XDocument.Parse(SecXML);
                        var SecXMLtables = x.Descendants("section");
                        string Sec = "";
                        string channel = "";
                        string growthchannel = "";
                        foreach (var secName in SecXMLtables)
                        {
                            Sec = Sec + secName.Value + ",";
                        }

                        string ChanXML = items.channelsXML.Replace("\r\n", "").Replace(" ", String.Empty);
                        XDocument y = XDocument.Parse(ChanXML);
                        var ChanXMLtables = y.Descendants("id");
                        foreach (var chanID in ChanXMLtables)
                        {
                            channel = channel + chanID.Value + ",";

                        }

                        string GrowChanXML = items.growthChannelsXML.Replace("\r\n", "").Replace(" ", String.Empty).Trim();
                        XDocument z = XDocument.Parse(GrowChanXML);
                        var GrowChanXMLtables = z.Descendants("id");
                        foreach (var GrowchanID in GrowChanXMLtables)
                        {
                            growthchannel = growthchannel + GrowchanID.Value + ",";

                        }
                        bool fixgrowth;
                        bool adddata;
                        if (items.fitGrowthRate == 1)
                        {
                            fixgrowth = true;
                        }
                        else
                        {
                            fixgrowth = false;
                        }
                        if (items.addDataOverLanes == 1)
                        {
                            adddata = true;
                        }
                        else
                        {
                            adddata = false;
                        }
                        List<NameAndDataValues> obj = new List<NameAndDataValues>();
                        obj = GetReportImageURL(Sec.Substring(0, Sec.Length - 1), channel.Substring(0, channel.Length - 1), growthchannel.Substring(0, growthchannel.Length - 1), items.direction, items.routeStart, items.routeEnd, adddata, fixgrowth, items.growthDateFrom, items.growthDateTo, items.Name, items.description);
                        data = data + obj[0].DataValues + "^" + items.Name + "|";
                    }
                    catch (Exception ex)
                    {
                        InproperReports = InproperReports + items.Name + "?";
                        Exceptions.Add(ex);
                    }
                }
                return data + "~" + InproperReports;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GenerateReportWord. Details: " + ex.Message);
            }

        }

        [WebMethod(enableSession: true)]
        public List<NameAndDataValues> GetReportImageURL(string Sections, string Channels, string GrowthChannels, string Direction, int LocStart, int LocEnd, bool AddDataOverLanes, bool FitGrowthRate, string DateFrom, string DateTo, string ReportName, string Description)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<trafficView>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var DAL = new trafficDAL();
            string selSections = Sections.Replace('@', ',');
            DataTable dtdata = DAL.GetDrawreportData(dbMan, Channels, selSections);
            int AccountId = user.AccountID;
            string ParamName = "TrafficProjectedMonth";
            var dbAdmin = new DBWorkerBase(connString);
            DataTable dtGlobalValues = DAL.GetGlobalData(dbAdmin, AccountId, ParamName);
            string ProjectedDate = "";
            if (dtGlobalValues.Rows.Count == 1)
            {
                foreach (DataRow row in dtGlobalValues.Rows)
                {
                    ProjectedDate = row["ParamValue"].ToString();
                }
            }
            else
            {
                string currentYear = DateTime.Now.Year.ToString();
                ProjectedDate = "1/1/" + currentYear;
            }
            var reportRow = new junoViewerVBUtilities.jCollection();
            reportRow["Sections"] = Sections;
            reportRow["Channels"] = Channels;
            reportRow["GrowthChannels"] = GrowthChannels;
            reportRow["Direction"] = Direction;
            reportRow["LocStart"] = LocStart;
            reportRow["LocEnd"] = LocEnd;
            reportRow["AddDataOverLanes"] = AddDataOverLanes;
            reportRow["FitGrowthRate"] = FitGrowthRate;
            reportRow["growthDateFrom"] = DateFrom;
            reportRow["growthDateTo"] = DateTo;
            reportRow["reportName"] = ReportName;
            reportRow["description"] = Description;
            return GetImageURl(dtdata, AddDataOverLanes, reportRow, ProjectedDate);

        }

        /// <summary>
        /// Import TRAC Loop Data
        /// </summary>
        /// <param name="fileURL"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="stationNumber"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public List<string> ImportTRACLoopData(string fileURL, string startDate, string endDate, int stationNumber)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<trafficView>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            string fullPath = Server.MapPath(fileURL); //CSV Path

            //Gets the channels for the selected station number
            trafficStationChannel objTracChannel = new trafficStationChannel();
            List<trafficStationChannel> lstChannels = objTracChannel.GetTrafficStationChannelByStationID(dbMan, stationNumber, "LOOP");

            //List Erros
            List<string> errors = new List<string>();
            TRAC_TrafficHelper objTraf = new TRAC_TrafficHelper();

            if (lstChannels.Count > 0)
            {
                //Gets Data as Data Set
                DataSet dsChannelsData = objTraf.GetHourlyDataFromCSVAsDataSet(dbMan, fullPath, stationNumber, lstChannels, errors);
                if (errors.Count == 0)
                {
                    DateTime stTime;
                    DateTime edTime;
                    //Gets Min and Max Dates if dates are not given
                    if (startDate.Trim() == "" && endDate.Trim() == "")
                    {
                        DateTime minDate = DateTime.Now;
                        DateTime maxDate = DateTime.Now;
                        bool isFirst = true;
                        foreach (DataTable dt in dsChannelsData.Tables)
                        {
                            DataView dv = dt.DefaultView;
                            dv.Sort = "measDate desc";
                            DataTable sortedDT = dv.ToTable();
                            if (isFirst)
                            {
                                maxDate = Convert.ToDateTime(dt.Rows[0]["measDate"]);
                                minDate = Convert.ToDateTime(dt.Rows[dt.Rows.Count - 1]["measDate"]);
                                isFirst = false;
                            }
                            else
                            {
                                if (minDate > Convert.ToDateTime(dt.Rows[0]["measDate"])) { minDate = Convert.ToDateTime(dt.Rows[0]["measDate"]); }
                                if (maxDate < Convert.ToDateTime(dt.Rows[dt.Rows.Count - 1]["measDate"])) { maxDate = Convert.ToDateTime(dt.Rows[dt.Rows.Count - 1]["measDate"]); }
                            }
                        }
                        stTime = minDate;
                        edTime = maxDate;
                    }
                    else
                    {
                        stTime = Convert.ToDateTime(startDate.Trim());
                        edTime = Convert.ToDateTime(endDate.Trim());
                    }

                    //Import TRAC Data Hourly
                    objTraf.ImportHourlyDataFromDataSet(dbMan, dsChannelsData, stationNumber, stTime, edTime);

                    //Import  Daily Traffic Data
                    objTraf.CalculateAndAddDailyTrafficData(dbMan, lstChannels, stationNumber, stTime, edTime);

                    //Import  Monthly Traffic Data
                    objTraf.CalculateAndAddMonthlyTrafficData(dbMan, lstChannels, stationNumber, stTime, edTime);
                }
            }
            else
            {
                errors.Add("Upload data failed, It seems no channels found for the selected stationID.");
            }
            
            return errors;
        }

        /// <summary>
        /// Import TRAC WIM Data
        /// </summary>
        /// <param name="fileURL"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public List<string> ImportTRACWIMData(string fileURL, string sheetName)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<trafficView>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            string fullPath = Server.MapPath(fileURL); //File Path
            TRAC_TrafficHelper objTraf = new TRAC_TrafficHelper();
            List<string> errors = new List<string>();

            //Checks the templates and get the row numbers for the stations
            List<Dictionary<string, int>> stationWithRowNumbers = objTraf.CheckTRACWIMDataAndReturnStations(fullPath, sheetName, errors);
            if (errors.Count() == 0)
            {
                //Import Traffic Monthly data
                objTraf.ImportMonthlyTrafficData(dbMan, fullPath, sheetName, stationWithRowNumbers[0], stationWithRowNumbers[1], errors);
            }
            return errors;
        }

        private List<NameAndDataValues> GetImageURl(DataTable dtdata, bool AddDataOverLanes, junoViewerVBUtilities.jCollection reportRow, string ProjDate)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                var result = new List<NameAndDataValues>();
                if (dtdata.Rows.Count > 0)
                {
                    var dataForReport = new junoViewerVBUtilities.jCollection();
                    if (AddDataOverLanes == true)
                    {
                        var allLaneData = new junoViewerVBUtilities.jCollection();
                        for (int i = 0; i < dtdata.Rows.Count; i++)
                        {
                            int SecID = Convert.ToInt32(dtdata.Rows[i]["sectionID"].ToString());
                            int Loc = Convert.ToInt32(dtdata.Rows[i]["location"].ToString());
                            DateTime dateValdt = Convert.ToDateTime(dtdata.Rows[i]["monthStart"].ToString());
                            string dateVal = dateValdt.ToString("dd-MMM-yyyy");
                            string key = SecID + "-" + Loc + "-" + dateVal;
                            if (allLaneData[key] == null)
                            {
                                var newRow = new junoViewerVBUtilities.jCollection();
                                newRow["channelID"] = dtdata.Rows[i]["ID"].ToString();
                                newRow["statOwner"] = dtdata.Rows[i]["statOwner"].ToString();
                                newRow["statName"] = dtdata.Rows[i]["statName"].ToString();
                                newRow["statNumber"] = dtdata.Rows[i]["statNumber"].ToString();
                                newRow["sectionID"] = SecID;
                                newRow["secName"] = dtdata.Rows[i]["secName"].ToString();
                                newRow["lane"] = "all";
                                newRow["location"] = Loc;
                                newRow["monthStart"] = dtdata.Rows[i]["monthStart"].ToString();
                                newRow["ADT"] = 0;
                                newRow["ADTT"] = 0;
                                newRow["E80perHeavy"] = 0;
                                allLaneData[key] = newRow;
                            }
                        }
                        //Calculating ADT,ADTT and E80perHeavy values based on key for all values.
                        var NewAllLaneData = new junoViewerVBUtilities.jCollection();
                        for (int i = 0; i < allLaneData.Count; i++)
                        {
                            var dataFromAllLane = allLaneData[i].Value as junoViewerVBUtilities.jCollection;
                            var newRow = new junoViewerVBUtilities.jCollection();
                            newRow["channelID"] = dataFromAllLane["channelID"];
                            newRow["statOwner"] = dataFromAllLane["statOwner"];
                            newRow["statName"] = dataFromAllLane["statName"];
                            newRow["statNumber"] = dataFromAllLane["statNumber"];
                            newRow["sectionID"] = dataFromAllLane["sectionID"];
                            newRow["secName"] = dataFromAllLane["secName"];
                            newRow["lane"] = dataFromAllLane["lane"];
                            newRow["location"] = dataFromAllLane["location"];
                            newRow["monthStart"] = dataFromAllLane["monthStart"];
                            var AllLaneKey = allLaneData[i].Key.ToString();
                            var ADT = 0.0;
                            var ADTT = 0.0;
                            var E80perHeavy = 0.0;
                            for (int j = 0; j < dtdata.Rows.Count; j++)
                            {
                                int SecID = Convert.ToInt32(dtdata.Rows[j]["sectionID"].ToString());
                                int Loc = Convert.ToInt32(dtdata.Rows[j]["location"].ToString());
                                DateTime dateValdt = Convert.ToDateTime(dtdata.Rows[j]["monthStart"].ToString());
                                string dateVal = dateValdt.ToString("dd-MMM-yyyy");
                                string key = SecID + "-" + Loc + "-" + dateVal;
                                if (key == AllLaneKey)
                                {
                                    if (dtdata.Rows[j]["ADT"].ToString() != null && dtdata.Rows[j]["ADT"].ToString() != "")
                                    {
                                        ADT = ADT + Convert.ToDouble(dtdata.Rows[j]["ADT"].ToString());
                                    }
                                    if (dtdata.Rows[j]["ADTT"].ToString() != null && dtdata.Rows[j]["ADTT"].ToString() != "")
                                    {
                                        ADTT = ADTT + Convert.ToDouble(dtdata.Rows[j]["ADTT"].ToString());
                                    }
                                    if (dtdata.Rows[j]["E80perHeavy"].ToString() != null && dtdata.Rows[j]["E80perHeavy"].ToString() != "")
                                    {
                                        E80perHeavy = E80perHeavy + Convert.ToDouble(dtdata.Rows[j]["E80perHeavy"].ToString());
                                    }
                                }
                            }
                            newRow["ADT"] = ADT;
                            newRow["ADTT"] = ADTT;
                            newRow["E80perHeavy"] = E80perHeavy;
                            NewAllLaneData[AllLaneKey] = newRow;
                        }
                        //Calculated ADT,ADTT and E80perHeavy values and assigned to dataForReport
                        dataForReport = NewAllLaneData;
                    }
                    else
                    {
                        //If AddDataOverLanes is not true then directly bind the get data.
                        var allLaneData = new junoViewerVBUtilities.jCollection();
                        for (int i = 0; i < dtdata.Rows.Count; i++)
                        {
                            int SecID = Convert.ToInt32(dtdata.Rows[i]["sectionID"].ToString());
                            int Loc = Convert.ToInt32(dtdata.Rows[i]["location"].ToString());
                            DateTime dateValdt = Convert.ToDateTime(dtdata.Rows[i]["monthStart"].ToString());
                            string dateVal = dateValdt.ToString("dd-MMM-yyyy");
                            string key = SecID + "-" + Loc + "-" + dateVal;
                            var newRow = new junoViewerVBUtilities.jCollection();
                            newRow["ID"] = dtdata.Rows[i]["ID"].ToString();
                            newRow["statOwner"] = dtdata.Rows[i]["statOwner"].ToString();
                            newRow["statName"] = dtdata.Rows[i]["statName"].ToString();
                            newRow["statNumber"] = dtdata.Rows[i]["statNumber"].ToString();
                            newRow["sectionID"] = SecID;
                            newRow["secName"] = dtdata.Rows[i]["secName"].ToString();
                            newRow["lane"] = dtdata.Rows[i]["lane"].ToString();
                            newRow["location"] = Loc;
                            newRow["monthStart"] = dtdata.Rows[i]["monthStart"].ToString();
                            newRow["ADT"] = dtdata.Rows[i]["ADT"].ToString();
                            newRow["ADTT"] = dtdata.Rows[i]["ADTT"].ToString();
                            newRow["E80perHeavy"] = dtdata.Rows[i]["E80perHeavy"].ToString();
                            allLaneData[i.ToString()] = newRow;
                        }
                        dataForReport = allLaneData;
                    }
                    string filePath = Server.MapPath("/pages/TRAC/Traffic/ReportTemplates") + "\\TRAC_TrafficView_Report.xlsx";
                    var xlMan = new junoViewerVBUtilities.xlFileHelper(filePath);
                    SpreadsheetGear.IWorksheet xlSheet = xlMan.GetWorksheet("Report");

                    for (int i = xlSheet.Shapes.Count - 1; i >= 0; i += -1)
                    {
                        xlSheet.Shapes[i].Delete();
                    }
                    Bitmap Image = GetGraphImage(dataForReport, "ADT", reportRow, ProjDate);
                    AddGraphToReport(xlSheet, 6, 1, 19, 10, Image);

                    Image = GetGraphImage(dataForReport, "ADTT", reportRow, ProjDate);
                    AddGraphToReport(xlSheet, 20, 1, 33, 10, Image);

                    Image = GetGraphImage(dataForReport, "E80perHeavy", reportRow, ProjDate);
                    AddGraphToReport(xlSheet, 34, 1, 47, 10, Image);

                    Image = GetLegendImage(dataForReport, reportRow);
                    AddGraphToReport(xlSheet, 48, 1, 55.5, 10, Image);
                    xlSheet.Cells[1, 2].Value = reportRow["reportName"];
                    xlSheet.Cells[2, 2].Value = reportRow["description"];
                    if (String.IsNullOrEmpty(reportRow["LocStart"].ToString()) == false)
                    {
                        xlSheet.Cells[3, 2].Value = string.Format("{0:#0.00}", Convert.ToDouble(reportRow["LocStart"]) / 1000);
                        xlSheet.Cells[3, 2].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    if (String.IsNullOrEmpty(reportRow["LocEnd"].ToString()) == false)
                    {
                        xlSheet.Cells[4, 2].Value = string.Format("{0:#0.00}", Convert.ToDouble(reportRow["LocEnd"]) / 1000);
                        xlSheet.Cells[4, 2].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    if (reportRow["projected_ADT"].ToString() == "-999")
                    {
                        xlSheet.Cells[1, 8].Value = "Undetermined";
                        xlSheet.Cells[1, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    else
                    {
                        xlSheet.Cells[1, 8].Value = reportRow["projected_ADT"].ToString();
                        xlSheet.Cells[1, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    if (reportRow["projected_ADTT"].ToString() == "-999")
                    {
                        xlSheet.Cells[2, 8].Value = "Undetermined";
                        xlSheet.Cells[2, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    else
                    {
                        xlSheet.Cells[2, 8].Value = reportRow["projected_ADTT"].ToString();
                        xlSheet.Cells[2, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    if (reportRow["projected_E80perHeavy"].ToString() == "-999")
                    {
                        xlSheet.Cells[3, 8].Value = "Undetermined";
                        xlSheet.Cells[3, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    else
                    {
                        xlSheet.Cells[3, 8].Value = reportRow["projected_E80perHeavy"].ToString();
                        xlSheet.Cells[3, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    }
                    xlSheet.Cells[4, 8].Value = ProjDate.ToString();
                    xlSheet.Cells[4, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Left;
                    SpreadsheetGear.Drawing.Image reportImage = new SpreadsheetGear.Drawing.Image(xlSheet.Cells["A1:K56"]);
                    System.Drawing.Bitmap bmp = new Bitmap(reportImage.GetBitmap());
                    string FileName = "/zz_temp/" + reportRow["LocStart"].ToString() + "_" + reportRow["LocEnd"].ToString() + "_" + System.DateTime.Now.ToString("MM-dd-yyyy") + "_" + System.DateTime.Now.ToString("hh") + System.DateTime.Now.ToString("mm") + System.DateTime.Now.ToString("ss") + ".jpg";
                    string savedFilePath = HttpContext.Current.Server.MapPath("~") + FileName.ToString().Trim();
                    bmp.Save(savedFilePath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    var item = new NameAndDataValues();
                    item.Name = "Url";
                    item.DataValues = FileName;
                    result.Add(item);

                    var item1 = new NameAndDataValues();
                    item1.Name = "projected_ADT";
                    item1.DataValues = reportRow["projected_ADT"].ToString();
                    result.Add(item1);

                    var item2 = new NameAndDataValues();
                    item2.Name = "projected_ADTT";
                    item2.DataValues = reportRow["projected_ADTT"].ToString();
                    result.Add(item2);

                    var item3 = new NameAndDataValues();
                    item3.Name = "projected_E80perHeavy";
                    item3.DataValues = reportRow["projected_E80perHeavy"].ToString();
                    result.Add(item3);

                    var item4 = new NameAndDataValues();
                    item4.Name = "growth_ADT";
                    item4.DataValues = reportRow["growth_ADT"].ToString();
                    result.Add(item4);

                    var item5 = new NameAndDataValues();
                    item5.Name = "growth_ADTT";
                    item5.DataValues = reportRow["growth_ADTT"].ToString();
                    result.Add(item5);

                    var item6 = new NameAndDataValues();
                    item6.Name = "growth_E80perHeavy";
                    item6.DataValues = reportRow["growth_E80perHeavy"].ToString();
                    result.Add(item6);
                    return result;

                }
                else
                {
                    //No data found for selected criteria.
                    var item = new NameAndDataValues();
                    item.Name = "Url";
                    item.DataValues = "";
                    result.Add(item);

                    var item1 = new NameAndDataValues();
                    item1.Name = "projected_ADT";
                    item1.DataValues = "0";
                    result.Add(item1);

                    var item2 = new NameAndDataValues();
                    item2.Name = "projected_ADTT";
                    item2.DataValues = "0";
                    result.Add(item2);

                    var item3 = new NameAndDataValues();
                    item3.Name = "projected_E80perHeavy";
                    item3.DataValues = "0";
                    result.Add(item3);

                    var item4 = new NameAndDataValues();
                    item4.Name = "growth_ADT";
                    item4.DataValues = "0";
                    result.Add(item4);

                    var item5 = new NameAndDataValues();
                    item5.Name = "growth_ADTT";
                    item5.DataValues = "0";
                    result.Add(item5);

                    var item6 = new NameAndDataValues();
                    item6.Name = "growth_E80perHeavy";
                    item6.DataValues = "0";
                    result.Add(item5);
                    return result;

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetImageURl. Details: " + ex.Message);
            }
        }

        private Bitmap GetLegendImage(jCollection data, jCollection reportRow)
        {
            try
            {
                Bitmap Image;
                var Rect = new RectangleF(0, 0, 189, 40);
                var Graph = new junoViewerVBUtilities.clsBitmapCanvas(Rect);
                Graph.SetupBlankCanvas("blackAndWhite");
                Font legFont = junoViewerVBUtilities.clsGoferTools.GetFont("Arial", 10, false);
                Graph.LegendItems = new List<junoViewerVBUtilities.clsLegendInfo>();
                Graph.ShowLegend = true;
                Graph.RemoveLayer(junoViewerVBUtilities.LayerTypeEnum.legends);
                Graph.AddLayer(90, "legend", junoViewerVBUtilities.LayerTypeEnum.legends);
                string[] growthChannelIDs = reportRow["GrowthChannels"].ToString().Split(",".ToCharArray());
                var series = new junoViewerVBUtilities.jCollection();
                for (int i = 0; i < data.Count; i++)
                {
                    var row = data[i].Value as junoViewerVBUtilities.jCollection;
                    bool isUsedInGrowthRate = growthChannelIDs.Contains(row["channelID"]);
                    int sectionID = Convert.ToInt32(row["sectionID"]);
                    Double loc = Convert.ToDouble(row["location"]);
                    string key = row["statOwner"] + "-" + row["statNumber"] + " " + row["secName"] + " (km " + string.Format("{0:#0.00}", loc / 1000) + " " + row["statName"] + ")";
                    if (isUsedInGrowthRate == false)
                    {
                        key = key + " [NOT used in Growth Rate calculation]";
                    }
                    if (series[key] == null)
                    {
                        series[key] = new junoViewerVBUtilities.jCollection();
                    }
                    series[key] = row;
                }
                for (int iSerie = 0; iSerie < series.Count; iSerie++)
                {
                    var seriesData = series[iSerie].Value as junoViewerVBUtilities.jCollection;
                    var firstPt = seriesData as junoViewerVBUtilities.jCollection;
                    int sectionID = Convert.ToInt32(firstPt["sectionID"]);
                    int loc = Convert.ToInt32(firstPt["location"]);
                    string key = series[iSerie].Key.ToString();
                    junoViewerVBUtilities.clsLegendInfo LegItem = new junoViewerVBUtilities.clsLegendInfo(key, junoViewerVBUtilities.DrawingElementTypeEnum.scatterCircle, 3, legFont, getSeriesColour(iSerie), null);
                    if (firstPt["statOwner"].ToString() == "SANRAL")
                    {
                        LegItem = new junoViewerVBUtilities.clsLegendInfo(key, junoViewerVBUtilities.DrawingElementTypeEnum.scatterSquare, 3, legFont, getSeriesColour(iSerie), null);
                    }
                    LegItem.AutoFit = false;
                    Graph.LegendItems.Add(LegItem);
                }
                var legendSet = new junoViewerVBUtilities.deLegendXY(new PointF(5, 5), 170, Graph.LegendItems, null, Color.White, junoViewerVBUtilities.ScaleMethodEnum.none);
                legendSet.Font = junoViewerVBUtilities.clsGoferTools.GetFont("Arial", 10, false);
                Graph.get_Layer("legend").DrawingElements.Add(legendSet);
                return Graph.GetBitmap();
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetImageURl. Details: " + ex.Message);
            }
        }
        private void AddGraphToReport(SpreadsheetGear.IWorksheet xlSheet, Double iRow1, Double iCol1, Double iRow2, Double iCol2, Bitmap report)
        {
            try
            {
                SpreadsheetGear.IWorksheetWindowInfo windowInfo = xlSheet.WindowInfo;
                Double left = windowInfo.ColumnToPoints(iCol1);
                Double top = windowInfo.RowToPoints(iRow1);
                Double right = windowInfo.ColumnToPoints(iCol2);
                Double bottom = windowInfo.RowToPoints(iRow2);
                Double width = right - left;
                Double height = bottom - top;
                MemoryStream outMemStream = new MemoryStream();
                report.Save(outMemStream, System.Drawing.Imaging.ImageFormat.Bmp);
                xlSheet.Shapes.AddPicture(outMemStream.GetBuffer(), left, top, width, height);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddGraphToReport. Details: " + ex.Message);
            }
        }
        private Bitmap GetGraphImage(junoViewerVBUtilities.jCollection dataForReport, string colName, junoViewerVBUtilities.jCollection reportRow, string PDt)
        {
            try
            {
                var Rect = new RectangleF(0, 0, 189, 64);
                var g = new junoViewerVBUtilities.clsBitmapCanvas(Rect);
                g.XAxis.AxisType = "date";
                g.XAxis.Minimum = Convert.ToDateTime("1/1/2000").Ticks;
                g.XAxis.Maximum = Convert.ToDateTime(PDt).Ticks;
                g.XAxis.ShowMaximumTick = true;
                //g.XAxis.Increment = 365;
                g.XAxis.SetAutoIncrement();
                g.XAxis.TickFormatString = "MMM-yy";
                g.XAxis.VerticalLabels = true;
                g.XAxis.UseAutoRange = true;
                //g.XAxis.UseCustomTicks = true;
                g.XTitle = "";
                g.BottomPadding = 20;
                g.TopPadding = 2;
                g.RightPadding = 10;
                g.ColourScheme = "blackAndWhite";
                g.GraphAreaBorderColor = Color.White;
                g.YTitle = colName;
                g.YAxis.Minimum = 0;
                g.RemoveLayer("data");
                g.AddLayer(60, "data", junoViewerVBUtilities.LayerTypeEnum.dataLayer);
                jCollection series = new junoViewerVBUtilities.jCollection();
                jCollection seriesValuesData = new junoViewerVBUtilities.jCollection();
                for (int i = 0; i < dataForReport.Count; i++)
                {
                    var row = dataForReport[i].Value as junoViewerVBUtilities.jCollection;
                    int sectionID = Convert.ToInt32(row["sectionID"]);
                    int loc = Convert.ToInt32(row["location"]);
                    string key = row["statOwner"] + "-" + row["statNumber"] + " (km " + string.Format("{0:#0.00}", loc / 1000) + " " + row["statName"] + ")";
                    if (series[key] == null)
                    {
                        series[key] = new junoViewerVBUtilities.jCollection();
                    }
                    series[key] = row;
                }
                var growthData = new junoViewerVBUtilities.jCollection();
                DateTime growthStartDate = junoViewerVBUtilities.clsGoferTools.ParseDateNoTime(reportRow["growthDateFrom"]);
                DateTime growthEndDate = junoViewerVBUtilities.clsGoferTools.ParseDateNoTime(reportRow["growthDateTo"]);
                string[] growthChannelIDs = reportRow["GrowthChannels"].ToString().Split(",".ToCharArray());
                Double minVal = 9000000000.0;
                Double maxVal = -9000000000.0;
                for (int iSerie = 0; iSerie < series.Count; iSerie++)
                {
                    var seriesData = series[iSerie].Value as junoViewerVBUtilities.jCollection;
                    var firstPt = seriesData as junoViewerVBUtilities.jCollection;
                    int sectionID = Convert.ToInt32(firstPt["sectionID"]);
                    int loc = Convert.ToInt32(firstPt["location"]);
                    string key = series[iSerie].Key.ToString();
                    System.Drawing.Color colour = getSeriesColour(iSerie);
                    for (int iPt = 0; iPt < dataForReport.Count; iPt++)
                    {
                        var point = dataForReport[iPt].Value as junoViewerVBUtilities.jCollection;
                        int psectionID = Convert.ToInt32(point["sectionID"]);
                        int ploc = Convert.ToInt32(point["location"]);
                        string pkey = point["statOwner"] + "-" + point["statNumber"] + " (km " + string.Format("{0:#0.00}", ploc / 1000) + " " + point["statName"] + ")";
                        if (pkey == key)
                        {
                            DateTime measDate = Convert.ToDateTime(point["monthStart"]);
                            string dateTxt = measDate.ToString("MMM-yy");
                            if (point[colName] != "" && point[colName] != null)
                            {
                                Double Y = Convert.ToDouble(point[colName]);
                                if (Y > 0.001)
                                {
                                    if (growthChannelIDs.Contains(point["channelID"]))
                                    {
                                        if (growthStartDate <= measDate && measDate <= growthEndDate)
                                        {
                                            var growthRow = new junoViewerVBUtilities.jCollection();
                                            growthRow["channelID"] = point["channelID"];
                                            growthRow["date"] = measDate;
                                            growthRow["y"] = Y;
                                            growthData.Add(growthRow);
                                        }
                                    }
                                    if (point["statOwner"].ToString() == "SANRAL")
                                    {
                                        junoViewerVBUtilities.deScatterSquare Pt = new junoViewerVBUtilities.deScatterSquare(measDate.Ticks, Y, colour, float.Parse("1.6"), null, null, "left");// new junoViewerVBUtilities.deScatterSquare(measDate.Ticks, Y, colour, 1.6, null, null, "left");
                                        Pt.ToolTip = point["statNumber"] + ": " + dateTxt + "; " + colName + " = " + Y;
                                        g.AddLayerElement("data", Pt);
                                    }
                                    else
                                    {
                                        junoViewerVBUtilities.deScatterCircle Pt = new junoViewerVBUtilities.deScatterCircle(measDate.Ticks, Y, colour, 2, null, null, "left");
                                        Pt.ToolTip = point["statNumber"] + ": " + dateTxt + "; " + colName + " = " + Y;
                                        g.AddLayerElement("data", Pt);
                                    }
                                    minVal = Math.Min(minVal, Y);
                                    maxVal = Math.Max(maxVal, Y);
                                }
                            }
                        }
                    }
                }
                if (Convert.ToBoolean(reportRow["fitGrowthRate"]) == true)
                {
                    AddGrowthRateInformation(reportRow, growthData, growthChannelIDs, g, colName, growthStartDate, growthEndDate);
                }
                else
                {
                    reportRow["growth_" + colName] = -999;
                    reportRow["projected_" + colName] = -999;
                }
                if (maxVal > 100 && maxVal < 1000)
                {
                    maxVal = maxVal + 100;
                }
                else if (maxVal >= 1000)
                {
                    maxVal = maxVal + 500;
                }
                g.YAxis.Minimum = 0;
                g.YAxis.Maximum = maxVal;
                if (maxVal <= 3)
                {
                    g.YAxis.Increment = 0.25;
                }
                else if (maxVal <= 6)
                {
                    g.YAxis.Increment = 0.5;
                }
                else if (maxVal <= 12)
                {
                    g.YAxis.Increment = 1;
                }
                else if (maxVal <= 120)
                {
                    g.YAxis.Increment = 10;
                }
                else if (maxVal <= 600)
                {
                    g.YAxis.Increment = 100;
                }
                else if (maxVal <= 1600)
                {
                    g.YAxis.Increment = 200;
                }
                else if (maxVal <= 3000)
                {
                    g.YAxis.Increment = 200;
                }
                else if (maxVal <= 6000)
                {
                    g.YAxis.Increment = 500;
                }
                else if (maxVal <= 12000)
                {
                    g.YAxis.Increment = 1000;
                }
                else
                {
                    g.YAxis.Increment = 2000;
                }
                return g.GetBitmap();
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetGraphImage. Details: " + ex.Message);
            }
        }

        private void AddGrowthRateInformation(jCollection reportRow, jCollection growthData, string[] growthChannelIDs, junoViewerVBUtilities.clsBitmapCanvas graph, string colName, DateTime growthStartDate, DateTime growthEndDate)
        {
            try
            {
                //clsGoferTools.SortjCollectionByColumnDateTime(growthData, "date");   
                clsGoferTools.SortjCollectionByColumnDateTime(ref growthData, "date");
                Double startPoint = GetStartpoint(growthData, growthStartDate, -999);
                Double growthRate = GetGrowthRate(growthData, growthStartDate, startPoint);
                graph.RemoveLayer("fitted");
                graph.AddLayer(70, "fitted", junoViewerVBUtilities.LayerTypeEnum.undefined);
                graph.get_Layer("fitted").ConnectPoints = true;
                graph.get_Layer("fitted").ConnectionLinePen = new Pen(Color.Black, float.Parse("0.5"));
                DateTime dateVal = growthStartDate;
                while (dateVal < growthEndDate)
                {
                    Double yearDiff = dateVal.Subtract(growthStartDate).TotalDays / 365;
                    Double predVal = startPoint * Math.Pow(1 + growthRate / 100, yearDiff);
                    var Pt = new junoViewerVBUtilities.deScatterCircle(dateVal.Ticks, predVal, Color.Purple, float.Parse("0.02"), null, null, "left");
                    graph.AddLayerElement("fitted", Pt);
                    dateVal = dateVal.AddDays(182);
                }
                graph.RemoveLayer("growth");
                graph.AddLayer(90, "growth", junoViewerVBUtilities.LayerTypeEnum.dataLayer);
                var R = new RectangleF(graph.LeftPadding + 4, graph.TopPadding + 2, 50, 7);
                Font F = junoViewerVBUtilities.clsGoferTools.GetFont("Arial", 10, true);
                string growthTxt = string.Format("{0:#0.0%}", growthRate / 100);
                if (growthRate < -29)
                {
                    growthTxt = "Undetermined";
                }
                if (growthRate > 29)
                {
                    growthTxt = "Greater than 30%";
                }
                if (growthRate > -30)
                {
                    reportRow["growth_" + colName] = growthRate;
                    Double yearDiff = growthEndDate.Subtract(growthStartDate).TotalDays / 365;
                    Double predVal = startPoint * Math.Pow(1 + growthRate / 100, yearDiff);
                    reportRow["projected_" + colName] = Math.Round(predVal, 1);
                }
                else
                {
                    reportRow["growth_" + colName] = -999;
                    reportRow["projected_" + colName] = -999;
                }
                var t = new junoViewerVBUtilities.deTextBox(R, "Growth Rate = " + growthTxt, Color.Black, Color.White, null, F);
                graph.AddLayerElement("growth", t);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddGrowthRateInformation. Details: " + ex.Message);
            }
        }

        private double GetGrowthRate(jCollection allData, DateTime startDate, double startValue)
        {
            try
            {
                Double bestRate = -30;
                Double currentRate = -30;
                Double minErr = 1.0E+31;
                while (currentRate < 30)
                {
                    Double totalErr = GetGrowthRateTotalError(allData, startDate, startValue, currentRate);
                    if (totalErr < minErr)
                    {
                        minErr = totalErr;
                        bestRate = currentRate;
                    }
                    currentRate = currentRate + 0.5;
                }
                return bestRate;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetGrowthRate. Details: " + ex.Message);
            }
        }

        private double GetGrowthRateTotalError(jCollection allData, DateTime startDate, double startValue, double ratePercent)
        {
            try
            {
                Double totalErr = new Double();
                for (int i = 0; i <= allData.Count - 1; i++)
                {
                    var NewData = allData[i].Value as jCollection;
                    DateTime countDate = Convert.ToDateTime(NewData["date"]);
                    if (countDate > startDate)
                    {
                        var daysDiff = countDate.Subtract(startDate).TotalDays;
                        var yearDiff = daysDiff / 365;
                        Double actualValue = Convert.ToDouble(NewData["Y"]);
                        var rateFraction = ratePercent / 100;
                        Double valueAtRate = startValue * Math.Pow(1 + rateFraction, yearDiff);
                        Double err = Math.Abs(valueAtRate - actualValue);
                        totalErr = totalErr + err;
                    }
                }
                return totalErr;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetGrowthRateTotalError. Details: " + ex.Message);
            }
        }

        private double GetStartpoint(jCollection allData, DateTime firstDate, Double lastAvg)
        {
            try
            {
                Double total = 0;
                int kount = 0;
                var loopCount = 0;
                var daysDiffLimit = 60;
                while ((loopCount < 30 && kount == 0))
                {
                    for (int i = 0; i <= allData.Count - 1; i++)
                    {
                        var NewData = allData[i].Value as jCollection;
                        DateTime countDate = Convert.ToDateTime(NewData["date"]);
                        var daysDiff = Math.Abs(firstDate.Subtract(countDate).TotalDays);
                        if (daysDiff < daysDiffLimit)
                        {
                            Double value = Convert.ToDouble(NewData["Y"]);
                            if (lastAvg != -999)
                            {
                                Double diff = Math.Abs(lastAvg - value) / lastAvg;
                                if (diff < 2)
                                {
                                    total = total + value;
                                    kount = kount + 1;
                                }
                                else
                                {
                                    var jj = 9;
                                }
                            }
                            else
                            {
                                total = total + value;
                                kount = kount + 1;
                            }
                        }
                    }
                    loopCount = loopCount + 1;
                    daysDiffLimit = daysDiffLimit + 60;
                }
                var Avg = total / kount;
                if (lastAvg == -999)
                {
                    return GetStartpoint(allData, firstDate, Avg);
                }
                else
                {
                    return Avg;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetStartpoint. Details: " + ex.Message);
            }
        }

        private Color getSeriesColour(int iSerie)
        {
            try
            {
                switch (iSerie)
                {
                    case 0:
                        return Color.Blue;
                    case 1:
                        return Color.Red;
                    case 2:
                        return Color.Green;
                    case 3:
                        return Color.Purple;
                    case 4:
                        return Color.Yellow;
                    case 5:
                        return Color.Pink;
                    default:
                        throw new Exception("Series " + iSerie + " is not handled");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getSeriesColour. Details: " + ex.Message);
            }
        }

        private string getSectionsXmlFormat(string Sections)
        {
            try
            {
                string[] SectionsData = Sections.Split("@".ToCharArray());
                XDocument Secdoc = new XDocument();
                Secdoc.Add(new XElement("sections", SectionsData.Select(x => new XElement("section", x))));
                return Secdoc.ToString().Replace("\r\n", "").ToString().Trim();
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getSectionsXmlFormat. Details: " + ex.Message);
            }
        }
        private string getChannelXmlFormat(string Channels)
        {
            try
            {
                string[] ChannelsData = Channels.Split(",".ToCharArray());
                XDocument Channeldoc = new XDocument();
                Channeldoc.Add(new XElement("channelIDs", ChannelsData.Select(x => new XElement("id", x))));
                return Channeldoc.ToString().Replace("\r\n", "").ToString().Trim();
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getChannelXmlFormat. Details: " + ex.Message);
            }
        }
        private string getGrowthChannelXmlFormat(string GrowthChannels)
        {
            try
            {
                string[] GrowthChannelsData = GrowthChannels.Split(",".ToCharArray());
                XDocument GrowthChannelsdoc = new XDocument();
                GrowthChannelsdoc.Add(new XElement("channelIDs", GrowthChannelsData.Select(x => new XElement("id", x))));
                return GrowthChannelsdoc.ToString().Replace("\r\n", "").ToString().Trim();
            }
            catch (Exception ex)
            {
                throw new Exception("Error in getGrowthChannelXmlFormat. Details: " + ex.Message);
            }
        }
        [WebMethod(enableSession: true)]
        public List<NameAndDataValues> GetRouteSummaryReportImageURL(string Column, string Paramtext, string ReportID)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                var result = new List<NameAndDataValues>();
                UserBAL user = Context.Session["user"] as UserBAL;
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                var DAL = new trafficDAL();
                //DateTime today = DateTime.Parse(ToDate);
                //DateTime endOfMonth = new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month));
                //DataTable dtdata = DAL.GetRouteSummaryReportData(dbMan, endOfMonth);
                string YAxisText;
                if (Paramtext.Contains("Projected"))
                {
                    string ProjectedMonth = GetProjectedMonth();
                    YAxisText = Paramtext + "  to  " + ProjectedMonth;
                }
                else
                {
                    YAxisText = Paramtext;
                }

                DataTable dtdata = DAL.GetRouteSummaryReportData(dbMan, ReportID);
                var AllData = new junoViewerVBUtilities.jCollection();
                var SecLabels = new junoViewerVBUtilities.jCollection();
                int totalLengthEast = 0;
                int totalLengthWest = 0;
                var TempSecLabels = new junoViewerVBUtilities.jCollection();
                for (int i = 0; i < dtdata.Rows.Count; i++)
                {
                    var reportRow = new junoViewerVBUtilities.jCollection();
                    reportRow["ID"] = dtdata.Rows[i]["ID"].ToString();
                    reportRow["reportName"] = dtdata.Rows[i]["reportName"].ToString();
                    reportRow["routePosition"] = dtdata.Rows[i]["routePosition"].ToString();
                    reportRow["description"] = dtdata.Rows[i]["description"].ToString();
                    reportRow["direction"] = dtdata.Rows[i]["direction"].ToString();
                    reportRow["routeStart"] = dtdata.Rows[i]["routeStart"].ToString();
                    reportRow["routeEnd"] = dtdata.Rows[i]["routeEnd"].ToString();
                    reportRow["comment"] = dtdata.Rows[i]["comment"].ToString();
                    reportRow["sectionsXML"] = dtdata.Rows[i]["sectionsXML"].ToString();
                    reportRow["channelsXML"] = dtdata.Rows[i]["channelsXML"].ToString();
                    reportRow["growthChannelsXML"] = dtdata.Rows[i]["growthChannelsXML"].ToString();
                    reportRow["addDataOverLanes"] = dtdata.Rows[i]["addDataOverLanes"].ToString();
                    reportRow["fitGrowthRate"] = dtdata.Rows[i]["fitGrowthRate"].ToString();
                    reportRow["growthDateFrom"] = dtdata.Rows[i]["growthDateFrom"].ToString();
                    reportRow["growthDateTo"] = dtdata.Rows[i]["growthDateTo"].ToString();
                    reportRow["growth_ADT"] = dtdata.Rows[i]["growth_ADT"].ToString();
                    reportRow["growth_ADTT"] = dtdata.Rows[i]["growth_ADTT"].ToString();
                    reportRow["growth_E80perHeavy"] = dtdata.Rows[i]["growth_E80perHeavy"].ToString();
                    reportRow["projected_ADT"] = dtdata.Rows[i]["projected_ADT"].ToString();
                    reportRow["projected_ADTT"] = dtdata.Rows[i]["projected_ADTT"].ToString();
                    reportRow["projected_E80perHeavy"] = dtdata.Rows[i]["projected_E80perHeavy"].ToString();
                    int locFrom = Convert.ToInt32(dtdata.Rows[i]["routeStart"].ToString());
                    int locTo = Convert.ToInt32(dtdata.Rows[i]["routeEnd"].ToString());
                    string secLabel = GetSectionNameFromLabel(dtdata.Rows[i]["reportName"].ToString());
                    if (secLabel.Contains("EN4") == false && secLabel.Contains("N4-6Y") == false)
                    {
                        if (SecLabels[secLabel] == null)
                        {
                            SecLabels[secLabel] = new junoViewerVBUtilities.jCollection();
                            var SecRow = new junoViewerVBUtilities.jCollection();
                            SecRow["x1"] = 9000000000.0;
                            SecRow["x2"] = -9000000000.0;
                            SecLabels[secLabel] = SecRow;
                        }
                        if (dtdata.Rows[i]["direction"].ToString() == "East")
                        {
                            reportRow["xFrom"] = totalLengthEast;
                            totalLengthEast = totalLengthEast + (locTo - locFrom);
                            reportRow["xTo"] = totalLengthEast;
                        }
                        else
                        {
                            reportRow["xFrom"] = totalLengthWest;
                            totalLengthWest = totalLengthWest + (locTo - locFrom);
                            reportRow["xTo"] = totalLengthWest;
                        }
                        if (dtdata.Rows[i]["direction"].ToString() == "East")
                        {
                            for (int j = 0; j < SecLabels.Count; j++)
                            {
                                var point = SecLabels[j].Value as junoViewerVBUtilities.jCollection;
                                if (SecLabels[j].Key.ToString() == secLabel)
                                {
                                    var SecRow = new junoViewerVBUtilities.jCollection();
                                    SecRow["x1"] = Math.Min(Convert.ToDouble(reportRow["xFrom"]), Convert.ToDouble(point["x1"]));
                                    SecRow["x2"] = Math.Max(Convert.ToDouble(reportRow["xTo"]), Convert.ToDouble(point["x2"]));
                                    SecLabels[secLabel] = SecRow;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        reportRow["xFrom"] = 0;
                        reportRow["xTo"] = 0;
                    }
                    AllData[i.ToString()] = reportRow;
                }
                int routeLength = Math.Max(totalLengthEast, totalLengthWest);
                var Rect = new RectangleF(0, 0, 330, 180);
                var g = new junoViewerVBUtilities.clsBitmapCanvas(Rect);
                g.XAxis.AxisType = "number";
                g.XAxis.Minimum = 0;
                g.XAxis.Maximum = routeLength;
                g.XAxis.Increment = 5000;
                g.XAxis.VerticalLabels = true;
                g.ShowXAxis = false;
                g.XTitle = "";
                g.BottomPadding = 5;
                g.TopPadding = 5;
                g.RightPadding = 5;
                g.LeftPadding = 30;
                g.ColourScheme = "blackAndWhite";
                g.GraphAreaBorderColor = Color.White;
                //g.YTitle = Paramtext + " to " + Durationtext;
                g.YTitle = YAxisText;
                g.YAxis.Minimum = 0;
                g.YTitleFont = clsGoferTools.GetFont("Arial", 13, true);
                g.YAxis.Font = clsGoferTools.GetFont("Arial", 11, false);
                g.RemoveLayer("data");
                g.AddLayer(60, "data", junoViewerVBUtilities.LayerTypeEnum.dataLayer);
                g.RemoveLayer("labels");
                g.AddLayer(65, "labels", junoViewerVBUtilities.LayerTypeEnum.dataLayer);
                FormatGraphAxis(Column, g);
                Font dataLabelFont = clsGoferTools.GetFont("Arial", 10, false);
                double maxVal = -999;
                for (int iPt = 0; iPt < AllData.Count; iPt++)
                {
                    var row = AllData[iPt].Value as junoViewerVBUtilities.jCollection;
                    double X1 = Convert.ToDouble(row["xFrom"]);
                    double X2 = Convert.ToDouble(row["xTo"]);
                    double Y1 = 0;
                    string direction = row["direction"].ToString();
                    double Y2 = Convert.ToDouble(row[Column]);
                    string txt = "";
                    if ((X2 - X1 > 10000))
                    {
                        if (Column == "projected_ADT")
                        {
                            txt = string.Format("{0:#0}", Y2);
                        }
                        else if (Column == "projected_ADTT")
                        {
                            txt = string.Format("{0:#0}", Y2);
                        }
                        else if (Column == "projected_E80perHeavy")
                        {
                            txt = string.Format("{0:#0.0}", Y2);
                        }
                        else if (Column == "growth_ADT")
                        {
                            txt = string.Format("{0:#0.0}", Y2);
                        }
                        else if (Column == "growth_ADTT")
                        {
                            txt = string.Format("{0:#0.0}", Y2);
                        }
                        else
                        {
                            txt = string.Format("{0:#0.0}", Y2);
                        }

                    }
                    if (Y2 > 0)
                    {
                        if (direction == "West")
                        {
                            Y2 = -1 * Y2;
                        }
                        junoViewerVBUtilities.deDataBlock Pt = new junoViewerVBUtilities.deDataBlock(X1, X2, Y1, Y2, Color.SteelBlue, txt, dataLabelFont);
                        g.AddLayerElement("data", Pt);
                        if (Math.Abs(Y2) > maxVal)
                        {
                            maxVal = Math.Abs(Y2);
                        }
                    }
                }
                Pen tPen = new Pen(Color.Blue, float.Parse("0.4"));
                tPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

                Font labelFont = clsGoferTools.GetFont("Arial", 10, false);
                for (int i = 0; i < SecLabels.Count; i++)
                {
                    var row = SecLabels[i].Value as junoViewerVBUtilities.jCollection;
                    string label = SecLabels[i].Key.ToString();
                    double X1 = Convert.ToDouble(row["x1"]);
                    double X2 = Convert.ToDouble(row["x2"]);
                    junoViewerVBUtilities.deDataBlock lbl = new junoViewerVBUtilities.deDataBlock(X1, X2, g.YAxis.Maximum, g.YAxis.Maximum - g.YAxis.Increment, Color.Transparent, label, labelFont);
                    lbl.ShowLeftAndRightBorders = false;
                    g.AddLayerElement("labels", lbl);
                    junoViewerVBUtilities.deLineElement line = new junoViewerVBUtilities.deLineElement(float.Parse(X2.ToString()), float.Parse(g.YAxis.Maximum.ToString()), float.Parse(X2.ToString()), float.Parse(g.YAxis.Minimum.ToString()), tPen, junoViewerVBUtilities.ScaleMethodEnum.axisScales);
                    g.AddLayerElement("labels", line);

                }

                Font labelFont2 = clsGoferTools.GetFont("Arial", 13, true);
                PointF lblPt = new PointF(50, 20);
                junoViewerVBUtilities.deTextBox lblDir1 = new junoViewerVBUtilities.deTextBox(lblPt, "Eastbound Direction", Color.Black, Color.White, null, labelFont2, junoViewerVBUtilities.ScaleMethodEnum.plotAreaPercentages);
                g.AddLayerElement("labels", lblDir1);

                lblPt = new PointF(50, 80);
                junoViewerVBUtilities.deTextBox lblDir2 = new junoViewerVBUtilities.deTextBox(lblPt, "Westbound Direction", Color.Black, Color.White, null, labelFont2, junoViewerVBUtilities.ScaleMethodEnum.plotAreaPercentages);
                g.AddLayerElement("labels", lblDir2);

                Pen tPen2 = new Pen(Color.WhiteSmoke, float.Parse("0.4"));
                junoViewerVBUtilities.deLineElement midLine = new junoViewerVBUtilities.deLineElement(float.Parse(g.XAxis.Minimum.ToString()), float.Parse("0"), float.Parse(g.XAxis.Maximum.ToString()), float.Parse("0"), tPen2, junoViewerVBUtilities.ScaleMethodEnum.axisScales);
                g.AddLayerElement("labels", midLine);
                System.Drawing.Bitmap bmp = new Bitmap(g.GetBitmap());
                //string FileName = "ViewRouteSummary/" + Paramtext + "_" + Durationtext + "_" + System.DateTime.Now.ToString("MM-dd-yyyy") + "_" + System.DateTime.Now.ToString("hh") + System.DateTime.Now.ToString("mm") + System.DateTime.Now.ToString("ss") + ".jpg";
                string FileName = "/zz_temp/" + Paramtext + "_" + System.DateTime.Now.ToString("MM-dd-yyyy") + "_" + System.DateTime.Now.ToString("hh") + System.DateTime.Now.ToString("mm") + System.DateTime.Now.ToString("ss") + ".jpg";
                string savedFilePath = HttpContext.Current.Server.MapPath("~") + FileName.ToString().Trim();
                bmp.Save(savedFilePath, System.Drawing.Imaging.ImageFormat.Jpeg);

                var item = new NameAndDataValues();
                item.Name = "Url";
                item.DataValues = FileName;
                result.Add(item);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetRouteSummaryReportImageURL. Details: " + ex.Message);
            }

        }

        [WebMethod(enableSession: true)]
        public List<clsgrowthrate> GetGrowthRatesByParameter(string ReportID, string Parameter)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            var result = new List<clsgrowthrate>();
            UserBAL user = Context.Session["user"] as UserBAL;
            string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            var dbMan = new DBWorkerBase(user.GetConnectionString());
            var DAL = new trafficDAL();
            DataTable dtdata = DAL.GetGrowthRatesByParameter(dbMan, Parameter, ReportID);
            Double Avg = 0;
            Double TotalAvg = 0;
            Double MinVal = 0;
            Double MaxVal = 0;
            if (dtdata.Rows.Count > 0)
            {
                Avg = Convert.ToDouble(dtdata.Compute("sum(GrowthParam)", ""));
                MinVal = Convert.ToDouble(dtdata.Compute("min(GrowthParam)", ""));
                MaxVal = Convert.ToDouble(dtdata.Compute("max(GrowthParam)", ""));
                TotalAvg = Avg / dtdata.Rows.Count;
            }

            for (int i = 0; i < dtdata.Rows.Count; i++)
            {
                var item = new clsgrowthrate();
                //item.StationName = dtdata.Rows[i]["StatName"].ToString();
                item.ReportName = dtdata.Rows[i]["reportName"].ToString();
                item.GrowthParam = Math.Round(Convert.ToDouble(dtdata.Rows[i]["GrowthParam"].ToString()), 1).ToString();
                item.GrowthAvg = Math.Round(TotalAvg, 1).ToString();
                item.GrowthMax = Math.Round(MaxVal, 1).ToString();
                item.GrowthMin = Math.Round(MinVal, 1).ToString();
                result.Add(item);
            }
            return result;
        }

        /// <summary>
        /// Get's Traffic stations
        /// </summary>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public DataTable GetTrafficStations(int userID)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                UserBAL user = objUserDAL.GetUser(userID);

                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    DataTable dtdata = DAL.GetTrafficStations(dbMan);
                    return dtdata;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficStations. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Get's Traffic station channels
        /// </summary>
        [WebMethod(enableSession: true)]
        public DataTable GetTrafficChannels(int userID)
        {
            try
            {
                junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                UserBAL user = objUserDAL.GetUser(userID);

                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    DataTable dtdata = DAL.GetTrafficChannels(dbMan);
                    return dtdata;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficStationsChannels. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the Traffic Stations Data.
        /// </summary>
        [WebMethod(enableSession: true)]
        public trafficStation GetTrafficStationsData()
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    DataTable dtdata = DAL.GetTrafficStations(dbMan);
                    DataTable activeTableData = dtdata.AsEnumerable()
                                                .Where(r => r.Field<bool>("isActive") == true)
                                                .CopyToDataTable();
                    Array data = Array.CreateInstance(typeof(Array), activeTableData.Rows.Count);
                    int i = 0;
                    foreach (DataRow tstation in activeTableData.Rows)
                    {
                        if (Convert.ToInt32(tstation["isActive"]) == 1)
                        {
                            string imgPath = Convert.ToString(tstation["imagePath"] != System.DBNull.Value ? tstation["imagePath"] : "");
                            string imgHtml = "";
                            if (imgPath != "") { imgHtml = "<img src='" + imgPath + "' style='width:50px;' onClick='manageTrafficStations.showImage(this)'>"; }
                            string[] tableData = { tstation["ID"].ToString(), tstation["statNumber"].ToString(), tstation["statCode"].ToString(), tstation["statName"].ToString(), tstation["statOwner"].ToString(), tstation["statClass"].ToString(), tstation["statType"].ToString(), imgHtml, tstation["comment"].ToString(), imgPath };
                            data.SetValue(tableData, i);
                            i++;
                        }
                    }
                    var result = new trafficStation();
                    result.TableData = data;
                    result.trafficStations = HelperMethods.ToList<trafficStation>(activeTableData);
                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficStationsData. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the Traffic Stations Channel Data for selected station ID.
        /// </summary>
        [WebMethod(enableSession: true)]
        public trafficStationChannel GetTrafficStationsChannelsData(int stationID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    DataTable dtdata = DAL.GetTrafficChannels(dbMan, stationID);
                    Array data = Array.CreateInstance(typeof(Array), dtdata.Rows.Count);
                    int i = 0;
                    foreach (DataRow tstation in dtdata.Rows)
                    {
                        string[] tableData = { tstation["ID"].ToString(), tstation["channelCode"].ToString(), tstation["secName"].ToString(), tstation["location"].ToString(), tstation["lane"].ToString(), tstation["sectionLabel1"].ToString(), tstation["sectionLabel2"].ToString(), tstation["networkID"].ToString() };
                        data.SetValue(tableData, i);
                        i++;

                    }
                    var result = new trafficStationChannel();
                    result.TableData = data;
                    result.trafficStationChannels = HelperMethods.ToList<trafficStationChannel>(dtdata);
                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficStationsChannelsData. Details: " + ex.Message);
            }

        }

        /// <summary>
        ///Get the Traffic Stations Data for selected section ID
        /// </summary>
        [WebMethod(enableSession: true)]
        public List<trafficStationChannel> GetTrafficStationsDataBySection(int sectionID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    return DAL.GetTrafficStationsDataBySection(dbMan, sectionID);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTrafficStationsDataBySection. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Checks for the unique station number
        /// </summary>
        [WebMethod(enableSession: true)]
        public bool CheckTrafficStationUniqueByNumber(int stationNumber, string stationType)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    DataTable dtStation = DAL.CheckTrafficStationByNumber(dbMan, stationNumber, stationType);
                    if (dtStation.Rows.Count > 0)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in CheckTrafficStationUniqueByNumber. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Add's new Traffic Station
        /// </summary>
        [WebMethod(enableSession: true)]
        public int AddNewTrafficStation(trafficStation newStation, string imgData)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    newStation.startDate = null;
                    newStation.endDate = null;
                    if (imgData != "")
                    {
                        string base64 = imgData.Split(',')[1].Trim();
                        string imgType = imgData.Split(',')[0].Trim().Split(';')[0].Split('/')[1].Trim();
                        var bytes = Convert.FromBase64String(base64);
                        string fileName = Guid.NewGuid().ToString() + "." + imgType;
                        string userDirectory = HttpContext.Current.Server.MapPath("/userUploads/" + user.UploadFolder + "/StationImages");
                        if (!Directory.Exists(userDirectory))
                        {
                            Directory.CreateDirectory(userDirectory);
                        }
                        userDirectory = userDirectory + "\\" + fileName;
                        string url = "/userUploads/" + user.UploadFolder + "/StationImages/" + fileName;

                        using (var imageFile = new FileStream(userDirectory, FileMode.Create))
                        {
                            imageFile.Write(bytes, 0, bytes.Length);
                            imageFile.Flush();
                        }
                        newStation.imagePath = url;

                    }
                    newStation.updatedDate = DateTime.Now;
                    return DAL.AddNewTrafficStation(dbMan, newStation);
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddNewTrafficStationChannel. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Updates Traffic Station
        /// </summary>
        [WebMethod(enableSession: true)]
        public bool UpdateTrafficStation(trafficStation newStation, string imgData)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    newStation.startDate = null;
                    newStation.endDate = null;
                    if (imgData != "")
                    {
                        string base64 = imgData.Split(',')[1].Trim();
                        string imgType = imgData.Split(',')[0].Trim().Split(';')[0].Split('/')[1].Trim();
                        var bytes = Convert.FromBase64String(base64);
                        string fileName = Guid.NewGuid().ToString() + "." + imgType;
                        string userDirectory = HttpContext.Current.Server.MapPath("/userUploads/" + user.UploadFolder + "/StationImages");
                        if (!Directory.Exists(userDirectory))
                        {
                            Directory.CreateDirectory(userDirectory);
                        }
                        userDirectory = userDirectory + "\\" + fileName;
                        string url = "/userUploads/" + user.UploadFolder + "/StationImages/" + fileName;
                        using (var imageFile = new FileStream(userDirectory, FileMode.Create))
                        {
                            imageFile.Write(bytes, 0, bytes.Length);
                            imageFile.Flush();
                        }
                        newStation.imagePath = url;

                    }
                    newStation.updatedDate = DateTime.Now;
                    return DAL.UpdateTrafficStation(dbMan, newStation);

                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateTrafficStation. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Add's New Traffic Station Channel
        /// </summary>
        [WebMethod(enableSession: true)]
        public int AddNewTrafficStationChannel(trafficStationChannel newStationChannel)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    newStationChannel.updatedDate = DateTime.Now;
                    return DAL.AddNewTrafficStationChannel(dbMan, newStationChannel);



                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddNewTrafficStationChannel. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Updates Selected Traffic Station Channel
        /// </summary>
        [WebMethod(enableSession: true)]
        public bool UpdateTrafficStationChannel(trafficStationChannel stationChannelToUpdate)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    stationChannelToUpdate.updatedDate = DateTime.Now;
                    return DAL.UpdateTrafficStationChannel(dbMan, stationChannelToUpdate);
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateTrafficStationChannel. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Delete Selected Traffic Station Channel
        /// </summary>
        [WebMethod(enableSession: true)]
        public int DeleteTrafficStationChannel(int channelID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUserDAL = new junoViewerLib.DAL.UserDAL(dbAdmin);
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                if (user != null)
                {
                    var dbMan = new DBWorkerBase(user.GetConnectionString());
                    var DAL = new trafficDAL();
                    List<int> channelIDs = new List<int>();
                    channelIDs.Add(channelID);
                    return DAL.DeleteTrafficStationChannel(dbMan, channelIDs);
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in DeleteTrafficStationChannel. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// check the sheet and traffic data
        /// </summary>
        /// <param name="networkID"></param>
        /// <param name="fileName"></param>
        /// <param name="sheetName"></param>    
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public List<string> CheckAndAddTrafficData(int networkID, int sectionID, int stationID, string fileName, string sheetName)
        {

            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;

                //Get connection to the user's database
                string connString = user.GetConnectionString();
                var dbMan = new DBWorkerBase(connString);


                connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);

                var netDefDAL = new NetworkDefinitionDAL();
                //var exceptionImportDAL = new ExceptionSitesDAL(dbMan);
                //string filePath = Server.MapPath("/userUploads/" + user.UploadFolder) + "\\" + fileName;
                //string sourceFileName = "HourTrafficDataExportTemplate.xlsx";
                //sourceFileName = Server.MapPath("/userUploads/" + user.UploadFolder) + "\\Templates\\" + sourceFileName;
                List<string> errors = new List<string>();
                //string userName = user.userName;
                ////Check the unique combination of data is empty or not
                //List<string> error = exceptionImportDAL.CheckNullValuesFultonHoganNZExceptionsSegments(filePath, sheetName, networkID, errors, sourceFileName);
                //List<clsExceptionSitesBAL> fultonHoganNZExceptions = null;
                //if (errors.Count == 0)
                //{   //get the values from selected excell and assign to list object
                //    fultonHoganNZExceptions = exceptionImportDAL.GetFultonHoganNZExceptionsSegments(filePath, sheetName, networkID, errors, dateFormat, userName, addTag);
                //}
                ////Check FultonHoganNZExceptions For Errors
                //if (errors.Count == 0)
                //{
                //    error = exceptionImportDAL.GetFultonHoganNZExceptions(networkID, fultonHoganNZExceptions, errors);
                //}
                //if (errors.Count == 0)
                //{
                //    error = exceptionImportDAL.AddFultonHoganNZExceptions(fultonHoganNZExceptions, networkID, user.AccountID, dbAdmin, dateFormat, errors);
                //    if (error.Count == 0)
                //    {
                //        return new List<string>();
                //    }
                //    else
                //    {
                //        errors.Add("Failed To Import FultonHoganNZExceptions Types");
                //    }
                //}
                return errors;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in CheckAndImportFultonHoganNZExceptions Service. Details: " + ex.Message);
            }
        }

        private void FormatGraphAxis(string colName, clsBitmapCanvas g)
        {
            switch (colName)
            {
                case "projected_ADT":
                    g.YAxis.Maximum = 24000;
                    g.YAxis.Increment = 2000;
                    g.YAxis.TickFormatString = "#0";
                    break;
                case "projected_ADTT":
                    g.YAxis.Maximum = 2200;
                    g.YAxis.Increment = 200;
                    g.YAxis.TickFormatString = "#0";
                    break;
                case "projected_E80perHeavy":
                    g.YAxis.Maximum = 5;
                    g.YAxis.Increment = 0.5;
                    g.YAxis.TickFormatString = "#0.0";
                    break;
                case "growth_ADT":
                    g.YAxis.Maximum = 8;
                    g.YAxis.Increment = 0.5;
                    g.YAxis.TickFormatString = "#0.0";
                    break;
                case "growth_ADTT":
                    g.YAxis.Maximum = 20;
                    g.YAxis.Increment = 2;
                    g.YAxis.TickFormatString = "#0.0";
                    break;
                default:
                    g.YAxis.Maximum = 8;
                    g.YAxis.Increment = 0.5;
                    g.YAxis.TickFormatString = "#0.0";
                    break;
            }
            g.YAxis.Minimum = g.YAxis.Maximum * -1;
        }

        private string GetSectionNameFromLabel(string reportName)
        {
            try
            {
                for (int i = 1; i < 11; i++)
                {
                    reportName = reportName.Replace("Part " + i, "");
                }
                reportName = reportName.Replace("East", "");
                reportName = reportName.Replace("West", "");
                return reportName;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}

