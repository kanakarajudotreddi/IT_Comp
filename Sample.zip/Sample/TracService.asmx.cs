﻿using junoViewerLib.BAL;
using junoViewerLib.DAL;
using junoViewerLib.Utils;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace JunoViewer_Web.webServices
{
    /// <summary>
    /// Summary description for TracService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class TracService : System.Web.Services.WebService
    {

        /// <summary>
        /// Get the accidents and incidents data
        /// </summary>
        /// <param name="networkID"></param>
        /// <param name="secLabel1"></param>
        /// <param name="secLabel2"></param>
        /// <param name="sectionId"></param>
        /// <param name="optionType"></param>
        /// <param name="reportType"></param>
        /// <param name="showOnlyFurnitureDamaged"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public Array GetAccidentsAndIncidents(int networkID, string secLabel1, string secLabel2, int sectionId, string optionType, string reportType, bool showOnlyFurnitureDamaged)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;

                //Connection and user details
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUser = new junoViewerLib.DAL.UserDAL(dbAdmin);


                //Get connection to the user's database
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                clsAccidentsAndIncidentsDAL objDal = new clsAccidentsAndIncidentsDAL(dbMan);
                List<clsAccidentsAndIncidentsBAL> lstAccidentsAndIncidentsData = objDal.GeAccidentsAndIncidentsData(networkID, secLabel1, secLabel2, sectionId, optionType, reportType, showOnlyFurnitureDamaged);
                Array data = Array.CreateInstance(typeof(Array), lstAccidentsAndIncidentsData.Count);
                int i = 0;
                foreach (var objAccidentsAndIncidentsData in lstAccidentsAndIncidentsData)
                {
                    string[] tableData = { objAccidentsAndIncidentsData.ID.ToString(),objAccidentsAndIncidentsData.sectionID.ToString(), objAccidentsAndIncidentsData.sector == null ? "" : objAccidentsAndIncidentsData.sector.ToString(), objAccidentsAndIncidentsData.kmsTravelled.ToString(), objAccidentsAndIncidentsData.reportedBy.ToString(), objAccidentsAndIncidentsData.name == null ? "" : objAccidentsAndIncidentsData.name.ToString(), objAccidentsAndIncidentsData.action == null ? "" : objAccidentsAndIncidentsData.action.ToString(), objAccidentsAndIncidentsData.helpDeskRef == null ? "" : objAccidentsAndIncidentsData.helpDeskRef.ToString(), objAccidentsAndIncidentsData.patrolVehicleRegNo == null ? "" : objAccidentsAndIncidentsData.patrolVehicleRegNo.ToString(), objAccidentsAndIncidentsData.location == null ? "" : objAccidentsAndIncidentsData.location.ToString(), objAccidentsAndIncidentsData.isRoadFurnitureDamaged.ToString() };
                    data.SetValue(tableData, i);
                    i++;
                }
                objUser.InsertUserLogData(user.ID, user.AccountID, "Get the Accident or Incident data");
                return data;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetAccidentsAndIncidents. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Gets the quantity and cost for the Road Furniture by accidentID.
        /// </summary>
        [WebMethod(enableSession: true)]
        public clsRoadFurniture GetQuantityAndCostForRoadFurniture(int accidentID)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                //Get connection to the user's database
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                clsAccidentsAndIncidentsDAL objDal = new clsAccidentsAndIncidentsDAL(dbMan);
                return objDal.GetQuantityAndCostForRoadFurniture(accidentID);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetQuantityAndCostForRoadFurniture. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Saves the furniture cost data for the selected AccidentID
        /// </summary>
        /// <param name="accidentID"></param>
        /// <param name="furnitureData"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public int SaveFurnitureCost(int accidentID, clsRoadFurniture furnitureData)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;
                //Get connection to the user's database
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                clsAccidentsAndIncidentsDAL objDal = new clsAccidentsAndIncidentsDAL(dbMan);
                return objDal.SaveFurnitureCost(accidentID, furnitureData);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in SaveFurnitureCost. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Download the Accidents and Incidents Data
        /// </summary>
        /// <param name="networkID"></param>
        /// <param name="secLabel1"></param>
        /// <param name="secLabel2"></param>
        /// <param name="sectionId"></param>
        /// <param name="optionType"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        [WebMethod(enableSession: true)]
        public string ExportAccidentsAndIncidentsData(int networkID, string secLabel1, string secLabel2, int sectionId, string optionType, string reportType)
        {
            junoViewerLib.Utils.HelperMethods.CheckUserLoggedSession();
            try
            {
                var user = Session["user"] as junoViewerLib.BAL.UserBAL;

                //Connection and user details
                string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
                var dbAdmin = new DBWorkerBase(connString);
                junoViewerLib.DAL.UserDAL objUser = new junoViewerLib.DAL.UserDAL(dbAdmin);


                string exportFileName = "";
                if (reportType.Equals("Accident"))
                {
                    exportFileName = "Accidents_" + user.FullName + "_" + HelperMethods.GetRandomNumberOnDate() + ".xlsx";
                }
                else
                {
                    exportFileName = "Incidents_" + user.FullName + "_" + HelperMethods.GetRandomNumberOnDate() + ".xlsx";
                }


                string filePath = Server.MapPath("/zz_temp/") + "\\" + exportFileName;
                File.Delete(filePath);
                //Get connection to the user's database                
                var dbMan = new DBWorkerBase(user.GetConnectionString());
                clsAccidentsAndIncidentsDAL objDal = new clsAccidentsAndIncidentsDAL(dbMan);
                List<clsAccidentsAndIncidentsBAL> accidentsAndIncidentsData;
                accidentsAndIncidentsData = objDal.GeAccidentsAndIncidentsData(networkID, secLabel1, secLabel2, sectionId, optionType, reportType);
                bool exportResult = false;
                if (reportType.Equals("Accident"))
                {
                    exportResult = objDal.ExportAccidentsAndIncidentsData(accidentsAndIncidentsData, filePath, "Accidents");
                }
                else
                {
                    exportResult = objDal.ExportAccidentsAndIncidentsData(accidentsAndIncidentsData, filePath, "Incidents");
                }
                objUser.InsertUserLogData(user.ID, user.AccountID, "Download the Accident or Incident data from db to excell");
                if (exportResult)
                {
                    return "/zz_temp/" + exportFileName;
                }
                else
                {
                    return "error";
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExportAccidentsAndIncidentsData Service. Details: " + ex.Message);
            }
        }

    }
}
