﻿/// <reference path="juno_utils-2-0.js" />

//#region Checklist Box

var junoCheck = {};

junoCheck.addCheckListItem = function ($lstBoxDiv, itemText, checkboxID, checkedState, checkboxName, checkboxValue, clickHandler) {
    ///<summary>Adds a checklist item to a div = $lstBoxDiv. Note: to handle item click, set value of junoCheck.checkListItemClickHandler. This handler should take arguments (dataID, dataText, checked)</summary>
    $lstBoxDiv.append("<label class='checkbox'> <input type='checkbox' id='" + checkboxID + "' name='" + checkboxName + "' value='" + checkboxValue + "'/> " + itemText + " </label>");
    var $chkBox = $("#" + checkboxID);
    ju.setCheckBoxChecked($chkBox, checkedState);
    if (clickHandler) { $chkBox.click(clickHandler) };
    return $chkBox;
}

junoCheck.addLabelListItem = function ($lstBoxDiv, itemText, checkboxID, checkedState, checkboxName, checkboxValue, clickHandler) {
    ///<summary>Adds a checklist item to a div = $lstBoxDiv. Note: to handle item click, set value of junoCheck.checkListItemClickHandler. This handler should take arguments (dataID, dataText, checked)</summary>
    $lstBoxDiv.append("<label id='" + checkboxID + "' name='" + checkboxName + "' /> " + itemText + " </label>");
    var $chkBox = $("#" + checkboxID);   
    return $chkBox;
}

junoCheck.resetBackgroundColours = function ($lstBoxDiv) {
    var colour = $lstBoxDiv.css("background-color");
    $lstBoxDiv.children().each(function () {
        $(this).css("background-color", colour);
    });
}

junoCheck.setCheckBoxBackgroundColour = function ($chkBox, colour, resetOthers) {
    if (resetOthers === true) { junoCheck.resetBackgroundColours($chkBox.parent().parent()) };
    $chkBox.parent().css("background-color", colour);
}

junoCheck.getAllCheckedItems = function ($lstBoxDiv) {
    ///<summary>Gets array of info objects for all checked items. Each object has properties id, value, name and text</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();        
        var checked = $chkBox.prop("checked");
        if (checked) {
            var info = { id: $chkBox.attr("id"), value: $chkBox.attr("value"), name: $chkBox.attr("name"), text: $(this).text() };
            checkedItems.push(info);
        }
    });
    return checkedItems;
}

junoCheck.removeCheckedItems = function ($lstBoxDiv) {
    ///<summary>Removes all checked items</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        var checked = $chkBox.prop("checked");
        if (checked) {
            $(this).remove();
        }
    });
    return checkedItems;
}

junoCheck.removeAllItems = function ($lstBoxDiv) {
    ///<summary>Removes all items from given DIV</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        $(this).remove();
    });
}

junoCheck.removeItemByValue = function ($lstBoxDiv,value) {
    ///<summary>Removes all items from given DIV</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        var itemValue = $chkBox.attr("value");
        if (itemValue == value) {
            $(this).remove();
        }
    });
}

junoCheck.CheckItemByValue = function ($lstBoxDiv, value) {
    ///<summary>Removes all items from given DIV</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        var itemValue = $chkBox.attr("value");
        if (itemValue == value) {
            $chkBox.prop("checked", true);
        }
    });
}

junoCheck.UnCheckItemByValue = function ($lstBoxDiv, value) {
    ///<summary>Removes all items from given DIV</summary>
    var checkedItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        var itemValue = $chkBox.attr("value");
        if (itemValue == value) {
            $chkBox.prop("checked", false);
        }
    });
}

junoCheck.getAllItems = function ($lstBoxDiv) {
    ///<summary>Gets array of info objects for all items (checked or not). Each object has properties id, value, name and text</summary>
    var allItems = new Array();
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        var info = { id: $chkBox.attr("id"), value: $chkBox.attr("value"), name: $chkBox.attr("name"), text: $(this).text() };
        allItems.push(info);                   
    });
    return allItems;
}

junoCheck.setAllItemsCheckState = function ($lstBoxDiv, checkState) {    
    $lstBoxDiv.children().each(function () {
        var $chkBox = $(this).children();
        $chkBox.prop("checked", checkState);        
    });    
}

junoCheck.checkSomeItemsByValue = function ($lstBoxDiv, valuesToCheck) {
    junoCheck.setAllItemsCheckState($lstBoxDiv, false); //first un-check all items
    if (valuesToCheck) {
        $lstBoxDiv.children().each(function () {
            var $chkBox = $(this).children();
            var itemValue = $chkBox.attr("value");
            var found = false;
            var i = 0;
            do {
                if (itemValue == valuesToCheck[i]) {
                    found = true
                    $chkBox.prop("checked", true);
                }
                else if (i >= valuesToCheck.length - 1) {
                    found = true
                };
                i++;
            } while (found == false);
        });
    }    
}

junoCheck.checkSomeItems = function ($lstBoxDiv, labelsToCheck) {
    junoCheck.setAllItemsCheckState($lstBoxDiv, false); //first un-check all items
    if (labelsToCheck) {
        $lstBoxDiv.children().each(function () {
            var $chkBox = $(this).children();
            var itemText = $(this).text();
            var found = false;
            var i = 0;
            do {
                if (itemText == labelsToCheck[i]) {
                    found = true
                    $chkBox.prop("checked", true);
                }
                else if (i >= labelsToCheck.length - 1) {
                    found = true
                };
                i++;
            } while (found == false);
        });
    }
}

junoCheck.checkSomeDateItems = function ($lstBoxDiv, labelsToCheck) {
    junoCheck.setAllItemsCheckState($lstBoxDiv, false); //first un-check all items
    if (labelsToCheck) {
        $lstBoxDiv.children().each(function () {
            var $chkBox = $(this).children();
            var itemText = $(this).text();
            var found = false;
            var i = 0;
            do {
                if ($(this)[0].outerHTML.indexOf(labelsToCheck[i]) > 0) {
                    if ($chkBox.val().trim() == labelsToCheck[i].trim()) {
                        found = true
                        $chkBox.prop("checked", true);
                    }
                }
                else if (i >= labelsToCheck.length - 1) {
                    found = true
                };
                i++;
            } while (found == false);
        });
    }
}

//#endregion