﻿var accidentsAndIncidents = {};

var $lstNetworkNames = $("#lstNetworkNames");
var $lstSection = $("#lstSection");
var $lstSubSection = $("#lstSubSection");
var $sectionId = $("#sectionId");
var $lstSelectedType = $("#lstSelectedType");
var $btnShowData = $("#btnShowData");
var $btnDownloadData = $("#btnDownloadData");
var $btnAddCost = $("#btnAddCost");
var selectedAccID = 0;

jQuery(document).ready(function () {

    accidentsAndIncidents.GetNetworkDetails();
    $lstNetworkNames.change(function () {
        accidentsAndIncidents.getSectionDefsForNetwork();
    });
    $lstSection.change(accidentsAndIncidents.popSectionLabel2Data);
    $lstSubSection.change(accidentsAndIncidents.popSectionLimits);
    $btnShowData.click(function () {
        event.preventDefault();
        accidentsAndIncidents.getAccidentsAndIncidentsData();
    });
    $btnDownloadData.click(function () {
        event.preventDefault();
        accidentsAndIncidents.downloadAccidentsAndIncidentsData();
    });

    $('.cost').keyup(function () {
        accidentsAndIncidents.UpdateCostField();
    });

    $("#btnSave").click(function (event) {
        accidentsAndIncidents.SaveRoadFurnitureCost();
    })

    $("#btnCancel").click(function (event) {
        $('#mdlAddCost').modal('hide')
    })
});

//#region Network Details

//Get Network Details
accidentsAndIncidents.GetNetworkDetails = function () {
    ju.doAjaxWebService("/webServices/networkDefService.asmx/GetNetworkIDsAndNamesAllByNetworkIDs", "", accidentsAndIncidents.showNetworkNames, ju.handleWebServiceError);
}


//Fill Networks
accidentsAndIncidents.showNetworkNames = function (result) {
    if (result && result.d) {
        ju.clearListBox($lstNetworkNames[0]);
        var data = result.d;
        for (var i = 0; i < data.length; i++) {
            var info = data[i].split("|");
            var id = Number(info[0]);
            var name = info[1];
            ju.addListItem($lstNetworkNames[0], name, id);
        }
    }

    $lstNetworkNames.change();
}

//Get SectionDefs for Network
accidentsAndIncidents.getSectionDefsForNetwork = function () {
    var networkID = $lstNetworkNames.val();
    if (networkID != null && networkID != "") {
        ju.doAjaxWebService("/webServices/networkDefService.asmx/GetSectionDefinitions", "{'networkID' : '" + networkID + "' }", accidentsAndIncidents.showSectionDefsForNetwork);
    }
}

//Fills the sectionDef for SH,RS,SectionID,LocFrom & LocTo
accidentsAndIncidents.showSectionDefsForNetwork = function (result) {
    if (result && result.d) {
        sectionHelper = new JV_SectionWorker();
        sectionHelper.setup(result.d, accidentsAndIncidents.popSectionLabel1Data);
    }
}

accidentsAndIncidents.popSectionLabel1Data = function () {
    accidentsAndIncidents.popSectionLabel1List($lstSection, accidentsAndIncidents.popSectionLabel2Data);
}

//Fills the SH for selected section
accidentsAndIncidents.popSectionLabel1List = function ($lst, completeHandler) {
    ju.clearListBox($lst[0]);
    for (var i = 0; i < sectionHelper.label1List.length; i++) {
        if (i == 0) {
            ju.addListItem($lst[0], "All", "All");
        }
        var label = sectionHelper.label1List[i];
        ju.addListItem($lst[0], label);
    }
    if (completeHandler) { completeHandler() };
}

accidentsAndIncidents.popSectionLabel2List = function (sectionLabel1, $lst, completeHandler) {
    ju.clearListBox($lst[0]);
    if (sectionLabel1 != "All") {
        var label2List = sectionHelper.getUniqueSectionLabel2s(sectionLabel1);
        ju.addListItem($lst[0], "All", "All");
        for (var i = 0; i < label2List.length; i++) {
            var label = label2List[i];
            ju.addListItem($lst[0], label);
        }
    }
    else {
        ju.addListItem($lst[0], "All", "All");
        $("#sectionId").val("")
    }
    if (completeHandler) { completeHandler() };
}

//Fills sub section for selected SH
accidentsAndIncidents.popSectionLabel2Data = function () {
    //var secLabel1 = $lstSection.val();
    var secLabel1 = $("option:selected", $lstSection).text();  //Modified by Ravi to comply with Browser standards, IE removes any spaces in value field by default, and hence we rely on Text for SecLabel1
    accidentsAndIncidents.popSectionLabel2List(secLabel1, $lstSubSection, accidentsAndIncidents.popSectionLimits);
    accidentsAndIncidents.popSectionLimits();

}

//Fills LocFrom & LocTo for selected section
accidentsAndIncidents.popSectionLimits = function () {
    var secLabel1 = $("option:selected", $lstSection).text();
    var secLabel2 = $("option:selected", $lstSubSection).text();

    if (secLabel2 != "All") {
        tmpSection = sectionHelper.getSection(secLabel1, secLabel2);
        if (tmpSection) {
            $("#sectionId").val(tmpSection.SectionID);
        }
        if (secLabel1 == "All") {
            $(".divHide").addClass("hidden");
        } else {
            $(".divHide").removeClass("hidden");
        }
    }
    else {
        $(".divHide").addClass("hidden");
        $("#sectionId").val("");
    }
}

//#end region

//#region accidents and incidents

// Get the accidents and incidents
accidentsAndIncidents.getAccidentsAndIncidentsData = function () {
    if ($("#btnShowData").attr("disabled") == "disabled") {
        event.preventDefault();
    }
    else {
        accidentsAndIncidents.showThrobberOverTable();
        $btnDownloadData.css("display", "none");
        $("#btnShowData").attr("disabled", true);
        $("#btnShowData").text("Please Wait....");
        var networkID = $("#lstNetworkNames").val();
        var secLabel1 = $("option:selected", $lstSection).text();
        var secLabel2 = $("option:selected", $lstSubSection).text();
        var reportType = $("option:selected", $lstSelectedType).text();
        if (reportType == "Accidents") {
            reportType = "Accident"
        } else {
            reportType = "Incident"
        }
        var sectionId = 0;
        if (secLabel1 == "All") {
            optionType = "EntireNetwork";
        } else if (secLabel2 == "All") {
            optionType = "EntireSectionLabel1";
        } else {
            optionType = "";
            sectionId = $("#sectionId").val();
        }

        accidentsAndIncidents.clearTableData();
        ju.doAjaxWebService("/webServices/TracService.asmx/GetAccidentsAndIncidents", "{networkID : " + networkID + ",secLabel1:'" + secLabel1 + "',secLabel2:'" + secLabel2 + "',sectionId:" + sectionId + ",optionType:'" + optionType + "',reportType:'" + reportType + "',showOnlyFurnitureDamaged:" + $("#chkOnlyDamageFurniture").prop("checked") + "}", accidentsAndIncidents.showAccidentsAndIncidentsData, ju.handleWebServiceError);
    }
}

accidentsAndIncidents.showThrobberOverTable = function () {
    $('#tableGroup').css("display", "none");
    $("#throbber1").css("display", "block");
}

accidentsAndIncidents.hideThrobberOverTable = function () {
    $('#tableGroup').css("display", "block");
    $("#throbber1").css("display", "none");
}

accidentsAndIncidents.clearTableData = function () {
    var data = {};
    data.d = new Array();
    accidentsAndIncidents.showAccidentsAndIncidentsData(data);
}

// Showing accidents and incidents data
accidentsAndIncidents.showAccidentsAndIncidentsData = function (data) {
    $('#tableGroup').html('<table cellpadding="0" cellspacing="0" border="0" class="table" id="tableData"></table>');
    if (data && data.d) {
        oTable = $('#tableData').dataTable({
            //"aaSorting": [[0, 'asc'], [1, 'asc'], [3, 'asc']],
            "bDeferRender": true,
            "sScrollY": "400px",
            "bPaginate": false,
            "bLengthChange": false,
            "bFilter": true,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false,
            "aaData": data.d,
            "aoColumns": [
                { "sTitle": "Accident ID" },
                { "sTitle": "Section ID" },
                { "sTitle": "Sector" },
                { "sTitle": "Kms Travelled" },
                { "sTitle": "Reported By" },
                { "sTitle": "Name" },
                { "sTitle": "Action" },
                { "sTitle": "HelpDeskRef" },
                { "sTitle": "Patrol Vehicle RegNo" },
                { "sTitle": "Location" },
                {
                    "sTitle": "",
                    "mRender": accidentsAndIncidents.DisplayUpStatus,
                    "sWidth": "85px"
                },
            ],
            "aoColumnDefs": [{ "sClass": "hide_column", "aTargets": [0] }]

        });

        $("#throbber1").css("display", "none");

        $(".addCost").click(function () {
            selectedAccID = parseInt($(this).attr("data-id"));
            accidentsAndIncidents.GetRoadFurnitureData(selectedAccID);
        })
        $("#btnAddCost").removeClass("btn-danger");
        accidentsAndIncidents.hideThrobberOverTable();

        oTable.fnSort([[0, 'asc']]);
        if (data.d.length > 0) { $btnDownloadData.css("display", "block"); }
        else { $btnDownloadData.css("display", "none"); }
    }
    else {
        accidentsAndIncidents.hideThrobberOverTable();
    }
    $("#btnShowData").attr("disabled", false);
    $("#btnShowData").text("Get Data");
    $("#btnAddCost").addClass("hidden");

    /* Add a click handler to the rows - this could be used as a callback */
    $("#tableData tbody").click(function (event) {
        $(oTable.fnSettings().aoData).each(function () {
            $(this.nTr).removeClass('row_selected');
        });
        //$(event.target.parentNode).addClass('row_selected');
        selectedRows = accidentsAndIncidents.fnGetSelected(oTable);
        if (selectedRows && selectedRows.length == 1) {
            if (selectedRows[0].childNodes[selectedRows[0].childNodes.length - 1].innerText == "True") {
                $("#btnAddCost").removeClass("hidden");
            }
            else {
                $("#btnAddCost").addClass("hidden");
            }
        }
    });
}

accidentsAndIncidents.DisplayUpStatus = function (data, type, full) {
    if (data == "True") {
        return "<a href='#' id='btnAddCosts' class='btn btn-primary btn-small addCost'  data-id=" + full[0] + ">Add Cost</a>";
    }
    else {
        return "";
    }
}

accidentsAndIncidents.GetRoadFurnitureData = function (accidentID) {
    $("#mdlAddCost").modal("show");
    ju.doAjaxWebService("/webServices/TracService.asmx/GetQuantityAndCostForRoadFurniture", "{ accidentID : '" + selectedAccID + "'}", function (data) {
        if (data.d) {
            $("#lblGuardRails").text(data.d.guardRails_Extent);
            $("#Guard").val(data.d.guardRails_Cost);
            $("#lblHazPlates").text(data.d.hazPlates_Extent);
            $("#Haz").val(data.d.hazPlates_Cost);
            $("#lblDrainageStructs").text(data.d.drainageStructs_Extent);
            $("#Drainage").val(data.d.drainageStructs_Cost);
            $("#lblStreetLights").text(data.d.streetLights_Extent);
            $("#Street").val(data.d.streetLights_Cost);
            $("#lblBridgeParapets").text(data.d.bridgeParapet_Extent);
            $("#Bridge").val(data.d.bridgeParapet_Cost);
            $("#lblFencing").text(data.d.fencing_Extent);
            $("#Fence").val(data.d.fencing_Cost);
            $("#lblPavements").text(data.d.pavement_extent);
            $("#Pave").val(data.d.pavement_Cost);
            $("#lblSigns").text(data.d.signs_Extent);
            $("#Sign").val(data.d.signs_Cost);
            $("#lblOther").text(data.d.Other_Extent);
            $("#Others").val(data.d.Other_Cost);
            accidentsAndIncidents.UpdateCostField();
        }
    }, ju.handleWebServiceError);
}

/* Get the rows which are currently selected */
accidentsAndIncidents.fnGetSelected = function (oTableLocal) {
    var aReturn = new Array();
    var aTrs = oTableLocal.fnGetNodes();

    for (var i = 0 ; i < aTrs.length ; i++) {
        if ($(aTrs[i]).hasClass('row_selected')) {
            aReturn.push(aTrs[i]);
        }
    }
    return aReturn;
}

//Calculate the response cost
accidentsAndIncidents.UpdateCostField = function () {

    // initialize the sum (total cost) to zero
    var sum = 0;

    // we use jQuery each() to loop through all the textbox with 'cost' class
    // and compute the sum for each loop
    $('.cost').each(function () {
        sum += Number($(this).val());
    });

    // set the computed value to 'totalCostsss' textbox
    $('#totalCost').val(sum.toFixed(2));


}

//Download the data into excell
accidentsAndIncidents.downloadAccidentsAndIncidentsData = function () {
    var networkID = $("#lstNetworkNames").val();
    var secLabel1 = $("option:selected", $lstSection).text();
    var secLabel2 = $("option:selected", $lstSubSection).text();
    var reportType = $("option:selected", $lstSelectedType).text();
    if (reportType == "Accidents") {
        reportType = "Accident"
    } else {
        reportType = "Incident"
    }
    var sectionId = 0;
    if (secLabel1 == "All") {
        optionType = "EntireNetwork";
    } else if (secLabel2 == "All") {
        optionType = "EntireSectionLabel1";
    } else {
        optionType = "";
        sectionId = $("#sectionId").val();
    }
    ju.doAjaxWebService("/webServices/TracService.asmx/ExportAccidentsAndIncidentsData", "{networkID : '" + networkID + "',secLabel1:'" + secLabel1 + "',secLabel2:'" + secLabel2 + "',sectionId:'" + sectionId + "',optionType:'" + optionType + "',reportType:'" + reportType + "'}", accidentsAndIncidents.fileDownLoad, ju.handleWebServiceError);
}

accidentsAndIncidents.fileDownLoad = function (data) {
    if (data && data.d) {
        if (data.d != "error")
            window.location.href = data.d;
    }
}

accidentsAndIncidents.SaveRoadFurnitureCost = function () {
    var guardRail = $("#Guard").val();
    if (guardRail.trim().length == 0) {
        guardRail = 0;
    }
    var hazPlates = $("#Haz").val();
    if (hazPlates.trim().length == 0) {
        hazPlates = 0;
    }
    var drainageStructs = $("#Drainage").val();
    if (drainageStructs.trim().length == 0) {
        drainageStructs = 0;
    }
    var streetLights = $("#Street").val();
    if (streetLights.trim().length == 0) {
        streetLights = 0;
    }
    var bridgeParapet = $("#Bridge").val();
    if (bridgeParapet.trim().length == 0) {
        bridgeParapet = 0;
    }
    var fencing = $("#Fence").val();
    if (fencing.trim().length == 0) {
        fencing = 0;
    }
    var pavement = $("#Pave").val();
    if (pavement.trim().length == 0) {
        pavement = 0;
    }
    var signs = $("#Sign").val();
    if (signs.trim().length == 0) {
        signs = 0;
    }
    var Other = $("#others").val();
    if (Other.trim().length == 0) {
        Other = 0;
    }

    var responseCost = $("#totalCost").val();
    if (responseCost.trim().length == 0) {
        responseCost = 0;
    }

    var roadFurniture = {
        guardRails_Cost: parseFloat(guardRail),
        hazPlates_Cost: parseFloat(hazPlates),
        drainageStructs_Cost: parseFloat(drainageStructs),
        streetLights_Cost: parseFloat(streetLights),
        bridgeParapet_Cost: parseFloat(bridgeParapet),
        fencing_Cost: parseFloat(fencing),
        pavement_Cost: parseFloat(pavement),
        signs_Cost: parseFloat(signs),
        other_Cost: parseFloat(Other),
        response_Cost: parseFloat(responseCost)
    }
    ju.doAjaxWebService("/webServices/TracService.asmx/SaveFurnitureCost", "{ accidentID : '" + parseInt(selectedAccID) + "',furnitureData:" + JSON.stringify(roadFurniture) + "}", function (data) {
        $("#mdlAddCost").modal("hide");
        bootbox.alert("Road furniture cost succesfully saved.");
    }, ju.handleWebServiceError);
}

//#end region

