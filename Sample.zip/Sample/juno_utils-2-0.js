﻿/// <reference path="jquery-1.6.3.min.js" />
//Changes ver 1.2 to 1.3:
// added function ju.removeSpecialChars()


// Utilities Namespace.
// Contains generic helper functions
var ju = {};
ju.req = new XMLHttpRequest;
ju.contentFrame = null;
ju.callBackFunction = null;
ju.loadComplete = false;
ju.svgNS = "http://www.w3.org/2000/svg";
ju.msHour = 3600000;   //milliseconds in an hour

//#region JSON

ju.getArrayFromJSON = function (jsonObject) {
    ///<summary>Gets the VALUEs for all keys/parameters in a JSON object as an array. If object is null, then an empty array is returned///</summary>
    var tmp = new Array;
    if (jsonObject) {
        for (var key in jsonObject) {
            tmp.push(jsonObject[key]);
        }
    }
    return tmp;
}

//#endregion

//#region Modify Existing DOM by adding/removing/modifying elements

ju.setDropdownItemByText = function (lstID, textValueToSet) {
    var dd = document.getElementById(lstID);
    if (dd && dd.options) {
        for (var i = 0; i < dd.options.length; i++) {
            if (dd.options[i].text === textValueToSet) {
                dd.selectedIndex = i;
                break;
            }
        }
    }
}

ju.setDropdownItemByValue = function (selectElement, value) {
    var options = selectElement.options;
    for (var i = 0, optionsLength = options.length; i < optionsLength; i++) {
        if (options[i].value == value) {
            selectElement.selectedIndex = i;
            return true;
        }
    }
    return false;
}

ju.setDropdownItemByTextWithCB = function (lstID, textValueToSet, callback) {
    var dd = document.getElementById(lstID);
    if (dd && dd.options) {
        for (var i = 0; i < dd.options.length; i++) {
            if (dd.options[i].text === textValueToSet) {
                dd.selectedIndex = i;
                if (callback) { callback() };
                break;
            }
        }
    }
    if (callback) { callback() };
}

ju.setDropdownItemByValueWithCB = function (selectElement, value, callback) {
    var options = selectElement.options;
    for (var i = 0, optionsLength = options.length; i < optionsLength; i++) {
        if (options[i].value == value) {
            selectElement.selectedIndex = i;
            if (callback) { callback() };
        }
    }
    if (callback) { callback() };
}

ju.addItemToDivList = function ($divList, $itemBase, margTop, margRight, nCols, idPrefix) {
    var count = $divList.children().length;
    var newItem = $itemBase.clone();

    var w = ju.getInnerWidth($divList, true);
    w = w / nCols;
    var row = Math.floor(count / nCols);
    var col = count - row * nCols;

    var padT = ju.getCSSNumber($divList, "padding-top");
    var padL = ju.getCSSNumber($divList, "padding-left");

    var h = $(newItem).height();
    var y = padT + (row * (h + margTop));
    var l = padL + col * (w + margRight);
    w = w - margRight;
    if (idPrefix) {
        newItem.attr('id', idPrefix + count);
    }
    else {
        newItem.attr('id', 'itm_' + count);
    }

    newItem.appendTo($divList);
    newItem.css('left', l + 'px');
    newItem.css('top', y + 'px');
    newItem.css('width', w + 'px');
    newItem.css('display', 'block');
    return newItem;
}

ju.setCheckBoxChecked = function ($checkBox, checked) {
    ///<summary>Sets the check state of a checkbox, regardless of whether parameter checked is string or boolean///</summary>
    /// <param name="checked" type="Boolean/String">True or False to value to set checkbox check state to. Can handle boolean or string</param> 
    checked = ju.getBoolean(checked);   //make sure value is boolean
    $checkBox.attr("checked", checked);     //tested on IE9 and Chrome  
    $checkBox.prop('checked', checked)   //Needed for this to work on Bootstrap - tested on IE9
}


ju.getCheckBoxChecked = function ($checkBox) {
    ///<summary>Returns true/false depending on whether checkbox is checked. This is a wrapper to ju.checkboxIsChecked()///</summary>    
    return ju.checkboxIsChecked($checkBox)
}


ju.setRadioChecked = function ($radio, nameAttr) {
    ///<summary>sets a specific radio button's select to true, and all other's to false
    ///<paragraph>NOTE: To target only a certain subset of radio inputs, set the name attribute for the group to a certain value and pass that value as nameAttr </paragraph>
    ///</summary>
    var $radios
    if (nameAttr) {
        $radios = $("input:radio[name=" + nameAttr + "]");
    }
    else {
        $radios = $('input:radio');
    }
    if ($radios.is(':checked') === true) {
        $radios.attr('checked', false);
    }
    $radio.attr('checked', true);
}

//removes the child notes from a parent element with ID = parentID
ju.removeChildNodes = function (parentID) {
    var parentNode = document.getElementById(parentID);
    if (parentNode) {
        while (parentNode.hasChildNodes()) {
            parentNode.removeChild(parentNode.lastChild);
        }
    }
}

ju.popSelectList = function ($lstBox, valueArray, textArray) {
    ///<summary>Populates a select dropdown list with values and text</summary>
    $lstBox[0].innerHTML = "";
    for (i = 0; i < valueArray.length; i++) {
        $('<option/>').val(valueArray[i]).html(textArray[i]).appendTo($lstBox);
    }
}


//Populates a listbox by using the parsed values from a delimited string
ju.popListBox = function (oListBox, delimString, delimiter) {
    var values = delimString.split(delimiter);
    ju.clearListBox(oListBox);
    for (var i = 0; i <= values.length - 1; i++) {
        ju.addListItem(oListBox, values[i])
    }
}

//Searches if name exists ing list box
ju.isNameExistsInListBox = function (oListBox, itemName) {
    for (var i = oListBox.length - 1; i >= 0; i--) {
        if (oListBox.options[i].text == itemName) {
            return true;
        }
    }

    return false;
}

// Clears a list box, i.e. <select> element
ju.clearListBox = function (oListBox) {
    for (var i = oListBox.length - 1; i >= 0; i--) {
        oListBox.remove(i);
    }
}

//Adds an element to a listbox
ju.addListItem = function (oListBox, sText, sValue) {
    var oOption = document.createElement("option");
    oOption.appendChild(document.createTextNode(sText));
    if (arguments.length == 3) {
        oOption.setAttribute("value", sValue);
    }
    oListBox.appendChild(oOption);
}


//Initiates call to get content after navigation link click                                  
//contentURL = URL of the content to load
//contentFrameID = ID of the <div> into which content should be loaded
//isAsync = True or False indicating if request should be async
ju.loadContent = function (contentURL, contentFrameID, isAsync, callBack) {
    ju.contentFrame = document.getElementById("contentFrame");
    ju.callBackFunction = callBack;
    if (ju.req != null) {
        ju.req.open("GET", contentURL, isAsync);
        ju.req.onreadystatechange = ju.showContent;
        ju.loadComplete = false;
        ju.req.send();
    }
}

//Shows loaded content in the content Frame
ju.showContent = function () {
    if ((ju.req.readyState == 4) && (ju.req.status == 200)) {
        if (ju.contentFrame) {
            ju.contentFrame.innerHTML = ju.req.responseText;
            if (ju.callBackFunction) {
                ju.callBackFunction()
            }
            ju.loadComplete = true;
        }
    }
}

//Adds a javascript file reference to a page
ju.addJavascriptFile = function (jsFileName) {
    var pos = 'head';
    var th = document.getElementsByTagName(pos)[0];
    var s = document.createElement('script');
    s.setAttribute('type', 'text/javascript');
    s.setAttribute('src', jsFileName);
    th.appendChild(s);
}

//Adds a CSS file reference to a page
ju.addCSSFile = function (cssFileName) {
    ju.removeStyleSheet(cssFileName);
    var pos = 'head';
    var th = document.getElementsByTagName(pos)[0];
    var s = document.createElement('link');
    s.setAttribute('rel', 'stylesheet');
    s.setAttribute('href', cssFileName);
    th.appendChild(s);
}

ju.removeStyleSheet = function (cssFileURL) {
    var styleSheets = document.styleSheets;
    for (var i = 0; i < styleSheets.length; i++) {
        if (styleSheets[i].href == cssFileURL) {
            styleSheets[i].disabled = true;
            break;
        }
    }
    $("link[href*='" + cssFileURL + "']").remove();  //need this for Firefox
}



//#endregion

//#region Pop-Up Dialog Helpers

ju.showDivAsPopUp = function ($div, $fadeBox, $container) {
    /// <summary>Shows an existing div as a pop-up in the centre of $container. If $container is null, then $div is centred in window. 
    /// $fadeBox must be preset in size to cover full window, and have a z-index above other elements    
    /// </summary>    
    var z = parseInt($fadeBox.css("z-index")) + 1;
    $div.css("z-index", z);
    $fadeBox.css('display', 'block');
    $div.css('display', 'block');
    if ($container) {
        ju.centreDivInContainer($div, $container);
    }
    else {
        ju.centerElement($div, 1, 1);
    }
}

ju.showProgress = function (contentFrameID, $waiter) {
    /// <summary>Positions a Waiter signal element over another div. Assumes $waiter is absolutely positioned and NOT a chile of the element with contentFrameID.    
    /// </summary> 
    var $contentFrame = $('#' + contentFrameID);
    $('#' + contentFrameID + ' div').each(function () {
        $(this).css('visibility', 'hidden');
    });
    ju.centreDivOverContainer($waiter, $contentFrame);
    $waiter.css('visibility', 'visible');
}

ju.hideProgress = function (contentFrameID, $waiter) {
    $waiter.css('visibility', 'hidden');
    $('#' + contentFrameID + ' div').each(function () {
        $(this).css('visibility', 'visible');
    });
}


//#endregion

//#region SVG Helpers

ju.svgMeasureString = function (svgParent, stringToMeasure, fontName, fontSize) {
    /// <summary>Gets the size of a string. Returns a jSON object with properties width and height.</summary>   
    var t = ju.svgAddText(svgParent, "testStringZonkoBonko", stringToMeasure, 50, 50, fontName, fontSize, "middle");
    var bbox = t.getBBox();
    var w = bbox.width;
    var h = bbox.height;
    $("#testStringZonkoBonko").remove();
    return { width: w, height: h };
}

ju.isTouchDevice = function () {
    var el = document.createElement("div");
    el.setAttribute("ongesturestart", "return;");
    if (typeof el.ongesturestart == "function") {
        return true;
    }
    else {
        return false;
    };
}

ju.SvgAddSlider = function (containerDivID, sliderID, padLeft, padRight, lineColour, lineWidth, handleColour, handleWidth, dragHandler, handleCornerRadius) {
    /// <summary>Adds an SVG slider to a div element with id = containerDivID. dragHandler is the callback function to handle
    /// a dragging of the slider. It must accept a parameter x which is the percentage length dragged as a fraction, e.g: 0.5 if the slider is dragged right in the centre
    ///   <para> Note that sliderID is actually the ID of the circle SVG element that is being dragged</para>
    /// </summary>    
    var mySvg = document.createElementNS(ju.svgNS, "svg");
    var frame = document.getElementById(containerDivID);
    var $frame = $(frame);
    var w = $frame.width();
    var h = $frame.height();
    var y = h / 2;
    var handleID = sliderID + "_handle";
    frame.appendChild(mySvg);
    mySvg.setAttribute("id", sliderID);
    mySvg.setAttribute("version", "1.2");
    mySvg.setAttribute("width", w);
    mySvg.setAttribute("height", h);
    mySvg.setAttribute("style", "overflow:hidden");
    mySvg.setAttribute("preserveAspectRatio", "none");
    ju.svgAddLine(mySvg, "1", padLeft, y, w - padRight, y, lineWidth, lineColour);

    var x = w / 2 - handleWidth / 2;
    var $handle = $(ju.svgAddRect(mySvg, sliderID, x, y - h / 2, handleWidth, h, 1, handleColour, handleColour, 1));

    if (handleCornerRadius) {
        $handle.attr("rx", handleCornerRadius);
        $handle.attr("ry", handleCornerRadius);
    }

    var isDrawing = false;
    function handleMouseMove(e) {
        if (isDrawing) {
            w = $frame.width();
            var xLeft = $frame.offset().left + padLeft;
            var effectiveWidth = w - padLeft - padRight;
            var x = e.pageX - xLeft - handleWidth / 2;
            $handle.attr("x", x);
            x = x + handleWidth / 2;
            if (dragHandler) { dragHandler(100 * (x / effectiveWidth)) };
        }
    }

    if (ju.isTouchDevice()) {
        $handle.touchstart(function (e) {
            isDrawing = true;
        });
        $handle.touchend(function (e) {
            // isDrawing = false;
        });
        $handle.touchmove(function (e) {
            handleMouseMove(e);
        });
    }
    else {
        $handle.mousedown(function (e) {
            isDrawing = true;
        });
        $handle.mouseup(function (e) {
            isDrawing = false;
        });

        $handle.mousemove(function (e) {
            handleMouseMove(e);
        });
    };




    this.setSliderValue = function (xPercFrac) {
        w = $frame.width();
        var effectiveWidth = w - padLeft - padRight;
        var x = (xPercFrac * effectiveWidth) - handleWidth / 2;
        $handle.attr("x", x);
    }
}

ju.svgAddGroup = function (parent, id) {
    var g = document.createElementNS(ju.svgNS, 'g');
    g.setAttribute("overflow", "hidden");
    if (id !== null) { g.setAttribute("id", id) };
    parent.appendChild(g);
    return g;
}

ju.svgAddTextBox = function (parent, id, x, y, w, h, lw, lineCol, fillCol, opacity, txt, fontFamily, fontSize, fontCol) {
    var g = ju.svgAddGroup(parent, id);
    var r = ju.svgAddRect(g, null, x, y, w, h, lw, lineCol, fillCol, opacity);
    x = x + w / 2;
    y = y + h / 2 + fontSize / 2;
    t = ju.svgAddText(g, null, txt, x, y, fontFamily, fontSize, fontCol);
    t.setAttribute("text-anchor", "middle");
    return g;
}

ju.svgAddRect = function (parent, id, x, y, w, h, lw, lineCol, fillCol, opacity) {
    var rec = document.createElementNS(ju.svgNS, 'rect');
    if (id !== null) { rec.setAttribute("id", id) };
    rec.setAttribute("x", x);
    rec.setAttribute("y", y);
    rec.setAttribute("width", w);
    rec.setAttribute("height", h);
    rec.setAttribute("fill", fillCol);
    rec.setAttribute("stroke-width", lw);
    rec.setAttribute("stroke", lineCol);
    rec.setAttribute("fill-opacity", opacity);
    parent.appendChild(rec);
    return rec;
}

ju.svgAddLine = function (parent, id, x1, y1, x2, y2, lw, lineCol, dashArray) {
    ///<summary>Adds an SVG line. dashArray is string and is optional</summary>
    /// <param name="dashArray" type="String">string indicating dash spacings delimited by commas, e.g. '3,2' for 3 pixel line and 2 pixel gap</param> 
    var l = document.createElementNS(ju.svgNS, 'line');
    if (id !== null) { l.setAttribute("id", id) };
    l.setAttribute("x1", x1);
    l.setAttribute("y1", y1);
    l.setAttribute("x2", x2);
    l.setAttribute("y2", y2);
    l.setAttribute("stroke-width", lw);
    l.setAttribute("stroke", lineCol);
    if (dashArray) { l.setAttribute("stroke-dasharray", dashArray) };
    parent.appendChild(l);
    return l;
}

ju.svgAddText = function (parent, id, textVal, x, y, fontFamily, fontSize, colour, anchor) {
    /// <param name="anchor" type="String">string indicating anchor for vertical alignment. Valid values are 'start', 'middle' or 'end'</param> 
    var t = document.createElementNS(ju.svgNS, 'text');
    if (id !== null) { t.setAttribute("id", id) };
    t.setAttribute("x", x);
    t.setAttribute("y", y);
    t.setAttribute("font-family", fontFamily);
    t.setAttribute("font-size", fontSize);
    t.setAttribute("fill", colour);
    if (anchor !== null) { t.setAttribute("text-anchor", anchor) };
    var t2 = document.createTextNode(textVal);
    t.appendChild(t2);
    parent.appendChild(t);
    return t;
}

ju.svgAddCircle = function (parent, id, x, y, r, colour) {
    var circle = document.createElementNS(ju.svgNS, 'circle');
    if (id !== null) { circle.setAttribute("id", id) };
    circle.setAttribute("cx", x);
    circle.setAttribute("cy", y);
    circle.setAttribute("r", r);
    circle.setAttribute("fill", colour);
    parent.appendChild(circle);
}

ju.svgAddPolygon = function (parent, id, pointsText, fillColour, fillOpacity, lineColour, lineThickness) {
    ///<summary>Adds a polygon element to the parend</summary>
    /// <param name="pointsText" type="string">String representing points of polygon, correctly formatted. E.g. '0,10 5,13 9,21.3'</param> 
    var poly = document.createElementNS(ju.svgNS, 'polygon');
    if (id !== null) { poly.setAttribute("id", id) };
    poly.setAttribute("points", pointsText);
    var txt = "fill: " + fillColour + "; fill-opacity: " + fillOpacity + "; stroke: " + lineColour + "; stroke-width: " + lineThickness + ";";
    poly.setAttribute("style", txt);
    parent.appendChild(poly);
}


//#endregion

//#region Layout Helpers

ju.findPosition = function (obj) {
    ///<summary>Gets the absolute poisition of an element, relative to the page origin. Usage: call findPosition().left and findPosition().top
    ///Code from :http://www.quirksmode.org/js/findpos.html
    ///</summary>
    var curleft = curtop = 0;
    if (obj.offsetParent) {
        do {
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);  //must be '=' and not '=='
        return { left: curleft, top: curtop };
    }
}

ju.getElementOffsetX = function ($elem) {
    ///<summary>Gets the INNER left of an element, relative to its parent (for absolute offset, use ju.findPosition), taking into consideration margin, padding and border.
    ///Note that $elem.position().left gives the position of the corner OUTSIDE the border, margin and padding.
    ///</summary>
    var b = ju.getCSSNumber($elem, "border-left-width");
    var p = ju.getCSSNumber($elem, "padding-left");
    var m = ju.getCSSNumber($elem, "margin-left");
    var outL = $elem.position().left;
    var innL = outL + b + p + m;
    return innL;
}

ju.getElementOffsetY = function ($elem) {
    ///<summary>Gets the INNER top of an element, relative to its parent (for absolute offset, use ju.findPosition) taking into consideration margin, padding and border.
    ///Note that $elem.position().top gives the position of the corner OUTSIDE the border, margin and padding.
    ///</summary>
    var b = ju.getCSSNumber($elem, "border-top-width");
    var p = ju.getCSSNumber($elem, "padding-top");
    var m = ju.getCSSNumber($elem, "margin-top");
    var outT = $elem.position().top;
    var innT = outT + b + p + m;
    return innT;
}

ju.ElemSetup = function (id, spBefore, spAfter, top) {
    ///<summary>Object for positioning of an element. Used by routines such as stackElemsHoriz.
    ///</summary>
    /// <param name="id" type="String">id of the element</param>    
    this.id = id;
    this.spaceBefore = spBefore;
    this.spaceAfter = spAfter;
    this.$elem = $("#" + this.id);
    this.top = top;
}

ju.stackElemsHoriz = function (elementSetups, $container, floatLastElem) {
    ///<summary>Positions elements horizontally and optionally floats the last element to the right. Ideal for buttons on a toolbar.
    ///</summary>
    /// <param name="elementSetups" type="Array">Array of ju.ElemSetup objects containing details about layout</param>
    /// <param name="floatLastElem" type="Boolean">If true, then the last element is floated right, with margin at right = .spaceAfter</param>
    for (var i = 0; i <= elementSetups.length - 1; i++) {
        var thisElem = elementSetups[i];
        var l = null;
        if (i == 0) {
            l = thisElem.spaceBefore;
        }
        else {
            var prevElem = elementSetups[i - 1];
            l = prevElem.$elem.position().left + prevElem.$elem.width() + prevElem.spaceAfter + thisElem.spaceBefore;
        };
        thisElem.$elem.css("position", "absolute");
        thisElem.$elem.css("left", l + "px");
        if (i == elementSetups.length - 1 && floatLastElem == true) {
            l = $container.width() - thisElem.$elem.width() - thisElem.spaceAfter;
            thisElem.$elem.css("left", l + "px");
        }
        thisElem.$elem.css("top", thisElem.top + "px");
    }
}

// Centers an Element horizontally on the page
ju.centerElementHorizontally = function ($Elem, minWidth) {
    var winWidth = $(window).width();
    var offset = $Elem.offset();
    var currWidth = $Elem.outerWidth();
    var currTop = offset.top;
    if (winWidth < minWidth) {
        $Elem.offset({ top: currTop, left: 0 })
    }
    else {
        var newLeft = Math.max(0, (winWidth - currWidth) / 2);
        $Elem.offset({ top: currTop, left: newLeft })
    }
    //$Elem.width(percentOfWidth*winWidth);                                                                                                                                                                             
}

// Centers an Element vertically on the page
ju.centerElementVertically = function ($Elem, minHeight) {
    var winHeight = $(window).height();
    var offset = $Elem.offset();
    var currHeight = $Elem.outerHeight();
    var currLeft = offset.left;
    if (winHeight < minHeight) {
        $Elem.offset({ top: 0, left: currLeft });
    }
    else {
        var newTop = Math.max(0, (winHeight - currHeight) / 2);
        $Elem.offset({ top: newTop, left: currLeft });
    }
    //$Elem.height(winHeight*percentOfHeight);                                                                                                                           
}

ju.centerElement = function ($Elem, minWidth, minHeight) {
    ///<summary> Centers an Element vertically and horizontally in the available window</summary>
    ju.centerElementVertically($Elem, minHeight);
    ju.centerElementHorizontally($Elem, minWidth);
}

ju.centreDivOverContainer = function ($box, $cframe) {
    /// <summary>Centers a div = $box over another div = $cframe. This method assumes $box is absolutely positioned and NOT a child of $cframe.
    /// Assumes both have stylesheets set up.</summary>  
    var fl = $cframe.offset().left;
    var ft = $cframe.offset().top;
    var fw = $cframe.width();
    var fh = $cframe.height();
    var lw = $box.width();
    var lh = $box.height();
    var left = fl + (fw / 2 - lw / 2) + 'px';
    var top = ft + (fh / 2 - lh / 2) + 'px';
    $box.css('left', left);
    $box.css('top', top);
}

ju.centreDivOverWindow = function ($box) {
    /// <summary>Centers a div = $box over the window. This method assumes $box is absolutely positioned with a style set up</summary>      
    var winWidth = $(window).width();
    var winHeight = $(window).height();
    var lw = $box.width();
    var lh = $box.height();
    var left = (winWidth / 2 - lw / 2) + 'px';
    var top = (winHeight / 2 - lh / 2) + 'px';
    $box.css('left', left);
    $box.css('top', top);
}

//  
// containing div has a stylesheet element set up
ju.centreDivInContainer = function ($box, $cframe) {
    /// <summary>Centers a div = $box over a container = $cframe. This method assumes $box is absolutely positioned and IS a child of $cframe   
    /// Assumes both have stylesheets set up.</summary>   
    var fw = $cframe.width();
    var fh = $cframe.height();
    var lw = $box.width();
    var lh = $box.height();
    var left = (fw / 2 - lw / 2) + 'px';
    var top = (fh / 2 - lh / 2) + 'px';
    $box.css('left', left);
    $box.css('top', top);
}

//Sets an element's outer width
ju.setOuterWidth = function ($Elem, width) {
    var padLeft = ju.stripPx($Elem.css('padding-left'));
    var padRight = ju.stripPx($Elem.css('padding-right'));
    var margLeft = ju.stripPx($Elem.css('margin-left'));
    var margRight = ju.stripPx($Elem.css('margin-right'));
    var bordLeft = ju.stripPx($Elem.css('border-left-width'));
    var bordRight = ju.stripPx($Elem.css('border-right-width'));
    var w = width - bordLeft - margLeft - padLeft - padRight - margRight - bordRight;
    $Elem.width(w);
}

//Sets an element's outer Height
ju.setOuterHeight = function ($Elem, height) {
    var padTop = ju.stripPx($Elem.css('padding-top'));
    var padBott = ju.stripPx($Elem.css('padding-bottom'));
    var margTop = ju.stripPx($Elem.css('margin-top'));
    var margBott = ju.stripPx($Elem.css('margin-bottom'));
    var bordTop = ju.stripPx($Elem.css('border-top-width'));
    var bordBott = ju.stripPx($Elem.css('border-bottom-width'));
    var h = height - bordTop - margTop - padTop - padBott - margBott - bordBott;
    $Elem.height(h);
}

//Gets an element's width excluding padding and margin. Note: just using jQuery.width() does not work, for
//some reason the width needs to be further reduced by diff between outerWidth and innerWidth. This one WORKS, believe me!
ju.getInnerWidth = function ($Elem, excludeMargins) {
    var padLeft = ju.stripPx($Elem.css('padding-left'));
    var padRight = ju.stripPx($Elem.css('padding-right'));
    var margLeft = ju.stripPx($Elem.css('margin-left'));
    var margRight = ju.stripPx($Elem.css('margin-right'));
    if (excludeMargins) {
        margLeft = 0;
        margRight = 0;
    }
    var bordLeft = ju.stripPx($Elem.css('border-left-width'));
    var bordRight = ju.stripPx($Elem.css('border-right-width'));
    var w = $Elem.width() - bordLeft - margLeft - padLeft - padRight - margRight - bordRight;
    return w;
}

//Gets an element's Height excluding padding and margin.
ju.getInnerHeight = function ($Elem, excludeMargins) {
    var padTop = ju.stripPx($Elem.css('padding-top'));
    var padBott = ju.stripPx($Elem.css('padding-bottom'));
    var margTop = ju.stripPx($Elem.css('margin-top'));
    var margBott = ju.stripPx($Elem.css('margin-bottom'));
    var bordTop = ju.stripPx($Elem.css('border-top-width'));
    var bordBott = ju.stripPx($Elem.css('border-bottom-width'));
    if (excludeMargins) {
        margTop = 0;
        margBott = 0;
    }
    var h = $Elem.height() - bordTop - margTop - padTop - padBott - margBott - bordBott;
    return h;
}

ju.sizeToParent = function ($parent, $content) {
    var w = $parent.width();
    var padLeft = parseInt($content.css('padding-left'));
    var padRight = parseInt($content.css('padding-right'));
    w = w - padLeft - padRight;
    $content.css('width', w + 'px');
}

//#endregion

//#region DATE Helpers

ju.parseJSONToObjectDateSafe = function (jsonText) {
    ///<summary>Parses a JSON string created with JavascripSeriealizer to a Object AND correctly converts DATE properties to Javascript dates.
    ///For more details see: http://stackoverflow.com/questions/82058/deserializing-client-side-ajax-json-dates</summary>

    var parsedObject = JSON.parse(jsonText);
    for (var key in parsedObject) {
        if (parsedObject.hasOwnProperty(key)) {
            var value = parsedObject[key];
            if (value) {
                if (ju.stringContains(value, "/Date", false)) {
                    parsedObject[key] = ju.getDateFromASPJson(value);
                };
            }
        }
    }
    return parsedObject;
}

ju.getDateFromASPJson = function (JsonFromASP) {
    ///<summary>Parses the value in a JSON string created with JavascripSeriealizer to a Date. We need to do this because dates are written to something like: '/Date(1123412431324)/'
    ///For more details see: http://stackoverflow.com/questions/82058/deserializing-client-side-ajax-json-dates</summary>      
    return new Date(parseInt(JsonFromASP.replace("/Date(", "").replace(")/", ""), 10))
}

ju.getMinsFromHr = function (hrVal) {
    ///<summary>Returns the minutes from an hour, e.g will return 30 for hrVal = 1.5
    ///</summary>
    var frac = hrVal - Math.floor(hrVal);
    return frac * 60;
}

ju.getDateInterval = function (date1, date2, interval) {
    ///<summary>Returns the number of intervals between two dates, where interval can be years,months,weeks, days, hours, minutes, seconds, milliseconds.
    ///Code from http://stackoverflow.com/questions/542938/how-do-i-get-the-number-of-days-between-two-dates-in-jquery</summary>
    /// <param name="interval" type="String">Must be one of: 'years', 'months', weeks, days, hours, minutes, seconds, milliseconds</param>
    var millsec = 1, second = 1000, minute = second * 60, hour = minute * 60, day = hour * 24, week = day * 7;
    date1 = new Date(date1);
    date2 = new Date(date2);
    var timediff = date2 - date1;
    if (isNaN(timediff)) return NaN;
    switch (interval) {
        case "years": return date2.getFullYear() - date1.getFullYear();
        case "months": return (
            (date2.getFullYear() * 12 + date2.getMonth())
            -
            (date1.getFullYear() * 12 + date1.getMonth())
        );
        case "weeks": return Math.floor(timediff / week);
        case "days": return Math.floor(timediff / day);
        case "hours": return Math.floor(timediff / hour);
        case "minutes": return Math.floor(timediff / minute);
        case "seconds": return Math.floor(timediff / second);
        case "milliseconds": return Math.floor(timediff / millsec);
        default: return undefined;
    }
}

ju.getHoursBetweenDates = function (date1, date2) {
    var value1 = date1.getTime();
    var value2 = date2.getTime();
    var diff = Math.abs(value1 - value2); //millisec difference
    var result = diff / ju.msHour;   //divide millsec diff by millsecs/hour to get total number of hours
    return result;
}

ju.getFormatDateString = function (dateString, formatString) {
    ///<summary>Formats a date string that is in yyyy/mm/dd format. '-' can also be a '/' </summary>
    /// <param name="dateString" type="String">Date string that is in yyyy/mm/dd format. '-' can also be a '/' </param> 
    /// <param name="formatString" type="String">Format: handled values are 'DDD', 'dd', 'dd-MMM', 'dd-mm', 'dd-MMM-yyyy', 'yyyy-mm-dd', 'MMM-yy'</param> 
    var dateVal = ju.parseDateString(dateString);
    var dateTxt = ju.getDateString(dateVal, formatString);
    return dateTxt;
}

ju.getDateString = function (dateValue, formatString) {
    ///<summary>Formats a date as a string</summary>
    /// <param name="formatString" type="String">Format: handled values are 'DDD', 'dd', 'dd-MMM', 'dd-mm', 'dd-MMM-yyyy', 'yyyy-mm-dd', 'MMM-yy'. Dash could also be '/'</param> 
    switch (formatString) {
        case "DDD":
            var dayOfWeek = ju.getDayString(dateValue);
            var days = dateValue.getDate();
            return dayOfWeek + " " + days;
        case "dd":
            var days = dateValue.getDate();
            return days;
        case "dd-MMM":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            return days + "-" + ju.getMonthString(month);
        case "dd/MMM":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            return days + "/" + ju.getMonthString(month);
        case "dd-mm":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            return days + "-" + month;
        case "dd/mm":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            return days + "/" + month;
        case "dd-MMM-yyyy":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            return days + "-" + ju.getMonthString(month) + "-" + year;
        case "dd/MMM/yyyy":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            return days + "/" + ju.getMonthString(month) + "/" + year;
        case "yyyy-mm-dd":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            return year + "-" + month + "-" + days;
        case "yyyy/mm/dd":
            var days = dateValue.getDate();
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            return year + "/" + month + "/" + days;
        case "MMM-yy":
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            if (year >= 2000) {
                year = year - 2000;
            }
            else {
                year = year - 1900;
            }
            year = year.toString();
            if (year.length == 1) { year = "0" + year };
            return ju.getMonthString(month) + "-" + year;
        case "MMM/yy":
            var month = dateValue.getMonth() + 1;
            var year = dateValue.getFullYear();
            if (year >= 2000) {
                year = year - 2000;
            }
            else {
                year = year - 1900;
            }
            year = year.toString();
            if (year.length == 1) { year = "0" + year };
            return ju.getMonthString(month) + "/" + year;
    }

}

ju.getMonthString = function (iMonth) {
    switch (iMonth) {
        case 1: return "Jan";
        case 2: return "Feb";
        case 3: return "Mar";
        case 4: return "Apr";
        case 5: return "May";
        case 6: return "Jun";
        case 7: return "Jul";
        case 8: return "Aug";
        case 9: return "Sep";
        case 10: return "Oct";
        case 11: return "Nov";
        case 12: return "Dec";
    }
}

ju.getMonthValue = function (monthStringShort) {
    ///<summary>Returns the integer value corresponding to monthStringShort = 'jan', 'feb' etc., with jan = 1, feb = 2,...,dec =12. Not case sensitive</summary>
    switch (monthStringShort.toLowerCase()) {
        case "jan": return 1;
        case "feb": return 2;
        case "mar": return 3;
        case "apr": return 4;
        case "may": return 5;
        case "jun": return 6;
        case "jul": return 7;
        case "aug": return 8;
        case "sep": return 9;
        case "oct": return 10;
        case "nov": return 11;
        case "dec": return 12;
        default:
            return -999;
    }
}

ju.getMonthStringLong = function (iMonth) {
    switch (iMonth) {
        case 1: return "January";
        case 2: return "February";
        case 3: return "March";
        case 4: return "April";
        case 5: return "May";
        case 6: return "June";
        case 7: return "July";
        case 8: return "August";
        case 9: return "September";
        case 10: return "October";
        case 11: return "November";
        case 12: return "December";
    }
}

ju.getDayString = function (dateValue) {
    var dayOfWeek = dateValue.getDay();
    switch (dayOfWeek) {
        case 0: return "Sun";
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
    }
}

ju.addDaysToDate = function (baseDate, daysToAdd) {
    ///<summary>Returns a date that is daysToAdd days later than baseDate</summary>
    var millSecs = baseDate.getTime();
    var tmpDate = new Date(millSecs);
    tmpDate.setDate(tmpDate.getDate() + daysToAdd);
    return tmpDate;
}

ju.addHoursToDate = function (baseDate, hoursToAdd) {
    ///<summary>Returns a date that is hoursToAdd days later than baseDate. hoursToAdd must be less than 24. If the resulting hours is more than 24, a day will be added to the date</summary>    
    var currHrs = baseDate.getHours();
    var totHrs = currHrs + Number(hoursToAdd);
    while (totHrs > 24) {
        baseDate = ju.addDaysToDate(baseDate, 1);
        totHrs = totHrs - 24;
    }
    var millSecs = baseDate.getTime();
    var tmpDate = new Date(millSecs);
    tmpDate.setHours(totHrs);
    return tmpDate;
}

ju.getDateFromString = function (dateString, dateFormat) {
    ///<summary>parse a date in yyyy/mm/dd format. '-' can also be a '/' </summary>
    /// <param name="dateFormat" type="String">Format of the date string. If null, we assume "yyyy/mm/dd". "/" can also be "-"</param>
    var delimiter;
    if (ju.stringContains(dateString, "-", false) == true) { delimiter = "-" };
    if (ju.stringContains(dateString, "/", false) == true) { delimiter = "/" };
    if (dateFormat == null || dateFormat == undefined) { dateFormat = "yyyy/mm/dd" };
    var parts = dateString.split(delimiter);

    // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]]) 

    switch (dateFormat) {
        case "yyyy/mm/dd":
            var result = new Date(parts[0], parts[1] - 1, parts[2]); // months are 0-based 
            return result;
        case "dd-MMM-yyyy":
            var monthVal = ju.getMonthValue(parts[1]) - 1; // months are 0-based 
            var result = new Date(Number(parts[2]), monthVal, Number(parts[0]));
            return result;
        default:
            alert("Date format = '" + dateFormat + "' is not handled in juno_utils.getDateFromString");
            return null;
    }
}

ju.parseDateString = function (dateString) {
    ///<summary>parse a date in yyyy/mm/dd format. '-' can also be a '/' </summary>
    var delimiter;
    if (ju.stringContains(dateString, "-", false) == true) { delimiter = "-" };
    if (ju.stringContains(dateString, "/", false) == true) { delimiter = "/" };
    var parts = dateString.split(delimiter);
    // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]]) 
    var result = new Date(parts[0], parts[1] - 1, parts[2]); // months are 0-based 
    return result;
}

// parse a date in yyyy-mm-dd HH:min format with HH in 24 hour format. '-' can also be a '/'
ju.parseDateTimeString = function (dateTimeString) {
    var delimiter;
    if (ju.stringContains(dateTimeString, "-", false) == true) { delimiter = "-" };
    if (ju.stringContains(dateTimeString, "/", false) == true) { delimiter = "/" };
    var info = dateTimeString.split(" ");
    var dateParts = info[0];
    var timeParts = info[1];
    dateParts = dateParts.split(delimiter);
    if (timeParts !== undefined) {
        var timeParts = timeParts.split(":");
        // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]]) 
        return new Date(dateParts[0], dateParts[1] - 1, dateParts[2], timeParts[0], timeParts[1]); // months are 0-based 
    }
    else {
        return new Date(dateParts[0], dateParts[1] - 1, dateParts[2], 0, 0); // months are 0-based 
    }
}

ju.parseDateTimeStringSQL = function (dateTimeString) {
    ///<summary>parse a date in format '05 Jan 2012 00:00:00:000'. Does not parse seconds. </summary>//
    var parts = dateTimeString.split(" ");
    var day = Number(parts[0]);
    var monStr = parts[1];
    var monInt = Number((ju.getMonthValue(monStr)));
    var yr = Number(parts[2]);
    var timeString = parts[3];
    var timeParts = timeString.split(":");
    var result = new Date(yr, (monInt - 1), day, Number(timeParts[0]), Number(timeParts[1])); // months are 0-based 
    return result;
}

ju.getDateTimeStringSQLDate = function (dateValue) {
    ///<summary>Converts a date into the format '05 Jan 2012 00:00:00:000'. Does not parse seconds etc. </summary>//
    var day = dateValue.getDate();
    var monStr = ju.getMonthString(dateValue.getMonth() + 1);
    var yr = dateValue.getFullYear();
    var hrs = dateValue.getHours()
    var mins = dateValue.getMinutes();
    var result = day + " " + monStr + " " + yr + " " + hrs + ":" + mins + ":00:000";
    return result;
}

ju.getValidDateString = function (dateValue) {
    ///<summary>Removes spaces, appends "0" if the day in date is given as single char and formt the month ie., "jan" to "Jan"</summary>//
    var date = dateValue.replace(/ /g, '');
    if (date.split("-")[0].length == 1) {
        date = "0" + date;
    }
    if (date.length == 11) {
        var formatedDate = date.replace(date.charAt(3) + date.substr(4), date.charAt(3).toUpperCase() + date.substr(4).toLowerCase())
        return formatedDate;
    }
    else {
        return date;
    }
}
ju.validateFromAndToDate = function (fromDate, toDate) {
    ///<summary>validates for todate is greater then from date or not.</summary>//
    var startDate = new Date(fromDate);
    var endDate = new Date(toDate);
    if (endDate > startDate) { return true; }
    else { return false; }
}

//#endregion

//#region CSS/jQuery Wrappers

ju.getCSSNumber = function ($Elem, propName) {
    var propVal = $Elem.css(propName);
    if (propVal == "normal") {
        propVal = "11px";
    }
    return ju.stripPx(propVal);
}

ju.stripPx = function (value) {
    if (value) {
        value = value.replace('px', '');
        value = value.replace(';', '');
        return Number(value);
    }
    else {
        return 0;
    }
}

ju.checkboxIsChecked = function ($chkBox) {
    return $chkBox.is(':checked');
}

//#endregion

//#region Diverse Helpers (Validation, Arrays, XML, etc)

ju.getListBoxSelectedText = function ($lstBox) {
    var id = $lstBox.attr("id");
    return $("#" + id + " option:selected").text();
}

ju.getListBoxSelectedValue = function ($lstBox) {
    var id = $lstBox.attr("id");
    return $("#" + id + " option:selected").val();
}

ju.arrayContainsItem = function (arrayToCheck, itemToFind) {
    var index = ju.getItemIndexInArray(arrayToCheck, itemToFind);
    if (index >= 0) {
        return true;
    }
    else {
        return false;
    }
}

ju.getItemIndexInArray = function (arrayToCheck, itemToFind) {
    if (typeof arrayToCheck.indexOf === 'function') {
        return arrayToCheck.indexOf(itemToFind);
    }
    else {
        for (var i = 0; i < arrayToCheck.length; i++) {
            if (arrayToCheck[i] === itemToFind) {
                return i;
            }
        }
        return -1;
    }
}

ju.isEven = function (numberToCheck) {
    ///<summary>Checks if a number is an even number</summary> 
    return ((numberToCheck % 2) == 0);
}

ju.isNumberOrFloat = function (num) {

    var validate = true;

    //To check if supplied value is not empty
    if (num.length <= 0) {
        validate = false;
    }

    //To check for number or float
    if (!isNaN(parseFloat(num)) && isFinite(num)) {

    }
    else {
        validate = false;
    }

    return validate;
}

ju.onlyNumbers = function (e) {
    ///<summary>Accepts only numeric values on key press</summary> 
    if (e.which != 8 && e.which != 0 && (e.which < 48 && e.which!=9) || e.which > 57) {
        return false;
    }
};

ju.notAllowSpaces = function (e) {
    ///<summary>Dosn't Allow White Spaces</summary> 
    if (e.which == 32) {
        return false;
    }
};

ju.notAllowSingleQuotes = function (e) {
    ///<summary>Dosn't Allow Single Quotes</summary> 
    if (e.which == 39) {
        return false;
    }
};
ju.userNameValidation = function (e) {
    ///<summary>Dosn't Allow Special Characters in User Name</summary> 
    if ((32 <= e.which && e.which <= 35) || (37 <= e.which && e.which <= 39) || (40 <= e.which && e.which <= 44) || e.which == 47 || (58 <= e.which && e.which <= 59) || (60 <= e.which && e.which <= 64) || (91 <= e.which && e.which <= 94) || e.which == 96 || (123 <= e.which && e.which <= 126)) {
        return false;
    }
};
ju.userNameValidationWithoutDot = function (e) {
    ///<summary>Dosn't Allow Special Characters with dot in User Name</summary> 
    if ((32 <= e.which && e.which <= 35) || (37 <= e.which && e.which <= 39) || (40 <= e.which && e.which <= 44) || e.which == 47 || (58 <= e.which && e.which <= 59) || (60 <= e.which && e.which <= 64) || (91 <= e.which && e.which <= 94) || e.which == 96 || (123 <= e.which && e.which <= 126) || e.which == 46) {
        return false;
    } 

};
ju.allowNumbersWithSingleDot = function (e) {
    ///<summary>Accepts only numeric values on key press with single dot</summary> 
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
        return false;
    }
}

ju.checkIDOK = function (tryID, idLabel) {
    ///<summary>Checks an ID to ensure it is not null or zero length, and also that it is unique on the page</summary> 
    var msg = null;
    if (tryID == null) { msg = idLabel + " ID is null or undefined" };
    if (tryID == "") { msg = idLabel + " ID is a zero length string" };
    if ($("#" + tryID).length > 0) { msg = idLabel + " ID is not unique on the page" };
    if (msg == null) {
        return true;
    }
    else {
        alert(msg);
        return false;
    };
}

ju.validateInputValue = function ($input, $errLabel, inputLabel, minLength, checkForSpecialChars) {
    ///<summary>Validates the value attribute on an input element. If too short or contains invalidchars (optional), and error is shown on label = $errLabel. Returns false if any validation fails, else true</summary>    
    /// <param name="inputLabel" type="String">If provided, this is appended in front of the error message</param> 
    /// <param name="checkForSpecialChars" type="Boolean">If true, a check is done for special characters. See ju.stringContainsSpecialChars() for details on what is checked for</param> 
    if ($input.attr("value").length < minLength) {
        $errLabel.text(inputLabel + " Too short or invalid");
        return false;
    }

    if (ju.stringContainsSpecialChars($input.attr("value"))) {
        $errLabel.text(inputLabel + " Contains invalid characters");
        return false;
    }

    return true;
}

ju.getBoolean = function (boolOrString) {
    ///<summary>Gets a boolean from a string or boolean value.</summary>
    /// <param name="boolOrString" type="Boolean/String">Value to convert. Can be boolean or string. If string, only returns True if value = 'true' (not case sensitive); if null, false is returned</param> 
    if (boolOrString) {
        var t = boolOrString.toString().toLowerCase();
        if (t === "true") {
            return true
        }
        else {
            return false;
        };
    }
    else {
        return false;
    };
}

ju.removeSpecialChars = function (stringToCheck) {
    ///<summary>Replaces special characters '|', '~', '^', '_' from a string = stringToCheck.</summary>
    var txt = stringToCheck.split('|').join('');
    txt = txt.split('~').join('');
    txt = txt.split('^').join('');
    txt = txt.split('_').join('');
    return txt;
}

ju.stringContainsSpecialChars = function (stringToCheck) {
    ///<summary>Replaces special characters '|', '~', '^', '_' from a string = stringToCheck.</summary>
    if (ju.stringContains(stringToCheck, "|", false)) { return true };
    if (ju.stringContains(stringToCheck, "~", false)) { return true };
    if (ju.stringContains(stringToCheck, "^", false)) { return true };
    if (ju.stringContains(stringToCheck, "_", false)) { return true };
    return false;
}

ju.validateEmailSimple = function (email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}

ju.elementExists = function (elementID) {
    if ($("#" + elementID).length > 0) {
        return true;
    }
    else {
        return false;
    };
}

ju.isTouchDevice = function () {
    var isTouchSupported = 'ontouchstart' in window.document;
    return isTouchSupported;
}

ju.getGUID = function () {
    ///<summary>Returns an mimicked/almost GUID value.</summary>
    var S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

ju.getBrowserInfo = function () {
    var nVer = navigator.appVersion;
    var nAgt = navigator.userAgent;
    var browserName = navigator.appName;
    var fullVersion = '' + parseFloat(navigator.appVersion);
    var majorVersion = parseInt(navigator.appVersion, 10);
    var nameOffset, verOffset, ix;

    // In Opera, the true version is after "Opera" or after "Version"
    if ((verOffset = nAgt.indexOf("Opera")) != -1) {
        browserName = "Opera";
        fullVersion = nAgt.substring(verOffset + 6);
        if ((verOffset = nAgt.indexOf("Version")) != -1)
            fullVersion = nAgt.substring(verOffset + 8);
    }
        // In MSIE, the true version is after "MSIE" in userAgent
    else if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
        browserName = "Microsoft Internet Explorer";
        fullVersion = nAgt.substring(verOffset + 5);
    }
        // In Chrome, the true version is after "Chrome" 
    else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
        browserName = "Chrome";
        fullVersion = nAgt.substring(verOffset + 7);
    }
        // In Safari, the true version is after "Safari" or after "Version" 
    else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
        browserName = "Safari";
        fullVersion = nAgt.substring(verOffset + 7);
        if ((verOffset = nAgt.indexOf("Version")) != -1)
            fullVersion = nAgt.substring(verOffset + 8);
    }
        // In Firefox, the true version is after "Firefox" 
    else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
        browserName = "Firefox";
        fullVersion = nAgt.substring(verOffset + 8);
    }
        // In most other browsers, "name/version" is at the end of userAgent 
    else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) <
          (verOffset = nAgt.lastIndexOf('/'))) {
        browserName = nAgt.substring(nameOffset, verOffset);
        fullVersion = nAgt.substring(verOffset + 1);
        if (browserName.toLowerCase() == browserName.toUpperCase()) {
            browserName = navigator.appName;
        }
    }
    // trim the fullVersion string at semicolon/space if present
    if ((ix = fullVersion.indexOf(";")) != -1)
        fullVersion = fullVersion.substring(0, ix);
    if ((ix = fullVersion.indexOf(" ")) != -1)
        fullVersion = fullVersion.substring(0, ix);

    majorVersion = parseInt('' + fullVersion, 10);
    if (isNaN(majorVersion)) {
        fullVersion = '' + parseFloat(navigator.appVersion);
        majorVersion = parseInt(navigator.appVersion, 10);
    }

    var t = { name: browserName, majorVersion: majorVersion, fullVersion: fullVersion };
    return t;

}

ju.parseXML = function (xmlStr) {
    var xmlDoc;
    if (typeof window.DOMParser != "undefined") {
        var parser = new window.DOMParser();
        xmlDoc = parser.parseFromString(xmlStr, "text/xml");
    }
    else if (typeof window.ActiveXObject != "undefined" && new window.ActiveXObject("Microsoft.XMLDOM")) {
        xmlDoc = new window.ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(xmlStr);
    } else {
        throw new Error("No XML parser found");
    }
    return xmlDoc;
}

ju.removeItemFromArray = function (arrayToAlter, indexToRemove) {
    ///<summary>Removes the item with index = indexToRemove from arrayToAlter. Basically wraps 'arrayToAlter.splice(indexToRemove, 1);'</summary>
    arrayToAlter.splice(indexToRemove, 1);
}

ju.compareArrays = function (arr1, arr2) {
    if (arr1.length != arr2.length) { return false }
    var n = arr1.length;
    for (var i = 0; i < n; i++) {
        if (arr1[i] !== arr2[i]) { return false }
    }
    return true;
}

ju.stringContains = function (stringToCheck, searchString, caseSensitive) {
    ///<summary>checks if stringToCheck contains searchString.</summary>    
    if (stringToCheck) {
        stringToCheck = stringToCheck.toString();
        if (caseSensitive !== true) {
            stringToCheck = stringToCheck.toLowerCase();
            searchString = searchString.toLowerCase();
        }
        var iValue = stringToCheck.indexOf(searchString);
        if (iValue != -1) {
            return true;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }

}

//Checks if user information is OK
ju.userInfoOK = function (userInfoString) {
    if (userInfoString) {
        if (userInfoString.length < 4) {
            return false;
        }
        else {
            return true
        }
    }
}

///IE secure cancellation of an event (e.g. to cancel form submit)
ju.cancelEvent = function (event) {
    if (event.stopPropagation) {
        event.stopPropagation();
    }
    else if (window.event) {
        window.event.cancelBubble = true;
    }
}

ju.bubbleSort = function (arr, dir) {
    // Pre-calculate directional information
    var start, end;
    if (dir === 1) {
        start = 0;
        end = arr.length;
    } else if (dir === -1) {
        start = arr.length - 1;
        end = -1;
    }

    // Bubble sort: http://en.wikipedia.org/wiki/Bubble_sort
    var unsorted = true;
    while (unsorted) {
        unsorted = false;
        for (var i = start; i != end; i = i + dir) {
            if (arr[i + dir] && arr[i].value > arr[i + dir].value) {
                var a = arr[i];
                var b = arr[i + dir];
                var c = a;
                arr[i] = b;
                arr[i + dir] = c;
                unsorted = true;
            }
        }
    }
    return arr;
}

ju.getOverlap = function (x1, x2, X1, X2) {
    if (x2 < X1) { return 0 };
    if (x1 > X2) { return 0 };
    if (x1 <= X1 && x2 >= X2) { return Math.abs(X2 - X1) };   //full overlap on length of X1 to X2
    if (X1 <= x1 && X2 >= x2) { return Math.abs(x2 - x1) };   //full overlap on length of x1 to x2
    //In this case there is a partial overlap
    if (x1 < X1) { return (x2 - X1) };
    if (x2 > X2) { return (X2 - x1) };
    alert("Error in ju.getOverlap: overlap case not handled");
}

ju.hexToRgb = function (hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}
ju.componentToHex = function (c) {
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
}

ju.rgbTohex = function (r, g, b) {

    return "#" + ju.componentToHex(r) + ju.componentToHex(g) + ju.componentToHex(b);
}
//#endregion

//#region Canvas/Drawing Helpers

ju.drawLine = function (ctx, x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
}

ju.drawLineDashed = function (ctx, x1, y1, x2, y2, dashLen) {
    if (dashLen == undefined) dashLen = 2;

    ctx.beginPath();
    ctx.moveTo(x1, y1);

    var dX = x2 - x1;
    var dY = y2 - y1;
    var dashes = Math.floor(Math.sqrt(dX * dX + dY * dY) / dashLen);
    var dashX = dX / dashes;
    var dashY = dY / dashes;

    var q = 0;
    while (q++ < dashes) {
        x1 += dashX;
        y1 += dashY;
        ctx[q % 2 == 0 ? 'moveTo' : 'lineTo'](x1, y1);
    }
    ctx[q % 2 == 0 ? 'moveTo' : 'lineTo'](x2, y2);

    ctx.stroke();
    ctx.closePath();
};

//#endregion

//#region AJAX Helpers

ju.handleWebServiceError = function (data) {
    //if (data.status == 500) {
    //    window.location.href = "/login.aspx";
    //}
    //else if (data.status == 408) {
    //    window.location.href = "/login.aspx";
    //}
    //else if (data.status == 403) {
    //    window.location.href = "/login.aspx";
    //}
    //else {
        //alert(data.responseText);
    //}
    if (JSON.parse(data.responseText).Message == "Session Expired") {
        window.location.href = "/login.aspx";
    }
    else {
        alert(data.responseText);
    }
};

ju.doAjaxWebService = function (url, dataString, successCallBack, errorCallback, async) {
    if (errorCallback === undefined) { errorCallback = ju.handleAjaxError };
    if (typeof (async) == "undefined") {
        async = true;
    }
    $.ajax({
        type: "POST",
        url: url,
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: successCallBack,
        async: async,
        error: errorCallback
    });
}

ju.handleAjaxError = function (errInfo) {
    if (errInfo) {
        alert(errInfo);
    }
}


ju.doAjax = function (url, callback) {
    ///<summary>Performs Ajax request to generic handler and returns response. Time is automatically added with param name = 'tmp' to avoid caching///</summary>
    var req = new XMLHttpRequest;
    req.onreadystatechange = function () {
        if ((req.readyState == 4) && (req.status == 200)) {
            var result = req.responseText;
            if (callback) { callback(result) };
        }
    };
    url = url + "&tmp=" + new Date().getTime();
    req.open("GET", url, true);
    req.send();
}


ju.getqueryStringvalue = function (name, url) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var urlSearch;
    if (typeof (url) == "undefined") {
        urlSearch = location.search;
    }
    else {
        urlSearch = url;
    }
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(urlSearch);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

//#endregion

//#region Math

ju.getClampedValue = function (value, min, max) {
    ///<summary>Returns a checked value to ensure value is never less than min or more than max</summary>
    if (value < min) {
        return min;
    }
    if (value > max) {
        return max;
    }
    return value;
}

//from: http://stackoverflow.com/questions/1527803/generating-random-numbers-in-javascript-in-a-specific-range
ju.getRandomArbitary = function (min, max) {
    ///<summary>Returns a random number between min and max/</summary>
    return Math.random() * (max - min) + min;
}

//from: http://stackoverflow.com/questions/1527803/generating-random-numbers-in-javascript-in-a-specific-range
ju.getRandomInt = function (min, max) {
    ///<summary>Returns a random integer between min and max. Using Math.round() will give you a non-uniform distribution!</summary>
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

ju.getRoundedNumber = function (number, decimals) {
    ///<summary>Returns a number rounded to a specific number of decimals</summary>
    var n = Math.pow(10, decimals);
    var roundedNum = Math.round(number * n) / n;
    return roundedNum;

}

ju.fnDownloadFile = function (filPath) {

    if (filPath) {
        window.location.href = filPath;
    }
    else {
        alert('Error while downloading file: ' + filPath);
    }

};


//#endregion

//#region Help / Imaage Video Methods

ju.EmbedVideo = function (elem) {
    var video = $(elem).attr("videourl");
    var VideoUrl = encodeURI(video);
    var videoTitle = $(elem).attr("videoTitle");
    var uniqueId = $(elem).attr("uniqueId");
    var videoFolder = $(elem).attr("videoFolder");

    $.ajax({
        url: '/snippets/ViewVideo.html',
        async: false,
        dataType: 'html',
        success: function (data) {
            var htmlData = data.replace("##@@video@@##", VideoUrl);
            htmlData = htmlData.replace(/##@@uniqueId@@##/gi, uniqueId);
            htmlData = htmlData.replace(/##@@videoFolder@@##/gi, videoFolder);
            $("#video").html(htmlData);
            $("#mdlVideo").find("#myModalLabel").html(videoTitle);
            $("#mdlVideo").modal("show");

            $("#btnCloseVideo").click(function () {
                $("#mdlVideo").modal("hide");
                $("#video").html("");
            })
            $($("#mdlVideo").find(".modal-header").find("button")[0]).click(function () {
                $("#mdlVideo").modal("hide");
                $("#video").html("");
            })

            $(".modal-backdrop").click(function () {
                $("#mdlVideo").modal("hide");
                $("#video").html("");
            })
        }
    });
}

ju.ShowHelpFiles = function (ImageArray, divSlideHelp, CssClassName) {

    $('#' + divSlideHelp + '').remove(".groupSlide");
    for (var i = 0; i < ImageArray.length; i++) {
        var ImgFile = "/HelpImages/" + ImageArray[i].toString();
        $('#' + divSlideHelp + '').wrap('<a class="' + CssClassName + '" href="' + ImgFile + '"/>');
    }
}

ju.ShowImages = function (ImageArray, divSlideHelp, CssClassName) {
    $('#' + divSlideHelp + '').remove(".groupSlide");
    for (var i = 0; i < ImageArray.length; i++) {
        var ImgFile = ImageArray[i].toString();
        $('#' + divSlideHelp + '').wrap('<a class="' + CssClassName + '" href="' + ImgFile + '"/>');
    }
}

// use plugin prompt = false for function calls from Inspection view and Section View
ju.saveImageToClipBoard = function (targetElem, usePluginPrompt,jqXCallBack) {
        
    if (usePluginPrompt == false) {

       var grahpTitle = window.prompt("Please Enter Image/Graph Title", "");

        if (grahpTitle != null) {
            ju.sendImageStreamToService(targetElem, grahpTitle, jqXCallBack);
        }
    }
    else {
        apprise('Please Enter Image/Graph Title', { 'input': true }, function (result) {

            if (result != false) {
                ju.sendImageStreamToService(targetElem, result, jqXCallBack);
            }
        });
    }

}

ju.sendImageStreamToService = function (imageStream, imageTitle, jqXCallBack) {

    if (imageTitle != null) {

        canvg();

        html2canvas(imageStream, {
            onrendered: function (canvas) {
                var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");  // here is the most important part because if you dont replace you will get a DOM 18 exception.
                //window.location.href = image

                $.ajax({
                    type: "POST",
                    url: "/Webservices/fileService.asmx/saveImageToClipBoard",
                    async: false,
                    data: "{ 'image':'" + canvas.toDataURL("image/png").replace('data:image/png;base64,', '') + "', 'Title':'" + imageTitle + "'}",
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json'
                }).done(function (respond) {
                    //alert("Image copied to clipBoard successfully");
                    if (typeof (jqXCallBack) != "undefined") {
                        jqXCallBack();
                    }
                });

            }
        });

    }

}

// use plugin prompt = false for function calls from Inspection view and Section View
ju.saveImageToClipBoardWithBase64 = function (imageStream, usePluginPrompt, jqXCallBack) {

    if (usePluginPrompt == false) {

        var grahpTitle = window.prompt("Please Enter Image/Graph Title", "");

        if (grahpTitle != null) {
            ju.sendImageStreamToServiceBase64(imageStream, grahpTitle, jqXCallBack);
        }
    }
    else {
        apprise('Please Enter Image/Graph Title', { 'input': true }, function (result) {

            if (result != false) {
                ju.sendImageStreamToServiceBase64(imageStream, result, jqXCallBack);
            }
        });
    }

}

//This mehtod is to send image stream directly if base64 string available
ju.sendImageStreamToServiceBase64 = function (imageStream, imageTitle, jqXCallBack) {

    if (imageTitle != null) {
               
                $.ajax({
                    type: "POST",
                    url: "/Webservices/fileService.asmx/saveImageToClipBoard",
                    async: false,
                    data: "{ 'image':'" + imageStream + "', 'Title':'" + imageTitle + "'}",
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json'
                }).done(function (respond) {
                    //alert("Image copied to clipBoard successfully");
                    if (typeof (jqXCallBack) != "undefined") {
                        jqXCallBack();
                    }
                });

            }

}

// use plugin prompt = false for function calls from Inspection view and Section View
ju.saveImageToClipBoardWithURL = function (imageURL, usePluginPrompt) {


    if (usePluginPrompt == false) {

        var grahpTitle = window.prompt("Please Enter Image/Graph Title", "");

        if (grahpTitle != null) {
            ju.sendImageURLToService(imageURL, grahpTitle);
        }
    }
    else {
        apprise('Please Enter Image/Graph Title', { 'input': true }, function (result) {

            if (result != false) {
                ju.sendImageURLToService(imageURL, result);
            }
        });
    }

}

ju.sendImageURLToService = function(imageURL, imageTitle)
{

    if (imageTitle != null) {

        $.ajax({
            type: "POST",
            url: "/Webservices/fileService.asmx/saveImageToClipBoardWithPath",
            async: false,
            data: "{ 'imagePath':'" + imageURL + "', 'Title':'" + imageTitle + "'}",
            contentType: 'application/json; charset=utf-8',
            dataType: 'json'
        }).done(function (respond) {
            //alert("Image copied to clipBoard successfully");
        });
    }
}

ju.svgToCanvas=function (targetElem,generateFile,fileName,callback) {
    canvg();

    html2canvas(targetElem, {
        onrendered: function (canvas) {
            var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");  // here is the most important part because if you dont replace you will get a DOM 18 exception.
            //window.location.href = image

            var timestamp = new Date().valueOf();
            if (fileName != "") {
                timestamp = fileName;
            }
            $.ajax({
                type: "POST",
                url: "/Webservices/fileService.asmx/saveImage",
                async:false,
                data: "{ 'image':'" + canvas.toDataURL("image/png").replace('data:image/png;base64,', '') + "','filePath':'/FileUpload/Files/" + timestamp + ".png'}",
                contentType: 'application/json; charset=utf-8',
                dataType: 'json'
            }).done(function (respond) {
                if (generateFile == true) {
                    window.open("/FileUpload/Files/" + timestamp + ".png");
                }
                else {
                    if (typeof (callback) != "undefined") {
                        callback();
                    }
                }
                //alert(respond);
            });

        }
    });
}


 ju.toRGB=function (color) {
        var r, g, b;
        var html = color;

        // Parse out the RGB values from the HTML Code
        if (html.substring(0, 1) == "#") {
            html = html.substring(1);
        }

        if (html.length == 3) {
            r = html.substring(0, 1);
            r = r + r;

            g = html.substring(1, 2);
            g = g + g;

            b = html.substring(2, 3);
            b = b + b;
        }
        else if (html.length == 6) {
            r = html.substring(0, 2);
            g = html.substring(2, 4);
            b = html.substring(4, 6);
        }

        // Convert from Hex (Hexidecimal) to Decimal
        r = parseInt(r, 16);
        g = parseInt(g, 16);
        b = parseInt(b, 16);

        return { r: r, g: g, b: b };
    }

 //To get XML nodes
 ju.GetXMLNodes = function (str) {
     var ChildNodesData = [];
     $(str).children().each(function (i, j) {
         if (j.innerText.toUpperCase() != "NONE" && j.innerText.trim() != "" && j.innerText.toUpperCase() != "NULL") {
             ChildNodesData.push(j.nodeName);
         }
     });
     return ChildNodesData;
 }

function $ensureHexLength(str) {
    if (str.length == 1) {
        str = "0" + str;
    }
    return str;
}

//#endregion