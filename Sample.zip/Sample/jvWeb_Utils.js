﻿/// <reference path="/juno_utils-2-0.js" />


//#region Showing Uploaded Files

var jvWeb_Utils = {}

jvWeb_Utils.UpdateLogStatus = function (status) {
    ju.doAjaxWebService("/webServices/userService.asmx/UpdateLogStatus", "{status:'" + status.replace(/'/g, "\\'") + "'}", function () { }, function () { });
}

jvWeb_Utils.getUploadedFiles = function($lstToShowFilesIn, callback) {
    ju.doAjaxWebService("/webServices/fileService.asmx/GetUserUploads", "{ searchPattern : '*.xls*' }", function (result) {
        if (result && result.d) {
            ju.clearListBox($lstToShowFilesIn[0]);
            var data = result.d;
            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    var info = data[i];
                    var fileName = info[1];
                    ju.addListItem($lstToShowFilesIn[0], fileName, fileName);
                }
            }
            else {
                ju.addListItem($lstToShowFilesIn[0], "No relevant uploaded files found", "No relevant uploaded files found");
            }            
        }
        if (callback) { callback() };
    }, ju.handleWebServiceError);
}

jvWeb_Utils.getSheetsInUploadedFile = function (fileName, $lstToShowSheetsIn, callback) {    
    ju.doAjaxWebService("/webServices/fileService.asmx/GetSheetsInExcelFile", "{ fileName : '" + fileName + "' }", function (result) {
        if (result && result.d) {
            ju.clearListBox($lstToShowSheetsIn[0]);
            var data = result.d;
            for (var i = 0; i < data.length; i++) {
                var sheet = data[i];               
                ju.addListItem($lstToShowSheetsIn[0], sheet, sheet);
            }
        }
        if (callback) { callback() };
    }, ju.handleWebServiceError);
}

//#endregion

//#region Workers

jvWeb_Utils.isFunction = function(functionToCheck) {
    var getType = {};
    return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]';
}

//#endregion