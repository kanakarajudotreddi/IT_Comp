﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace junoViewerLib.BAL
{
    public class clsAccidentsAndIncidentsBAL
    {
        #region Properties
        public int ID { get; set; }
        public int sectionID { get; set; }
        public string sector { get; set; }
        public int kmsTravelled { get; set; }
        public string reportedBy { get; set; }
        public string name { get; set; }
        public string action { get; set; }
        public string helpDeskRef { get; set; }
        public string patrolVehicleRegNo { get; set; }
        public string location { get; set; }
        public bool isRoadFurnitureDamaged { get; set; }
        #endregion
    }

    public class clsRoadFurniture
    {
        #region Properties

        public int guardRails_Extent { get; set; }
        public int hazPlates_Extent { get; set; }
        public int drainageStructs_Extent { get; set; }
        public int streetLights_Extent { get; set; }
        public int bridgeParapet_Extent { get; set; }
        public int fencing_Extent { get; set; }
        public int pavement_extent { get; set; }
        public int signs_Extent { get; set; }
        public int other_Extent { get; set; }

        public double guardRails_Cost { get; set; }
        public double hazPlates_Cost { get; set; }
        public double drainageStructs_Cost { get; set; }
        public double streetLights_Cost { get; set; }
        public double bridgeParapet_Cost { get; set; }
        public double fencing_Cost { get; set; }
        public double pavement_Cost { get; set; }
        public double signs_Cost { get; set; }
        public double other_Cost { get; set; }
        public double response_Cost { get; set; }

        #endregion
    }
}
