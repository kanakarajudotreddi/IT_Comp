﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

using junoViewerLib.BAL;

namespace junoViewerLib.DAL
{
    public class LayerDAL
    {

        #region Variables

        private string tableNameForLayers = "tblLayers";
        
        #endregion

        #region Constructor


        #endregion

        #region Public Methods

        public List<LayerDataItem> GetLayerData(Layer layer, TableInfo tableInfo, NetworkSegment segment, DateRange dateRange, DBWorkerBase dbUser)
        {
            try
            {
                var result = new List<LayerDataItem>();
                var dataDAL = new LinearNetworkDAL(dbUser.ConnectionString);

                //List<string> colsToGet = layer.GetRequiredColumnsForDataRetrieval(tableInfo);
                var segments = new List<NetworkSegment>();
                segments.Add(segment);

                var sortCols = new Dictionary<string,string>();              //must have sortcolumns else error occurs in dataDAL.getData
                sortCols.Add(tableInfo.MappingLocFromColumn,"ASC");

                DataTable data = dataDAL.GetData(segments, tableInfo, new List<string>(), dateRange,"","",sortCols);
                foreach (DataRow row in data.Rows)
                {
                    var item = layer.GetLayerItemFromData(row, tableInfo);
                    result.Add(item);
                }
                
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetLayerData. Details: " + ex.Message);
            }
        }
        
        public bool DeleteLayerOK(int layerID, DBWorkerBase dbAdmin)
        {
            try
            {
                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);
                int n = dbAdmin.ExecuteDeleteCommand(this.tableNameForLayers, whereConditions);
                if (n == 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in DeleteLayerOK. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Updates the General Options for a layer linked to a Segment Table
        /// </summary>        
        public bool UpdateSegmentLayerOptions(int layerID, string YLocType, string DateCol1, string DateCol2, int YOffset, int Height, string DefaultColour, DBWorkerBase dbAdmin)
        {
            try
            {
                var updateValues = new Dictionary<string, object>();
                updateValues.Add("yLocType", YLocType);
                updateValues.Add("dateCol1", DateCol1);
                updateValues.Add("dateCol2", DateCol2);
                updateValues.Add("yOffset", YOffset);
                updateValues.Add("height", Height);
                updateValues.Add("defaultColour", DefaultColour);

                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);

               int n = dbAdmin.ExecuteUpdateCommand(this.tableNameForLayers, updateValues, whereConditions);
               if (n == 1)
               {
                   return true;
               }
               return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateSegmentLayerOptions. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Updates the General Options for a layer linked to a Point data Table
        /// </summary>        
        public bool UpdatePointLayerOptions(int layerID, string YLocType, string DateCol1, int YOffset, string DefaultIcon, DBWorkerBase dbAdmin)
        {
            try
            {
                var updateValues = new Dictionary<string, object>();
                updateValues.Add("yLocType", YLocType);
                updateValues.Add("dateCol1", DateCol1);                
                updateValues.Add("yOffset", YOffset);                
                updateValues.Add("defaultIcon", DefaultIcon);

                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);

                int n = dbAdmin.ExecuteUpdateCommand(this.tableNameForLayers, updateValues, whereConditions);
                if (n == 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdatePointLayerOptions. Details: " + ex.Message);
            }

        }

        public bool UpdateCondFormatsForSegmentData(int layerID, List<string> delimitedData, DBWorkerBase dbAdmin)
        {
            try
            {
                var layer = new Layer();
                foreach (var delimString in delimitedData)
                {
                    var info = Utils.HelperMethods.SplitStringToList(delimString, "|");
                    layer.AddConditionalFormatSegmentData(info[0], info[1], info[2], info[3]);
                }

                var updateValues = new Dictionary<string, object>();
                updateValues.Add("conditionalFormatXML", layer.ConditionalFormatXML);

                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);

                int n = dbAdmin.ExecuteUpdateCommand(this.tableNameForLayers, updateValues, whereConditions);
                if (n == 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateCondFormatsForSegmentData. Details: " + ex.Message);
            }
        }

        public bool UpdateCondFormatsForPointData(int layerID, List<string> delimitedData, DBWorkerBase dbAdmin)
        {
            try
            {
                var layer = new Layer();
                foreach (var delimString in delimitedData)
                {
                    var info = Utils.HelperMethods.SplitStringToList(delimString, "|");
                    layer.AddConditionalFormatPointData(info[0], info[1], info[2], info[3]);
                }

                var updateValues = new Dictionary<string, object>();
                updateValues.Add("conditionalFormatXML", layer.ConditionalFormatXML);

                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);

                int n = dbAdmin.ExecuteUpdateCommand(this.tableNameForLayers, updateValues, whereConditions);
                if (n == 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateCondFormatsForSegmentData. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// To get all users who have active Layers configured within same account
        /// </summary>
        public List<UserBAL> GetUsersWithLayersConfigured(int userID, int accountID, DBWorkerBase dbAdmin)
        {
            try
            {
                var users = new List<UserBAL>();

                string Q = "Select Distinct US.ID, US.FirstName, US.LastName From [dbo].[tblLayers] LY INNER JOIN  [dbo].tblUsers US on LY.UserID = US.ID  Where US.AccountID = @AccountID  AND US.ID <> @UserID";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@AccountID", accountID));
                sqlParams.Add(new SqlParameter("@UserID", userID));
                DataTable data = dbAdmin.ExecuteSQLQueryReturnDataTable(Q, sqlParams);

                foreach (DataRow row in data.Rows)
                {
                    var user = new UserBAL();
                    user.ID = Convert.ToInt32(row["ID"]);
                    user.FirstName = Convert.ToString(row["FirstName"]);
                    user.LastName = Convert.ToString(row["LastName"]);

                    users.Add(user);

                }

                return users;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetUsersWithLayersConfigured. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// To import Data Parameters
        /// </summary>
        public Boolean ImportLayerConfigurations(int sourceUserID, int targetUserID, DBWorkerBase dbAdmin)
        {
            try
            {
                string Q = "exec sp_ImportData @SourceUserID = " + sourceUserID + ",  @TargetUserID = " + targetUserID + ", @ImportType='Layers'";
                int Result = dbAdmin.ExecuteDMLCommand(Q);
                if (Result > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ImportLayerConfigurations. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Imports the selected Account Layers Layer setting's to current user.
        /// </summary>
        public List<string> ImportLayerConfigurationsForSelectedAccount(int sourceAccountID, int targetAccountID, int sourceUserID, int targetUserID, DBWorkerBase dbMan)
        {
            try
            {
                string Q = "SELECT t.tableName, l.ID, l.userID, l.tableID, l.xLocType, l.yLocType, l.yOffset, l.dateCol1, l.dateCol2, l.height, " +
                          "l.defaultColour, l.defaultIcon, l.feedbackColumnsXML, l.conditionalFormatXML FROM " + this.tableNameForLayers +
                          " AS l INNER JOIN tblTableInfo AS t ON (t.ID = l.tableID) WHERE userID = @userID";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@userID", sourceUserID));
                DataTable data = dbMan.ExecuteSQLQueryReturnDataTable(Q, sqlParams);
                List<string> notImported = new List<string>();
                if (data.Rows.Count > 0)
                {
                    foreach (DataRow row in data.Rows)
                    {
                        var sqlParamsTable = new List<SqlParameter>();
                        sqlParamsTable.Add(new SqlParameter("@tableName", row["tableName"]));
                        sqlParamsTable.Add(new SqlParameter("@targetAccountID", targetAccountID));
                        string queryForTableID = "select ID from tblTableInfo where tableName=@tableName and accountID=@targetAccountID";

                        DataTable tableIDsData = dbMan.ExecuteSQLQueryReturnDataTable(queryForTableID, sqlParamsTable);
                        if (tableIDsData.Rows.Count > 0)
                        {
                            DataRow drTable = tableIDsData.Rows[0];
                            //Delete Existing layers with same table ID for seletced user
                            string deleteQuery = "Delete [dbo].[tblLayers] Where tableID =" + drTable["ID"] + " and userId=" + targetUserID;
                            int rows = dbMan.ExecuteDMLCommand(deleteQuery);

                            var layer = new Layer();
                            layer.UserID = Convert.ToInt32(targetUserID);
                            layer.TableID = Convert.ToInt32(drTable["ID"]);
                            layer.XLocType = Convert.ToString(row["xLocType"]);
                            layer.YLocType = Convert.ToString(row["yLocType"]);
                            layer.YOffset = Convert.ToInt32(row["yOffset"]);
                            layer.DateCol1 = Convert.ToString(row["dateCol1"]);
                            layer.DateCol2 = Convert.ToString(row["dateCol2"]);
                            layer.Height = Convert.ToInt32(row["height"]);
                            layer.DefaultColour = Convert.ToString(row["defaultColour"]);
                            layer.DefaultIcon = Convert.ToString(row["defaultIcon"]);
                            layer.FeedbackColumnsXML = Convert.ToString(row["feedbackColumnsXML"]);
                            layer.ConditionalFormatXML = Convert.ToString(row["conditionalFormatXML"]);

                            int insertStatus = dbMan.ExecuteInsertCommand(this.tableNameForLayers, layer.GetDataFields());
                        }
                        else
                        {
                            notImported.Add(row["tableName"].ToString());
                        }
                    }
                }
                return notImported;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetIsPrimaryAdminUserDetails. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Updates the General Options for a layer linked to a Segment Table
        /// </summary>        
        public bool UpdateLayerColumnsToShow(int layerID, List<string> colNamesToShow, DBWorkerBase dbAdmin)
        {
            try
            {
                var layer = new Layer();
                layer.UpdateFeedbackColumns(colNamesToShow);
                
                var updateValues = new Dictionary<string, object>();
                updateValues.Add("feedbackColumnsXML",layer.FeedbackColumnsXML);

                var whereConditions = new Dictionary<string, object>();
                whereConditions.Add("ID", layerID);

                int n = dbAdmin.ExecuteUpdateCommand(this.tableNameForLayers, updateValues, whereConditions);
                if (n == 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in UpdateSegmentLayerOptions. Details: " + ex.Message);
            }

        }

        public Layer GetLayerInfo(int layerID, DBWorkerBase dbAdmin)
        {
            try
            {
                var layers = new List<Layer>();

                string Q = "SELECT t.tableLabel, l.ID, l.userID, l.tableID, l.xLocType, l.yLocType, l.yOffset, l.dateCol1, l.dateCol2, l.height, " +
                           "l.defaultColour, l.defaultIcon, l.feedbackColumnsXML, l.conditionalFormatXML FROM " + this.tableNameForLayers +
                           " AS l INNER JOIN tblTableInfo AS t ON (t.ID = l.tableID) WHERE l.ID = @layerID ORDER BY t.tableLabel";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@layerID", layerID));
                DataTable data = dbAdmin.ExecuteSQLQueryReturnDataTable(Q, sqlParams);

                if (data.Rows.Count == 0) { throw new Exception("Cannot find layer with ID = " + layerID); };
                if (data.Rows.Count > 1) { throw new Exception("Multiple layers found with ID = " + layerID); };

                DataRow row = data.Rows[0];
                var layer = new Layer();
                layer.ID = Convert.ToInt32(row["ID"]);
                layer.UserID = Convert.ToInt32(row["userID"]);
                layer.TableID = Convert.ToInt32(row["tableID"]);
                layer.LayerName = Convert.ToString(row["tableLabel"]);
                layer.XLocType = Convert.ToString(row["xLocType"]);
                layer.YLocType = Convert.ToString(row["yLocType"]);
                layer.YOffset = Convert.ToInt32(row["yOffset"]);
                layer.DateCol1 = Convert.ToString(row["dateCol1"]);
                layer.DateCol2 = Convert.ToString(row["dateCol2"]);
                layer.Height = Convert.ToInt32(row["height"]);
                layer.DefaultColour = Convert.ToString(row["defaultColour"]);
                layer.DefaultIcon = Convert.ToString(row["defaultIcon"]);
                layer.FeedbackColumnsXML = Convert.ToString(row["feedbackColumnsXML"]);
                layer.ConditionalFormatXML = Convert.ToString(row["conditionalFormatXML"]);
                
                return layer;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetLayerInfo. Details: " + ex.Message);
            }
        }

        public List<Layer> GetLayersForUser(int userID, DBWorkerBase dbAdmin)
        {
            try
            {
                var layers= new List<Layer>();

                string Q = "SELECT t.tableLabel, l.ID, l.userID, l.tableID, l.xLocType, l.yLocType, l.yOffset, l.dateCol1, l.dateCol2, l.height, " +
                           "l.defaultColour, l.defaultIcon, l.feedbackColumnsXML, l.conditionalFormatXML FROM " + this.tableNameForLayers +
                           " AS l INNER JOIN tblTableInfo AS t ON (t.ID = l.tableID) WHERE userID = @userID ORDER BY t.tableLabel";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@userID", userID));
                DataTable data = dbAdmin.ExecuteSQLQueryReturnDataTable(Q, sqlParams);

                foreach (DataRow row in data.Rows)
                {
                    var layer = new Layer();
                    layer.ID = Convert.ToInt32(row["ID"]);
                    layer.UserID = Convert.ToInt32(row["userID"]);
                    layer.TableID = Convert.ToInt32(row["tableID"]);
                    layer.LayerName = Convert.ToString(row["tableLabel"]);
                    layer.XLocType = Convert.ToString(row["xLocType"]);
                    layer.YLocType = Convert.ToString(row["yLocType"]);
                    layer.YOffset = Convert.ToInt32(row["yOffset"]);
                    layer.DateCol1 = Convert.ToString(row["dateCol1"]);
                    layer.DateCol2 = Convert.ToString(row["dateCol2"]);
                    layer.Height = Convert.ToInt32(row["height"]);
                    layer.DefaultColour = Convert.ToString(row["defaultColour"]);
                    layer.DefaultIcon = Convert.ToString(row["defaultIcon"]);
                    layer.FeedbackColumnsXML = Convert.ToString(row["feedbackColumnsXML"]);
                    layer.ConditionalFormatXML = Convert.ToString(row["conditionalFormatXML"]);
                    layers.Add(layer);
                }

                return layers;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetLayersForUser. Details: " + ex.Message);
            }
        }

        public List<Layer> GetLayersForPrimaryAdminAccount(int accountID, DBWorkerBase dbMan)
        {
            try
            {
                var layers = new List<Layer>();

                string Q = "SELECT t.tableLabel, l.ID, l.userID, l.tableID, l.xLocType, l.yLocType, l.yOffset,";
                Q = Q + "l.dateCol1, l.dateCol2, l.height,l.defaultColour, l.defaultIcon, l.feedbackColumnsXML, l.conditionalFormatXML FROM " + this.tableNameForLayers + " AS l";
                Q = Q + " INNER JOIN tblTableInfo AS t ON (t.ID = l.tableID) inner join tblUsers AS u on l.userID=u.ID WHERE u.accountID = @accountID and u.isPrimaryAdmin=1 ORDER BY t.tableLabel";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@accountID", accountID));
                DataTable data = dbMan.ExecuteSQLQueryReturnDataTable(Q, sqlParams);

                foreach (DataRow row in data.Rows)
                {
                    var layer = new Layer();
                    layer.ID = Convert.ToInt32(row["ID"]);
                    layer.UserID = Convert.ToInt32(row["userID"]);
                    layer.TableID = Convert.ToInt32(row["tableID"]);
                    layer.LayerName = Convert.ToString(row["tableLabel"]);
                    layer.XLocType = Convert.ToString(row["xLocType"]);
                    layer.YLocType = Convert.ToString(row["yLocType"]);
                    layer.YOffset = Convert.ToInt32(row["yOffset"]);
                    layer.DateCol1 = Convert.ToString(row["dateCol1"]);
                    layer.DateCol2 = Convert.ToString(row["dateCol2"]);
                    layer.Height = Convert.ToInt32(row["height"]);
                    layer.DefaultColour = Convert.ToString(row["defaultColour"]);
                    layer.DefaultIcon = Convert.ToString(row["defaultIcon"]);
                    layer.FeedbackColumnsXML = Convert.ToString(row["feedbackColumnsXML"]);
                    layer.ConditionalFormatXML = Convert.ToString(row["conditionalFormatXML"]);
                    layers.Add(layer);
                }

                return layers;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetLayersForPrimaryAdminAccount. Details: " + ex.Message);
            }
        }

        public List<NameAndIDData> GetLayerNamesAndIDsForUser(int userID, DBWorkerBase dbAdmin)
        {
            try
            {
                var layers = new List<NameAndIDData>();

                string Q = "SELECT t.tableLabel, l.ID FROM " + this.tableNameForLayers +
                           " AS l INNER JOIN tblTableInfo AS t ON (t.ID = l.tableID) WHERE userID = @userID ORDER BY t.tableLabel";
                var sqlParams = new List<SqlParameter>();
                sqlParams.Add(new SqlParameter("@userID", userID));
                DataTable data = dbAdmin.ExecuteSQLQueryReturnDataTable(Q, sqlParams);

                foreach (DataRow row in data.Rows)
                {
                    var inf = new NameAndIDData();
                    inf.Value = Convert.ToInt32(row["ID"]);
                    inf.Name = Convert.ToString(row["tableLabel"]);
                    layers.Add(inf);
                }

                return layers;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetLayerNamesAndIDsForUser. Details: " + ex.Message);
            }
        }

        public bool AddNewLayerOK(Layer layer, DBWorkerBase dbAdmin)
        {
            try
            {
                if (layer.UserID <= 0) throw new Exception("Cannot add layer with userID = null");
                int n = dbAdmin.ExecuteInsertCommandAndReturnIdentity(this.tableNameForLayers, layer.GetDataFields());
                if (n > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }                
            }
            catch (Exception ex)
            {
                throw new Exception("Error in AddNewLayerOK. Details: " + ex.Message);
            }

        }

        #endregion


        public DataTable GetIsPrimaryAdminUserDetails(DBWorkerBase dbMan, int AccountId)
        {
            try
            {
                string Q = "select * from tblUsers where accountID=" + AccountId + " and isPrimaryAdmin=1";
                DataTable data = dbMan.ExecuteSQLQueryReturnDataTable(Q, null);
                return data;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetIsPrimaryAdminUserDetails. Details: " + ex.Message);
            }
        }
    }
}
