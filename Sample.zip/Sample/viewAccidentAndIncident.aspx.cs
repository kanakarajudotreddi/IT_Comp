﻿using junoViewerLib.BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JunoViewer_Web.pages.TRAC
{
    public partial class viewAccidentAndIncident : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                UserBAL userBAL = new UserBAL();
                userBAL.InsertUserLog("TRAC Accidents and Incidents View is opened");
            }
        }
    }
}