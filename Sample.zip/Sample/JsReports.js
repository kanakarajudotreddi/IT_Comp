﻿var growthrate = {};
var graphHelper = new JV_GraphSetupHelper();

growthrate.FillDuration = function () {
    ju.clearListBox($("#lstDuration")[0]);
    var months = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"];
    var currentDate = new Date();
    for (var i = 0; i < 24; i++) {
        var nextMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, currentDate.getDate());
        var currentMonth = months[nextMonth.getMonth()];
        var currentYear = nextMonth.getFullYear();
        var Name = currentMonth + "-" + currentYear;
        ju.addListItem($("#lstDuration")[0], Name, Name);

    }
}

growthrate.GetSelectedReports = function () {
    ju.doAjaxWebService("/webServices/trafficService.asmx/GetReports","", growthrate.showReports, ju.handleWebServiceError);
}

growthrate.showReports = function (data) {
    if (data && data.d) {
        for (var i = 0; i < data.d.length; i++) {
            var type = "Reports";
            var value = data.d[i].Value;
            var Name = data.d[i].Name;
            var id = data.d[i].Value;
            junoCheck.addCheckListItem($("#divReportCheckboxList"), Name, type + id, false, "txt" + i, value, null);
        }
    }
}

growthrate.ShowGraph = function () {
    var parameter = $("#lstParameter :selected").val()
    var checkboxInfo = junoCheck.getAllCheckedItems($("#divReportCheckboxList"));
    if (checkboxInfo.length > 1) {
        $("#divReportCheckboxList").css("border-color", "#d7e0e2");
        var chkIDs = "";
        for (var i = 0; i < checkboxInfo.length; i++) {
            var info = checkboxInfo[i];
            if (i != (checkboxInfo.length - 1)) {
                chkIDs = chkIDs + info.value + "#";
            }
            else {
                chkIDs = chkIDs + info.value;
            }

        }

        if (parameter != "Select" && chkIDs.length != 0) {
            $("#divThrobberClassImg").css("display", "block");
            $("#jqxChart").css("display", "none");
            //var data = "{ Parameter : '" + parameter + "' }";
            var data = "{ ReportID : '" + chkIDs + "' , Parameter : '" + parameter + "' }";
            ju.doAjaxWebService("/webServices/trafficService.asmx/GetGrowthRatesByParameter", data, growthrate.showBarchart, ju.handleWebServiceError);
        }
    }
    else {
        $("#divReportCheckboxList").css("border-color", "#e74c3c");
    }
}

growthrate.GetMonthForProjected = function () {
    ju.doAjaxWebService("/webServices/trafficService.asmx/GetProjectedMonth", "", growthrate.FillMonthForProjected, ju.handleWebServiceError);
}

growthrate.FillMonthForProjected = function (data) {
    $("#hdnProjectedMonth").val(data.d);
}

growthrate.GetReports = function () {
    $("#throbber").css("display", "block");
    $('#throbImage').css("display", "block");
    ju.doAjaxWebService("/webServices/trafficService.asmx/GetReports", "", growthrate.BuildReports, ju.handleWebServiceError);

}

growthrate.BuildReports = function (data) {
    // prepare the data
    var source =
    {
        datatype: "json",

        datafields: [
            { name: 'Value' },
            { name: 'Name', type: 'string' },
            { name: 'routePosition', type: 'number' },
            { name: 'direction' },
            { name: 'routeStart' },
            { name: 'routeEnd' },
            { name: 'growth_ADT' },
            { name: 'growth_ADTT' },
            { name: 'growth_E80perHeavy'},
            { name: 'projected_ADT' },
            { name: 'projected_ADTT' },
            { name: 'projected_E80perHeavy' }
        ],
        localdata: data.d
    };

    var dataAdapter = new $.jqx.dataAdapter(source);

    $('#jqxgrid').jqxGrid(
    {
        width: divWidth,
        height: 700,
        source: dataAdapter,
        columnsresize: true,
        sortable: true,
        altrows: true,
        enabletooltips: true,
        editable: true,
        filterable: true,
        altrows: true,
        columns: [
            { text: 'Link-ID', datafield: 'Value', editable: false, sortable: true, hidden:true},
            {
                text: 'Link tName', datafield: 'Name', columntype: 'textbox', editable: true, sortable: true,
                validation: function (cell, value) {
                    if (value != "") {                       
                        //$('#jqxgrid').css("display", "none");
                        //$("#throbber").css("display", "block");
                        //$('#throbImage').css("display", "block");
                        var datarow = $("#jqxgrid").jqxGrid('getrowdata', cell.row);
                        var ReportId = parseInt(datarow.Value);
                        var Routeposition = parseInt($('#hdnrp').val());
                        var Reportname = $('#hdnLinkName').val(value);
                        var data = "{ ReportID : '" + ReportId + "' , routePosition : '" + Routeposition + "' , reportName : '" + value + "' }";
                        ju.doAjaxWebService("/webServices/trafficService.asmx/UpdateTrafficGrid", data, function (params) {
                            if (params.d) {
                                //growthrate.GetReports();

                            }
                            else {
                                return true
                            }
                        }, ju.handleWebServiceError);
                        return true;
                    }
                    else {
                        return { result: false, message: "Please Enter Valid Link Name" };
                    }
                },

            },

            {
                text: 'Index', datafield: 'routePosition',columntype: 'numberinput', filtertype: 'textbox', editable: true, sortable: true,
                validation: function (cell, value) {
                if (value > 0 || value == 0) {
                    //$('#jqxgrid').css("display", "none");
                    //$("#throbber").css("display", "block");
                    //$('#throbImage').css("display", "block");
                    var datarow = $("#jqxgrid").jqxGrid('getrowdata', cell.row);
                    var ReportId = parseInt(datarow.Value);
                    var Reportname = datarow.Name;
                    var Routeposition = $('#hdnrp').val(value);
                    var data = "{ ReportID : '" + ReportId + "' , routePosition : '" + value + "' , reportName : '" + Reportname + "' }";
                    ju.doAjaxWebService("/webServices/trafficService.asmx/UpdateTrafficGrid", data, function (params) {
                        if (params.d) {
                            //growthrate.GetReports();
                            
                        }
                        else {
                            return true
                        }
                    }, ju.handleWebServiceError);
                    return true;
                    
                }
                else {
                    return { result: false, message: "Please Enter Valid Route Index" };;
                }
                },

            },
            { text: 'Direction', datafield: 'direction', editable: false,selectionmode: 'columnselect',sortable: true},
            { text: 'Start', datafield: 'routeStart', editable: false, sortable: true, selectionmode: 'columnselect' },
            { text: 'End', datafield: 'routeEnd', editable: false, sortable: true, selectionmode: 'columnselect' },
            { text: 'gr_ADT', datafield: 'growth_ADT', editable: false, sortable: true },
            { text: 'gr_ADTT', datafield: 'growth_ADTT', editable: false, sortable: true },
            { text: 'gr_E80', datafield: 'growth_E80perHeavy', editable: false, sortable: true },
            { text: 'pr_ADT', datafield: 'projected_ADT', editable: false, sortable: true },
            { text: 'pr_ADTT', datafield: 'projected_ADTT', editable: false, sortable: true },
            { text: 'pr_E80', datafield: 'projected_E80perHeavy', editable: false, sortable: true }
        ]
    });
    $("#throbber").css("display", "none");
    $('#throbImage').css("display", "none");
    $('#jqxgrid').css("display", "block");
}

growthrate.validateReportName = function (value,index) {
        if (value != "") {
            var data = "{ ReportName : '" + value + "' }";
            ju.doAjaxWebService("/webServices/trafficService.asmx/Searchreports", data, function (params) {
                if (params.d == false) {
                    $("#jqxgrid").jqxGrid('showvalidationpopup', index, 'Name', "Duplicate link name found, please review and edit link name.");
                }
                else {
                    return true
                }
            }, ju.handleWebServiceError, false);
        }
        else {
            $("#jqxgrid").jqxGrid('showvalidationpopup', index, 'Name', "Report name exists");
        }
}

growthrate.showBarchart = function (data) {
    if (data && data.d && data.d.length > 0) {
        var dataForBarChart = "{ min : '" + parseFloat(data.d[0].GrowthMin) + "' , max : '" + parseFloat(data.d[0].GrowthMax) + "' , intervels : '" + 10 + "' }";
        ju.doAjaxWebService("/webServices/utilsService.asmx/GetXAxisValues", dataForBarChart, function (params) {
            if (params.d) {
                $('#jqxChart').show();
                var options = graphHelper.getsetupBarChatOptions();

                if ($("#lstParameter :selected").text().toLowerCase().indexOf("projected") >= 0) {
                    options.yTitle = $("#lstParameter :selected").text() + " to " + $("#hdnProjectedMonth").val();
                }
                else {
                    options.yTitle = $("#lstParameter :selected").text() + " Rate";
                }
                options.xmin = params.d.minimum;
                options.xmax = params.d.maximum;
                options.unitInterval = params.d.increm;

                filename = $("#lstParameter :selected").text() + "_Chart.jpeg";
                graphHelper.setupBarChat($('#jqxChart'), data, options);

                $("#jqxChart").css("display", "block");
                $("#divThrobberClassImg").css("display", "none");
                $("#SaveAsImage").show();
                $("#copyToClipBoard").show();
            }
        }, ju.handleWebServiceError);
    }
    else {
        bootbox.alert("No growth rate data found for selected information");
        $("#SaveAsImage").hide();
        $("#divThrobberClassImg").css("display", "none");
        $("#jqxChart").css("display", "none");
    }
}

growthrate.DeleteReport = function () {
    if ($('#hdnReportID').val() != "") {
        bootbox.confirm("Are you sure you want to delete the selected Report?", function (result) {
            if (result == true) {
                $('#jqxgrid').css("display", "none");
                $("#throbber").css("display", "block");
                $('#throbImage').css("display", "block");

                var ReportId = parseInt($('#hdnReportID').val());
                var data = "{ ReportID : '" + ReportId + "' }";
                ju.doAjaxWebService("/webServices/trafficService.asmx/DeleteReports", data, function (params) {
                    if (params.d == true) {
                        jvWeb_Utils.UpdateLogStatus("Link:'" + ReportId + "' Deleted Succesfully.");
                        growthrate.GetReports();
                    }
                }, ju.handleWebServiceError);
            }
        }).find("a.null").addClass("btn-primary").removeClass("null");
    }
    else {
        bootbox.alert("First select the Report to delete, then try again");
    }
}

growthrate.UpdateMonthDate = function () {
    $('#hdnMonthDate').val($('#monthpicker').val());
    if (growthrate.ValidMonth()) {
        $('#errorFuture').css("display", "none");
        $('#errorwrong').css("display", "none");
        $('#btnOkShowMonth').attr("disabled", "disabled");
        $('#btnCancelShowMonth').attr("disabled", "disabled");
        $('#crossbtn').css("display", "none");
        $('#loadingdata').css("display", "block");

        var data = "{ MonthDate : '" + $('#monthpicker').val() + "' }";
        ju.doAjaxWebService("/webServices/trafficService.asmx/InsertGlobalValue", data, growthrate.UpdateReportsDataUsingNameValuePair, ju.handleWebServiceError);
    }
}

growthrate.ValidMonth = function () {
    var dateprojected = "01" + "-" + $('#hdnMonthDate').val();
    var dateFormat = 0;
    var datefuture = 0;
    var CurrentDate = new Date();
    var projdate = new Date(dateprojected);
    var fromdate = new Date("12/01/" + (CurrentDate.getFullYear() - 1));
    var todate = new Date("12/31/" + CurrentDate.getFullYear() + 2);
    //var todate = Date.parse(CurrentDate.getMonth() + "/" + CurrentDate.getDate() + "/" + (CurrentDate.getFullYear() - 5));

    if (dateprojected.length < 11 || junoValid.validateDateOk(dateprojected) > 0) {
        $('#errorFuture').css("display", "none");
        $('#errorwrong').css("display", "block");
        dateFormat = dateFormat + 1;
    }
    else if (((projdate >= fromdate) && (projdate <= todate)) == false) {
        $('#errorwrong').css("display", "none");
        dateFormat = dateFormat + 1;
        $('#errorFuture').text("Allowable date range is currently from Dec-" + (CurrentDate.getFullYear() - 1) + " to Dec-" + (CurrentDate.getFullYear() + 2));
        $('#errorFuture').css("display", "block");
        datefuture = datefuture + 1;
    }
    if (dateFormat > 0 || datefuture > 0) {
        return false
    }
    else {
        return true
    }
}


growthrate.UpdateReportsDataUsingNameValuePair = function (data) {
    var date = "20-" + $('#hdnMonthDate').val();
    var data = "{ GDateTo : '" + date + "' }";
    ju.doAjaxWebService("/webServices/trafficService.asmx/CalculateReportData", data, growthrate.UpdatedReportsData, ju.handleWebServiceError);
}


growthrate.UpdatedReportsData = function (data) {
    $('#btnOkShowMonth').attr("disabled", false);
    $('#btnCancelShowMonth').attr("disabled", false);
    $('#crossbtn').css("display", "block");
    $('#loadingdata').css("display", "none");
    $('#mdlShowMonths').modal("hide");
    $('#jqxgrid').css("display", "none");
    jvWeb_Utils.UpdateLogStatus("Growth Rate Calculated For: '" + $('#hdnMonthDate').val() + "' in Manage Traffic Reports page.");
    growthrate.GetReports();
}


growthrate.GetProjectedMonth = function () {
    $('#errorwrong').css("display", "none");
    $('#errorFuture').css("display", "none");
    ju.doAjaxWebService("/webServices/trafficService.asmx/GetProjectedMonth", "", growthrate.FillProjectedMonth, ju.handleWebServiceError);
}


growthrate.FillProjectedMonth = function (data) {
    $('#monthpicker').val(data.d);
}
