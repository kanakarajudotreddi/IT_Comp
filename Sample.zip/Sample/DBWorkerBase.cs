﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using junoViewerLib.BAL;

namespace junoViewerLib.DAL
{
    /// <summary>
    /// Base class for data access components
    /// </summary>
    public class DBWorkerBase : IDBWorker
    {

        #region Variables

        private System.Globalization.DateTimeFormatInfo CultureDate = new System.Globalization.CultureInfo("en-NZ",false).DateTimeFormat;
        protected string m_connectionString;


        #endregion
       
        #region Startup
       
        /// <summary>
        /// Default constructor. Creates the connection string for SQL Server
        /// </summary>
        /// <param name="connString">Full valid connection string for SQL need to supplied</param>
        public DBWorkerBase(string connString) {
            this.m_connectionString = connString;
        }
                
        /// <summary>
        /// Opens the connection if it is not already open
        /// </summary>
        /// <param name="connection"></param>
        public void OpenConnection(SqlConnection connection) {
            try 
	    {	        
		    if (connection.State != ConnectionState.Open)
	        {
		     connection.Open();
	        }
	    }
	    catch (Exception ex)
	    {
		    throw new Exception("Error opening Connection. Details: " + ex.Message);
	    }
        }

        #endregion

        #region Properties

        public string ConnectionString
        {
            get
            {
                return this.m_connectionString;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Inserts data into a table with mappings to match source and target tables contained in parameter tableInfo
        /// </summary>        
        public bool BulkInsertDataTable(TableInfo tableInfo, DataTable data)
        {
                 SqlConnection sqlCon = new SqlConnection(this.ConnectionString);                                  
                try
                {
                    sqlCon.Open();
                // Create the SqlBulkCopy object.  
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(sqlCon))
                    {
                        bulkCopy.DestinationTableName = tableInfo.TableName;

                        foreach (DataColumn sourceCol in data.Columns)
                        {                            
                            ColumnInfo targetCol = tableInfo.GetColumnBySourceColumnName(sourceCol.ColumnName);
                            if (targetCol == null) { throw new Exception("Column " + sourceCol.ColumnName + "' was not found on target table."); }
                            if (String.IsNullOrEmpty(targetCol.SourceColumn)) { throw new Exception("Column " + sourceCol.ColumnName + "' has no source to target mapping. All columns require mappings."); }

                            // Set up the column mappings by name.
                            SqlBulkCopyColumnMapping columnMapping = new SqlBulkCopyColumnMapping(sourceCol.ColumnName,targetCol.ColumnName);
                            bulkCopy.ColumnMappings.Add(columnMapping);
                        }                        
                    
                        try
                        {
                            bulkCopy.BulkCopyTimeout = 360;                   
                            bulkCopy.WriteToServer(data);
                            bulkCopy.Close();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Error doing bulkCopy.WriteToServer(). Details: " + ex.Message);
                        }        
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error in BulkInsertDataTable. Details: " + ex.Message);
                }
                finally
                {
                    sqlCon.Close();
                }            
        }

        /// <summary>
        /// Inserts data into a table assuming column names in data parameter matches exactly those on target table
        /// </summary>        
        public bool BulkInsertDataTable(string targetTableName, DataTable data)
        {
            if (data.Rows.Count > 0)
            {
                SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
                try
                {
                    sqlCon.Open();
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(sqlCon))
                    {
                        bulkCopy.DestinationTableName = targetTableName;

                        foreach (DataColumn sourceCol in data.Columns)
                        {                            
                            // We assume source and target column names are the same
                            SqlBulkCopyColumnMapping columnMapping = new SqlBulkCopyColumnMapping(sourceCol.ColumnName, sourceCol.ColumnName);
                            bulkCopy.ColumnMappings.Add(columnMapping);
                        }    

                        try
                        {
                            bulkCopy.BulkCopyTimeout = 360;
                            bulkCopy.WriteToServer(data);
                            bulkCopy.Close();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Error doing bulkCopy.WriteToServer(). Details: " + ex.Message);
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error in BulkInsertDataTable. Details: " + ex.Message);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// To execute a parameterized simple SELECT query (no JOINS) with parameters
        /// </summary>
        ///<param name="strReturnTableName">Name of the table in the returned data set</param>
        ///<param name="sourceTableName">Name of the database table to select data from</param>
        ///<param name="columnsToGet">List of column names to retrieve in the source table</param>
        ///<param name="whereConditions">Column names (as keys) and query values (as values) for where query. Pass null to omit and WHERE conditions</param>
        ///<param name="distinctQuery">True if the query must return unique values (i.e. 'SELECT DISTINCT...')</param>
        /// <returns>Return dataset with specified table name</returns>
        /// <remarks></remarks>
        public DataSet ExecuteSQLQueryReturnDataset(string strReturnTableName, string sourceTableName, List<string> columnsToGet, Dictionary<string,object> whereConditions, bool distinctQuery = false)
        {            
            try
            {
                var qBuilder = new QueryBuilderMSSql();
                SqlCommand sqlCmd = qBuilder.GetSelectCommand(sourceTableName, columnsToGet, whereConditions, distinctQuery);
                return this.ExecuteSQLQueryReturnDataset(strReturnTableName, sqlCmd);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataset. Details: " + ex.Message);
            }            
        }

        /// <summary>
        /// To execute a parameterized simple SELECT query (no JOINS) with parameters
        /// </summary>        
        ///<param name="sourceTableName">Name of the database table to select data from</param>
        ///<param name="columnsToGet">List of column names to retrieve in the source table</param>
        ///<param name="whereConditions">Column names (as keys) and query values (as values) for where query. Pass null to omit and WHERE conditions</param>
        ///<param name="distinctQuery">True if the query must return unique values (i.e. 'SELECT DISTINCT...')</param>
        /// <returns>Return dataset with specified table name</returns>
        /// <remarks></remarks>
        public DataTable ExecuteSQLQueryReturnDataTable(string sourceTableName, List<string> columnsToGet, Dictionary<string, object> whereConditions, bool distinctQuery = false) 
        {
            try
            {
                DataSet dSet = this.ExecuteSQLQueryReturnDataset("tmp", sourceTableName, columnsToGet, whereConditions, distinctQuery);
                return dSet.Tables[0];
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataTable. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// To execute a parameterized select query with/without parameters
        /// </summary>
        /// <param name="strQueryText">Query string represents select statements with parameters</param>
        /// <param name="iParameters">Parameters list comprises of values to assign</param>
        /// <param name="strReturnTableName">To specify data table name of DataSet</param>
        /// <returns>Return dataset with specified table name</returns>
        /// <remarks></remarks>
        public DataTable ExecuteSQLQueryReturnDataTable(string strQueryText, List<SqlParameter> iParameters)
        {
            try
            {
                DataSet dSet = this.ExecuteSQLQueryReturnDataset(strQueryText, iParameters,"tmp");
                return dSet.Tables[0];
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataTable. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// To execute a parameterized select query with parameters
        /// </summary>
        /// <param name="strQueryText">Query string represents select statements with parameters</param>
        /// <param name="iParameters">Parameters list comprises of values to assign</param>
        /// <param name="strReturnTableName">To specify data table name of DataSet</param>
        /// <returns>Return dataset with specified table name</returns>
        /// <remarks></remarks>
        public DataSet ExecuteSQLQueryReturnDataset(string strQueryText, List<SqlParameter> iParameters, string strReturnTableName)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                sqlCon.Open();
                DataSet dsResult = new DataSet();
                SqlDataAdapter sqlDtAdpt = new SqlDataAdapter();
                sqlDtAdpt.SelectCommand = BuildCommand(strQueryText, iParameters, sqlCon);
                sqlDtAdpt.SelectCommand.CommandType = CommandType.Text;
                sqlDtAdpt.SelectCommand.CommandTimeout = 7000;

                sqlDtAdpt.Fill(dsResult, strReturnTableName);
                sqlDtAdpt.Dispose();
                return dsResult;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataset. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }


        /// <summary>
        /// To return Dataadapter to maintaing fully connected operations to Database table via dataset / datatable
        /// </summary>
        /// <param name="strQueryText">Query to fill dataset</param>
        /// <param name="iParameters">Parameters set</param>
        /// <returns>Return dataadapter and </returns>
        public SqlDataAdapter ExecuteSQLQueryReturnDataAdapter(string strQueryText, List<SqlParameter> iParameters, out SqlConnection sqlConReturn)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                sqlCon.Open();
                DataSet dsResult = new DataSet();
                SqlDataAdapter sqlDtAdpt = new SqlDataAdapter();
                sqlDtAdpt.SelectCommand = BuildCommand(strQueryText, iParameters, sqlCon);
                sqlDtAdpt.SelectCommand.CommandType = CommandType.Text;
                sqlDtAdpt.SelectCommand.CommandTimeout = 7000;
                sqlConReturn = sqlCon;
                return sqlDtAdpt;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataset. Details: " + ex.Message);
            }
            finally
            {
                //Connection must be open as Adapter and connection returning back. Connection will be closed at upper level.
                //sqlCon.Close(); 
            }
        }


        /// <summary>
        /// To execute a SQL Insert Command
        /// </summary>
        ///<param name="targetTableName">Name of the database table in which to insert values</param>  
        ///<param name="insertValues">Column names (as keys) and insert values (as values) for query</param>
        /// <returns>Returns integer of number rows affected</returns>
        /// <remarks></remarks>
        public int ExecuteInsertCommand(string targetTableName, Dictionary<string, object> insertValues)
        {                   
            try
            {
                var qBuilder = new QueryBuilderMSSql();
                SqlCommand sqlCmd = qBuilder.GetInsertCommand(targetTableName, insertValues);
                return this.ExecuteDMLCommand(sqlCmd);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteInsertCommand. Details: " + ex.Message);
            }            
        }

        /// <summary>
        /// To execute any DML statement using a command supplied as parameter.
        /// </summary>
        /// <param name="sqlCmd">SQLCommand with commandstring and paramters set up as needed </param>        
        /// <returns>Returns integer of number rows affected</returns>
        /// <remarks></remarks>
        public int ExecuteInsertCommandAndReturnIdentity(string targetTableName, Dictionary<string, object> insertValues)
        {
           try
            {
                var qBuilder = new QueryBuilderMSSql();
                SqlCommand sqlCmd = qBuilder.GetInsertCommand(targetTableName, insertValues);
                return this.ExecuteDMLCommandAndReturnIdentity(sqlCmd);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteInsertCommandAndReturnIdentity. Details: " + ex.Message);
            }            
        }

        /// <summary>
        /// To execute a SQL Insert Command
        /// </summary>
        ///<param name="targetTableName">Name of the database table in which to update values</param>  
        ///<param name="insertValues">Column names (as keys) and update values (as values) for query</param>
        ///<param name="whereConditions">Column names (as keys) and query values (as values) for where query. Pass null to omit and WHERE conditions</param>
        /// <returns>Returns integer of number rows affected</returns>
        /// <remarks></remarks>
        public int ExecuteUpdateCommand(string targetTableName, Dictionary<string, object> updateValues, Dictionary<string,object> whereConditions)
        {                  
            try
            {
                var qBuilder = new QueryBuilderMSSql();
                SqlCommand sqlCmd = qBuilder.GetUpdateCommand(targetTableName, updateValues,whereConditions);
                return this.ExecuteDMLCommand(sqlCmd);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteUpdateCommand. Details: " + ex.Message);
            }            
        }

        /// <summary>
        /// To execute a SQL DELETE Command
        /// </summary>
        ///<param name="targetTableName">Name of the database table in which to delete values</param>          
        ///<param name="whereConditions">Column names (as keys) and query values (as values) for delete query. Pass null to omit any WHERE conditions</param>
        /// <returns>Returns integer of number rows affected</returns>        
        public int ExecuteDeleteCommand(string targetTableName, Dictionary<string, object> whereConditions)
        {
            try
            {
                var qBuilder = new QueryBuilderMSSql();
                SqlCommand sqlCmd = qBuilder.GetDeleteCommand(targetTableName, whereConditions);
                return this.ExecuteDMLCommand(sqlCmd);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteDeleteCommand. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// To execute any DML statement using a NON-parameterized query and return number records effected.
        /// </summary>
        /// <param name="strDMLCommandText">Specify command text WITHOUT any parameters</param>       
        /// <returns>Returns integer of number rows affected</returns>        
        public int ExecuteDMLCommand(string strDMLCommandText)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            int intRowsEffected = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqlCom = new SqlCommand(strDMLCommandText, sqlCon);
                intRowsEffected = sqlCom.ExecuteNonQuery();
                sqlCom.Dispose();
                return intRowsEffected;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteDMLCommand. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        /// <summary>
        /// To execute any DML statement using a parameterized query and return number records effected.
        /// </summary>
        /// <param name="strDMLCommandText">Specify command text with parameters</param>       
        /// <returns>Returns integer of number rows affected</returns>        
        public int ExecuteDMLCommand(string strDMLCommandText, List<SqlParameter> iParameters)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            int intRowsEffected = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqlCom = new SqlCommand(strDMLCommandText, sqlCon);
                foreach (SqlParameter sqlLocalParam in iParameters)
                {
                    sqlCom.Parameters.Add(sqlLocalParam);
                }
                intRowsEffected = sqlCom.ExecuteNonQuery();
                sqlCom.Dispose();
                return intRowsEffected;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteDMLCommand. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }
                                  

        #endregion

        #region Adding and Modifying TABLES

        /// <summary>
        ///  Creates a new table in the database
        /// </summary>
        /// <param name="tableName">name of the table. Must be a valid name, else error will be thrown</param>
        /// <param name="columns">List of columns, with properties set for name, autonumber = true/false, and allowNull = true/false</param>
        /// <returns></returns>
        public Boolean CreateDataTableOK(string tableName, List<ColumnInfo> columns)
        {
            try
            {
                string Q = "CREATE TABLE " + tableName + " (";
                for (int iCol = 0; iCol < columns.Count; iCol++)
                {
                    ColumnInfo col = columns[iCol];
                    if (col.AutoNumber)
                    {
                        Q = Q + col.ColumnName + " INT IDENTITY (1,1) NOT NULL PRIMARY KEY";
                    }
                    else
                    {
                        if (col.AllowNull == true)
                        {
                            Q = Q + col.ColumnName + " " + col.DataTypeForSQLServer + " NULL";
                        }
                        else
                        {
                            Q = Q + col.ColumnName + " " + col.DataTypeForSQLServer + " NOT NULL";
                        }

                    }
                    if (iCol == (columns.Count - 1))
                    {
                        Q = Q + ") ";

                    }
                    else
                    {
                        Q = Q + ", ";
                    }
                }
                int result = this.ExecuteDMLCommand(Q);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Error while adding Table = " + tableName + ". Details: " + ex.Message);
            }
        }

        #endregion
        
        #region Getting Information on Tables and Columns

        /// <summary>
        /// Gets a list of table names in the database
        /// </summary>
        /// <returns></returns>
        public List<string> GetTableNames()
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                var tables = new List<string>();
                sqlCon.Open();

            DataSet schemaDS = new DataSet();
            DataTable schemaTable = new DataTable();


            //To get user created tables from the database.
            SqlCommand Cmd = new SqlCommand("SELECT [object_id], name FROM SYS.TABLES WHERE type_desc = 'USER_TABLE' AND lock_escalation_desc = 'TABLE'", sqlCon);
            SqlDataAdapter adapter = new SqlDataAdapter(Cmd);
            adapter.Fill(schemaDS, "TableList");
            adapter.Dispose();
            Cmd.Dispose();

            schemaTable = schemaDS.Tables["TableList"];

            for (int iTable = 0; iTable < schemaTable.Rows.Count; iTable++)
			{
			    string tableName = Convert.ToString(schemaTable.Rows[iTable]["name"]);
                tables.Add(tableName); 
			}

            return tables;

            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetTableNames. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        }

        /// <summary>
        /// Gets a list of column names (keys) on a specific table, with the data type (value)
        /// </summary>
        public Dictionary<string, string> GetColumnInfo(string tableName)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                var info = new Dictionary<string, string>();
                sqlCon.Open();

            string Q = "SELECT TOP 1 * FROM " + tableName;
            var Cmd = new SqlCommand(Q, sqlCon);
            SqlDataReader reader = Cmd.ExecuteReader();
                for (int i = 0; i < reader.FieldCount; i++)
			    {
			        string fieldName = reader.GetName(i);
                    string fieldType = Convert.ToString(reader.GetFieldType(i));
                    info.Add(fieldName, fieldType);
			    }
                reader.Close();
                return info;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetColumnInfo. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        }

        /// <summary>
        /// Gets a list of column names (keys) on a specific table, with the data type (value)
        /// </summary>
        public Dictionary<string, object> GetColumnInfoWithDetailedColumnType(string tableName)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                var info = new Dictionary<string, object>();
                sqlCon.Open();

                string Q = "SELECT TOP 1 * FROM " + tableName;
                var Cmd = new SqlCommand(Q, sqlCon);
                SqlDataReader reader = Cmd.ExecuteReader();

                DataTable schemaTable = reader.GetSchemaTable();
                foreach (DataRow row in schemaTable.Rows)
                {
                    string fieldName = row["ColumnName"].ToString();
                    Dictionary<string, object> columnDetails = new Dictionary<string, object>();
                    columnDetails.Add("sqlDataType", row["DataType"].ToString());
                    columnDetails.Add("size", row["ColumnSize"].ToString());
                    info.Add(fieldName, columnDetails);
                }

                reader.Close();
                return info;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetColumnInfoWithDetailedColumnType. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        }

        /// <summary>
        /// Gets a list of column names (keys) on a specific table, with the data type (value)
        /// </summary>
        public Dictionary<string, string> GetColumnInfoNameWithSizes(string tableName)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);         
            try
            {
                var info = new Dictionary<string, string>();
                sqlCon.Open();
                string Q = "SELECT TOP 1 * FROM " + tableName;
                var Cmd = new SqlCommand(Q, sqlCon);
                SqlDataReader reader = Cmd.ExecuteReader();
                DataTable schemaTable = reader.GetSchemaTable();
                foreach (DataRow row in schemaTable.Rows)
                {
                    var name = row["ColumnName"];
                    var size = row["ColumnSize"];
                    string fieldName = name.ToString();
                    string fieldType = size.ToString();
                    info.Add(fieldName, fieldType);
                    //append these to a string or StringBuilder for writing out later...
                }
                reader.Close();
                return info;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetColumnInfo. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        }


        #endregion
        
        #region Private Methods

        /// <summary>
        /// To execute a parameterized select query with parameters
        /// </summary>
        /// <param name="strQueryText">Query string represents select statements with parameters</param>
        /// <param name="iParameters">Parameters list comprises of values to assign</param>
        /// <param name="strReturnTableName">To specify data table name of DataSet</param>
        /// <returns>Return dataset with specified table name</returns>
        /// <remarks></remarks>
        private DataSet ExecuteSQLQueryReturnDataset(string strReturnTableName, SqlCommand sqlCmd)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                sqlCon.Open();
                sqlCmd.Connection = sqlCon;
                DataSet dsResult = new DataSet();
                SqlDataAdapter sqlDtAdpt = new SqlDataAdapter();
                sqlDtAdpt.SelectCommand = sqlCmd;
                sqlDtAdpt.SelectCommand.CommandType = CommandType.Text;
                sqlDtAdpt.SelectCommand.CommandTimeout = 7000;

                sqlDtAdpt.Fill(dsResult, strReturnTableName);
                sqlDtAdpt.Dispose();
                return dsResult;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteSQLQueryReturnDataset. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        /// <summary>
        /// To execute any DML statement using a command supplied as parameter.
        /// </summary>
        /// <param name="sqlCmd">SQLCommand with commandstring and paramters set up as needed </param>        
        /// <returns>Returns integer of number rows affected</returns>
        /// <remarks></remarks>
        private int ExecuteDMLCommand(SqlCommand sqlCmd)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            int intRowsEffected = 0;
            try
            {                
                sqlCon.Open();
                sqlCmd.Connection = sqlCon;
                intRowsEffected = sqlCmd.ExecuteNonQuery();
                sqlCmd.Dispose();
                return intRowsEffected;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteDMLCommand. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        /// <summary>
        /// To execute any DML statement using a command supplied as parameter.
        /// </summary>
        /// <param name="sqlCmd">SQLCommand with commandstring and paramters set up as needed </param>        
        /// <returns>Returns identity (auto-number) value of newly inserted row</returns>
        /// <remarks></remarks>
        private int ExecuteDMLCommandAndReturnIdentity(SqlCommand sqlCmd)
        {
            SqlConnection sqlCon = new SqlConnection(this.ConnectionString);
            try
            {
                sqlCon.Open();
                if (sqlCmd.CommandText.ToUpper().Substring(0, 6) == "INSERT")
                {
                    sqlCmd.CommandText = sqlCmd.CommandText + " SELECT SCOPE_IDENTITY()";
                }
                sqlCmd.Connection = sqlCon;
                int id = Convert.ToInt32(sqlCmd.ExecuteScalar().ToString());
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExecuteDMLCommandAndReturnIdentit. Details: " + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        /// <summary>
        /// Build sql command and assign values to parameters
        /// </summary>
        /// <param name="strCommandText">Command text with parameters</param>
        /// <param name="iParameters">Parameters collection with values</param>
        /// <param name="IDBConn">Database connection object need to be provided</param>
        /// <returns>Returns data command upon successful build</returns>
        /// <remarks></remarks>
        SqlCommand BuildCommand(string strCommandText, List<SqlParameter> iParameters, SqlConnection sqlConn)
        {
            try
            {

                SqlCommand sqlCmd = new SqlCommand(strCommandText, sqlConn);

                if (iParameters != null)
                {
                    foreach (SqlParameter sqlLocalParam in iParameters)
                    {
                        sqlCmd.Parameters.Add(sqlLocalParam);
                    }
                }

                return sqlCmd;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in BuildCommand. Details: " + ex.Message);
            }
        }      
                  
       #endregion
       
    }
}
