﻿var trafficData = {}
var WIMFilePath = "";

//#region for traffic Loop data import and traffic WIM data import

//On Loop File change
trafficData.onFileChange = function (e) {
    if ($("#btnUplaodFile").text().trim() == "Start Import") { $("#btnUplaodFile").attr("disabled", false); }
    $("#txtFileSelected").text(e.files[0].name)
    if ($chkStationNumber.prop("checked")) {
        $lstStationNums.val(e.files[0].name.split('.')[0].trim());
    }
}

//On WIM File change
trafficData.OnIMFileChange = function (e) {
    $("#txtFileSelected").text(e.files[0].name)
    var formData = new FormData($(fileupload)[0]);
    $.ajax({
        url: "/handlers/fileUploadHandler.ashx?path=/zz_temp/",
        type: 'POST',
        data: formData,
        async: false,
        enctype: "multipart/form-data",
        success: function (data) {
            var fileURL = JSON.parse(data).files[0].url;
            WIMFilePath = fileURL
            ju.clearListBox($lstSheets[0]);
            ju.doAjaxWebService("/webServices/fileService.asmx/GetSheetsFromSelectedFile", "{ filePath : '" + fileURL + "' }", trafficData.showSourceFileSheets, ju.handleWebServiceError);
        },
        cache: false,
        contentType: false,
        processData: false
    });
    return false;
}

trafficData.showSourceFileSheets = function (data) {
    if (data && data.d) {
        for (var iSheet = 0; iSheet < data.d.length; iSheet++) {
            var sheetName = data.d[iSheet];
            ju.addListItem($lstSheets[0], sheetName, sheetName);
        }
        if ($("#btnStartImport").text().trim() == "Start Import") { $("#btnStartImport").attr("disabled", false); }
    }
}

//Import WIM data
trafficData.ImportWIMData = function () {
    ju.doAjaxWebService("/webServices/trafficService.asmx/ImportTRACWIMData", "{ fileURL : '" + WIMFilePath + "',sheetName:'" + $lstSheets.val() + "'}", function (data) {
        if (data.d.length > 0) {
            $("#divErrors").html("");
            var errCount = data.d.length;
            for (var i = 0; i < errCount; i++) {
                var errTxt = data.d[i];
                $("#divErrors").append("<p class='text-error'>" + errTxt + "</p>");
            }
            $('#mdlShowErrors').modal('show');
        }
        else {
            bootbox.alert("Trafic data was imported successfully.");
        }
        $btnStartImport.text("Start Import");
        $btnStartImport.attr("disabled", false);
    }, ju.handleWebServiceError);
}

//Imports the Loop Data
trafficData.importData = function () {
    var formData = new FormData($(fileupload)[0]);
    $.ajax({
        url: "/handlers/fileUploadHandler.ashx?path=/zz_temp/",
        type: 'POST',
        data: formData,
        async: false,
        enctype: "multipart/form-data",
        success: function (data) {
            var fileURL = JSON.parse(data).files[0].url;
            var stDate = "";
            var endDate = "";
            if ($rdImportDataRange.prop("checked")) {
                stDate = $dtFrom.val();
                endDate = $dtTo.val();
            }
            var stationNumber = parseInt($lstStationNums.val());
            ju.doAjaxWebService("/webServices/trafficService.asmx/ImportTRACLoopData", "{ fileURL : '" + fileURL + "',startDate:'" + stDate + "',endDate:'" + endDate + "',stationNumber:" + stationNumber + "}", function (data) {
                $("#btnUplaodFile").text("Start Import")
                $("#btnUplaodFile").attr("disabled", false);
                if (data.d.length > 0) {
                    $("#divErrors").html("");
                    var errCount = data.d.length;
                    for (var i = 0; i < errCount; i++) {
                        var errTxt = data.d[i];
                        $("#divErrors").append("<p class='text-error'>" + errTxt + "</p>");
                    }
                    $('#mdlShowErrors').modal('show');
                }
                else {
                    bootbox.alert("Trafic data was imported successfully.");
                }
            }, ju.handleWebServiceError);
        },
        cache: false,
        contentType: false,
        processData: false
    });
    return false;
}

//Get the traffic station numbers
trafficData.getTrafficStationNumbers = function () {
    var data = "{}";
    ju.doAjaxWebService("/webServices/trafficService.asmx/getTrafficStationsData", data, trafficData.showTrafficStationNumbers, ju.handleWebServiceError);
}

trafficData.showTrafficStationNumbers = function (data) {
    if (data && data.d) {
        var allTrafficStations = data.d.trafficStations;
        ju.clearListBox($lstStationNums[0]);
        for (var i = 0; i < allTrafficStations.length; i++) {
            var stationNum = allTrafficStations[i].statNumber;
            ju.addListItem($lstStationNums[0], stationNum, stationNum);
        }
        $lstStationNums.change();
    }
}

//#endregion

//#region for entered date converstion to correct format

//Validates the user input
trafficData.validateUserInput = function () {
    if ($rdImportDataRange.prop("checked")) {
        var dtFrmErr = 0;
        var dtToErr = 0;
        $('#dtFrm').css("border-color", "#dce4ec");
        $('#dtTo').css("border-color", "#dce4ec");

        if ($("#dtFrm").val().length < 11 || junoValid.validateDateOk($("#dtFrm").val()) > 0) {
            dtFrmErr = dtFrmErr + 1;
            $('#dtFrm').css("border-color", "#e74c3c");
        }

        if ($("#dtTo").val().length < 11 || junoValid.validateDateOk($("#dtTo").val()) > 0) {
            dtToErr = dtToErr + 1;
            $('#dtTo').css("border-color", "#e74c3c");
        }
        if (dtFrmErr > 0 || dtToErr > 0) {
            return false;
        }
        else if (new Date($("#dtFrm").val()) > new Date($("#dtTo").val())) {
            $('#dtFrm').css("border-color", "#e74c3c");
            $('#dtTo').css("border-color", "#e74c3c");
            return false;
        }
        else {
            return true;
        }
    }
    else {
        $('#dtFrm').css("border-color", "#dce4ec");
        $('#dtTo').css("border-color", "#dce4ec");
        return true;
    }
}

//Corrects the date input format for eg:if we enter "1/jan/2001" then it corrects as "01/Jan/2014" and removes spaces also.
trafficData.getValidDateString = function () {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var dtFrom;

    if ($("#dtFrm").val().trim().length >= 11) {
        dtFrom = ju.getValidDateString($("#dtFrm").val().trim());
    }
    else {
        dtFrom = $("#dtFrm").val().trim();
    }
    var dtTo;
    if ($("#dtTo").val().trim().length >= 11) {
        dtTo = ju.getValidDateString($("#dtTo").val().trim());
    }
    else {
        dtTo = $("#dtTo").val().trim();
    }
    var pattern = /^\s*(\d{4})-(\d\d)-(\d\d)\s*$/;
    var fromDay = isNaN(new Date(dtFrom).getDate());
    var toDay = isNaN(new Date(dtTo).getDate());

    if (isNaN(NaN)) fromDay = new Date();
    if (isNaN(undefined)) fromDay = new Date(); // Default to current

    if (isNaN(NaN)) toDay = new Date();
    if (isNaN(undefined)) toDay = new Date();// Default to current

    if (fromDay < 10) { fromDay = "0" + fromDay }
    if (toDay < 10) { toDay = "0" + toDay }

    if (dtFrom.trim() != "" && pattern.test(dtFrom.trim())) {
        dtFrom = fromDay + "-" + months[new Date(dtFrom).getMonth()] + "-" + new Date(dtFrom).getFullYear();
    }
    if (dtTo.trim() != "" && pattern.test(dtTo.trim())) {
        dtTo = toDay + "-" + months[new Date(dtTo).getMonth()] + "-" + new Date(dtTo).getFullYear();
    }

    $("#dtFrm").val(dtFrom);
    $("#dtTo").val(dtTo);
}

//#endregion
