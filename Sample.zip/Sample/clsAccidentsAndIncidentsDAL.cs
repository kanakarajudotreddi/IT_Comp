﻿using junoViewerLib.BAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace junoViewerLib.DAL
{
    public class clsAccidentsAndIncidentsDAL
    {

        #region Variables

        private DBWorkerBase DBMan;
        private string usersTableName = "tblAccidentsAndMajorIncidents";

        #endregion

        #region Constructor

        public clsAccidentsAndIncidentsDAL(DBWorkerBase DBManager)
        {
            this.DBMan = DBManager;
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Get the Accidents and incidents
        /// </summary>
        /// <param name="networkID"></param>
        /// <param name="secLabel1"></param>
        /// <param name="secLabel2"></param>
        /// <param name="sectionId"></param>
        /// <param name="optionType"></param>
        /// <param name="reportType"></param>
        /// <param name="showOnlyFurnitureDamaged"></param>
        /// <returns></returns>
        public List<clsAccidentsAndIncidentsBAL> GeAccidentsAndIncidentsData(int networkID, string secLabel1, string secLabel2, int sectionId, string optionType, string reportType, bool showOnlyFurnitureDamaged = false)
        {
            try
            {
                string Q = "SELECT ID,sectionID,sector,kmsTravelled,reportedBy,name,action,helpDeskRef,patrolVehicleRegNo,location,isRoadFurnitureDamaged ";
                Q = Q + " FROM " + usersTableName;

                string strWhereCondition;
                if (optionType.Equals("EntireNetwork"))
                {
                    strWhereCondition = " WHERE ";
                    string Qry = "Select sectionID From tblSections Where networkID=" + networkID;
                    strWhereCondition = strWhereCondition + "(sectionID in (" + Qry + "))";
                }
                else if (optionType.Equals("EntireSectionLabel1"))
                {
                    strWhereCondition = " WHERE ";
                    string Qry = "Select sectionID From tblSections Where sectionLabel1='" + secLabel1 + "'";
                    strWhereCondition = strWhereCondition + "(sectionID in (" + Qry + "))";
                }
                else
                {
                    strWhereCondition = " WHERE sectionID=" + sectionId;
                }
                strWhereCondition = strWhereCondition + " and type = '" + reportType + "'";
                if (showOnlyFurnitureDamaged)
                {
                    strWhereCondition = strWhereCondition + " and isRoadFurnitureDamaged = '" + showOnlyFurnitureDamaged + "'";
                }
                Q = Q + " " + strWhereCondition;

                var result = new List<clsAccidentsAndIncidentsBAL>();
                DataTable data = DBMan.ExecuteSQLQueryReturnDataTable(Q, null);
                foreach (DataRow dataRow in data.Rows)
                {
                    clsAccidentsAndIncidentsBAL objAccidentsAndIncidentsData = new clsAccidentsAndIncidentsBAL();
                    objAccidentsAndIncidentsData.ID = Convert.ToInt32(dataRow["ID"].ToString());
                    objAccidentsAndIncidentsData.sectionID = Convert.ToInt32(dataRow["sectionID"].ToString());
                    objAccidentsAndIncidentsData.sector = dataRow["sector"].ToString();
                    objAccidentsAndIncidentsData.kmsTravelled = Convert.ToInt32(dataRow["kmsTravelled"].ToString());
                    objAccidentsAndIncidentsData.reportedBy = dataRow["reportedBy"].ToString();
                    objAccidentsAndIncidentsData.name = dataRow["name"].ToString();
                    objAccidentsAndIncidentsData.action = dataRow["action"].ToString();
                    objAccidentsAndIncidentsData.helpDeskRef = dataRow["helpDeskRef"].ToString();
                    objAccidentsAndIncidentsData.patrolVehicleRegNo = dataRow["patrolVehicleRegNo"].ToString();
                    objAccidentsAndIncidentsData.location = dataRow["location"].ToString();
                    objAccidentsAndIncidentsData.isRoadFurnitureDamaged = Convert.ToBoolean(dataRow["isRoadFurnitureDamaged"] != System.DBNull.Value ? dataRow["isRoadFurnitureDamaged"] : "False");

                    result.Add(objAccidentsAndIncidentsData);
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GeAccidentsAndIncidentsData. Details: " + ex.Message);
            }

        }

        /// <summary>
        /// Gets the quantity and cost for the Road Furniture by accidentID.
        /// </summary>
        /// <param name="accidentID"></param>
        /// <returns></returns>
        public clsRoadFurniture GetQuantityAndCostForRoadFurniture(int accidentID)
        {
            try
            {
                string Q = "select guardRails_Extent,hazPlates_Extent,drainageStructs_Extent,streetLights_Extent,bridgeParapet_Extent,fencing_Extent,pavement_extent,signs_Extent,Other_Extent,";
                Q = Q + "guardRails_Cost,hazPlates_Cost,drainageStructs_Cost,streetLights_Cost,bridgeParapet_Cost,fencing_Cost,pavement_Cost,signs_Cost,Other_Cost from tblRoadFurniture where accidentID=" + accidentID;
                var result = new clsRoadFurniture();
                DataTable data = DBMan.ExecuteSQLQueryReturnDataTable(Q, null);
                foreach (DataRow dataRow in data.Rows)
                {
                    result.guardRails_Extent = Convert.ToInt32(dataRow["guardRails_Extent"] != System.DBNull.Value ? dataRow["guardRails_Extent"] : "0");
                    result.hazPlates_Extent = Convert.ToInt32(dataRow["hazPlates_Extent"] != System.DBNull.Value ? dataRow["hazPlates_Extent"] : "0");
                    result.drainageStructs_Extent = Convert.ToInt32(dataRow["drainageStructs_Extent"] != System.DBNull.Value ? dataRow["drainageStructs_Extent"] : "0");
                    result.streetLights_Extent = Convert.ToInt32(dataRow["streetLights_Extent"] != System.DBNull.Value ? dataRow["streetLights_Extent"] : "0");
                    result.bridgeParapet_Extent = Convert.ToInt32(dataRow["bridgeParapet_Extent"] != System.DBNull.Value ? dataRow["bridgeParapet_Extent"] : "0");
                    result.fencing_Extent = Convert.ToInt32(dataRow["fencing_Extent"] != System.DBNull.Value ? dataRow["fencing_Extent"] : "0");
                    result.pavement_extent = Convert.ToInt32(dataRow["pavement_extent"] != System.DBNull.Value ? dataRow["pavement_extent"] : "0");
                    result.signs_Extent = Convert.ToInt32(dataRow["signs_Extent"] != System.DBNull.Value ? dataRow["signs_Extent"] : "0");
                    result.other_Extent = Convert.ToInt32(dataRow["Other_Extent"] != System.DBNull.Value ? dataRow["Other_Extent"] : "0");

                    result.guardRails_Cost = Convert.ToDouble(dataRow["guardRails_Cost"] != System.DBNull.Value ? dataRow["guardRails_Cost"].ToString() != "" ? dataRow["guardRails_Cost"] : "0" : "0");
                    result.hazPlates_Cost = Convert.ToDouble(dataRow["hazPlates_Cost"] != System.DBNull.Value ? dataRow["hazPlates_Cost"].ToString() != "" ? dataRow["hazPlates_Cost"] : "0" : "0");
                    result.drainageStructs_Cost = Convert.ToDouble(dataRow["drainageStructs_Cost"] != System.DBNull.Value ? dataRow["drainageStructs_Cost"].ToString() != "" ? dataRow["drainageStructs_Cost"] : "0" : "0");
                    result.streetLights_Cost = Convert.ToDouble(dataRow["streetLights_Cost"] != System.DBNull.Value ? dataRow["streetLights_Cost"].ToString() != "" ? dataRow["streetLights_Cost"] : "0" : "0");
                    result.bridgeParapet_Cost = Convert.ToDouble(dataRow["bridgeParapet_Cost"] != System.DBNull.Value ? dataRow["bridgeParapet_Cost"].ToString() != "" ? dataRow["bridgeParapet_Cost"] : "0" : "0");
                    result.fencing_Cost = Convert.ToDouble(dataRow["fencing_Cost"] != System.DBNull.Value ? dataRow["fencing_Cost"].ToString() != "" ? dataRow["fencing_Cost"] : "0" : "0");
                    result.pavement_Cost = Convert.ToDouble(dataRow["pavement_Cost"] != System.DBNull.Value ? dataRow["pavement_Cost"].ToString() != "" ? dataRow["pavement_Cost"] : "0" : "0");
                    result.signs_Cost = Convert.ToDouble(dataRow["signs_Cost"] != System.DBNull.Value ? dataRow["signs_Cost"].ToString() != "" ? dataRow["signs_Cost"] : "0" : "0");
                    result.other_Cost = Convert.ToDouble(dataRow["Other_Cost"] != System.DBNull.Value ? dataRow["Other_Cost"].ToString() != "" ? dataRow["Other_Cost"] : "0" : "0");

                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetQuantityAndCostForRoadFurniture. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Saves the furniture cost data for the selected AccidentID
        /// </summary>
        /// <param name="accidentID"></param>
        /// <param name="furnitureData"></param>
        /// <returns></returns>
        public int SaveFurnitureCost(int accidentID, clsRoadFurniture furnitureData)
        {
            try
            {
                Dictionary<string, object> updatedValues = new Dictionary<string, object>();
                updatedValues.Add("guardRails_Cost", furnitureData.guardRails_Cost);
                updatedValues.Add("hazPlates_Cost", furnitureData.hazPlates_Cost);
                updatedValues.Add("drainageStructs_Cost", furnitureData.drainageStructs_Cost);
                updatedValues.Add("streetLights_Cost", furnitureData.streetLights_Cost);
                updatedValues.Add("bridgeParapet_Cost", furnitureData.bridgeParapet_Cost);
                updatedValues.Add("fencing_Cost", furnitureData.fencing_Cost);
                updatedValues.Add("pavement_Cost", furnitureData.pavement_Cost);
                updatedValues.Add("signs_Cost", furnitureData.signs_Cost);
                updatedValues.Add("Other_Cost", furnitureData.other_Cost);
                updatedValues.Add("responseCost", furnitureData.response_Cost);
                Dictionary<string, object> whereCondition = new Dictionary<string, object>();
                whereCondition.Add("accidentID", accidentID);
                return DBMan.ExecuteUpdateCommand("tblRoadFurniture", updatedValues, whereCondition);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in SaveFurnitureCost. Details: " + ex.Message);
            }
        }

        /// <summary>
        /// Down load the accidents and incidents data
        /// </summary>
        /// <param name="lstAccidentsAndIncidents"></param>
        /// <param name="targetFileName"></param>
        /// <param name="targetSheetName"></param>
        /// <returns></returns>
        public bool ExportAccidentsAndIncidentsData(List<clsAccidentsAndIncidentsBAL> lstAccidentsAndIncidents, string targetFileName, string targetSheetName)
        {
            try
            {
                if (File.Exists(targetFileName))
                {
                    try
                    {
                        File.Delete(targetFileName);
                    }
                    catch
                    {
                        throw new Exception("Error deleting Accidents and Incidents export target file.");
                    }
                }

                var xlMan = new junoViewerVBUtilities.xlFileHelper();
                var xlSheet = xlMan.GetWorksheet(targetSheetName);

                //write the headers
                xlSheet.Cells[0, 0].Value = "Section ID";
                xlSheet.Cells[0, 1].Value = "Sector";
                xlSheet.Cells[0, 2].Value = "Kms Travelled";
                xlSheet.Cells[0, 3].Value = "Reported By";
                xlSheet.Cells[0, 4].Value = "Name";
                xlSheet.Cells[0, 5].Value = "Action";
                xlSheet.Cells[0, 6].Value = "HelpDeskRef";
                xlSheet.Cells[0, 7].Value = "Patrol Vehicle RegNo";
                xlSheet.Cells[0, 8].Value = "Location";


                xlSheet.Cells[0, 0, 0, 8].Interior.Color = SpreadsheetGear.Colors.LightGray;
                xlSheet.Cells[0, 0, 0, 8].Font.Bold = true;

                int iRow = 1;
                foreach (var newAccidentsAndIncidents in lstAccidentsAndIncidents)
                {
                    xlSheet.Cells[iRow, 0].Value = newAccidentsAndIncidents.sectionID;
                    xlSheet.Cells[iRow, 1].Value = newAccidentsAndIncidents.sector;
                    xlSheet.Cells[iRow, 2].Value = newAccidentsAndIncidents.kmsTravelled;
                    xlSheet.Cells[iRow, 3].Value = newAccidentsAndIncidents.reportedBy;
                    xlSheet.Cells[iRow, 4].Value = newAccidentsAndIncidents.name;
                    xlSheet.Cells[iRow, 5].Value = newAccidentsAndIncidents.action;
                    xlSheet.Cells[iRow, 6].Value = newAccidentsAndIncidents.helpDeskRef;
                    xlSheet.Cells[iRow, 7].Value = newAccidentsAndIncidents.patrolVehicleRegNo;
                    xlSheet.Cells[iRow, 8].Value = newAccidentsAndIncidents.location;

                    iRow++;
                }
                iRow = iRow - 1;
                xlSheet.Cells[0, 0, iRow, 8].Borders.Color = SpreadsheetGear.Colors.Gray;
                xlSheet.Cells[0, 0, iRow, 8].Borders.LineStyle = SpreadsheetGear.LineStyle.Continous;
                xlSheet.Cells[0, 0, iRow, 8].ColumnWidth = 15;
                xlSheet.Cells[0, 0, iRow, 8].HorizontalAlignment = SpreadsheetGear.HAlign.Center;
                xlSheet.Cells[0, 0, iRow, 0].HorizontalAlignment = SpreadsheetGear.HAlign.Left;

                xlMan.Workbook.SaveAs(targetFileName, SpreadsheetGear.FileFormat.OpenXMLWorkbook);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ExportAccidentsAndIncidentsData. Details: " + ex.Message);
            }
        }

        #endregion

    }
}
